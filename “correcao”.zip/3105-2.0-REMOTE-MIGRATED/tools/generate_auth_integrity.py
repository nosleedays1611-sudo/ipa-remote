#!/usr/bin/env python3
import argparse, hashlib, struct
from pathlib import Path

LC_SEGMENT_64 = 0x19
MH_MAGIC_64 = 0xFEEDFACF
CPU_TYPE_ARM64 = 0x0100000C

# Stronger than the older EXTERNAL check: protect executable code, constructor
# offsets, Objective-C method/class metadata, constant strings and key data.
PROTECTED = [
    ('__TEXT', '__text'),
    ('__TEXT', '__init_offsets'),
    ('__TEXT', '__objc_methlist'),
    ('__TEXT', '__const'),
    ('__TEXT', '__cstring'),
    ('__TEXT', '__objc_methname'),
    ('__TEXT', '__objc_classname'),
    ('__TEXT', '__objc_methtype'),
    ('__TEXT', '__ustring'),
    ('__DATA_CONST', '__const'),
    ('__DATA_CONST', '__cfstring'),
    ('__DATA_CONST', '__objc_classlist'),
    ('__DATA_CONST', '__objc_protolist'),
    ('__DATA_CONST', '__objc_imageinfo'),
    ('__DATA_CONST', '__objc_arraydata'),
    ('__DATA_CONST', '__objc_arrayobj'),
    ('__DATA', '__objc_const'),
    ('__DATA', '__objc_selrefs'),
    ('__DATA', '__objc_classrefs'),
    ('__DATA', '__objc_superrefs'),
    ('__DATA', '__objc_ivar'),
    ('__DATA', '__objc_data'),
    ('__DATA', '__data'),
]

def cstr(raw: bytes) -> str:
    return raw.split(b'\0', 1)[0].decode('ascii', 'ignore')

def sections(data: bytes):
    if len(data) < 32:
        raise SystemExit('Mach-O truncado')
    magic, cpu, _, _, ncmds, _, _, _ = struct.unpack_from('<IiiIIIII', data, 0)
    if magic != MH_MAGIC_64 or cpu != CPU_TYPE_ARM64:
        raise SystemExit('Esperado Mach-O 64-bit arm64')
    off = 32
    found = {}
    for _ in range(ncmds):
        if off + 8 > len(data):
            raise SystemExit('Load command truncado')
        cmd, cmdsize = struct.unpack_from('<II', data, off)
        if cmdsize < 8 or off + cmdsize > len(data):
            raise SystemExit('Load command inválido')
        if cmd == LC_SEGMENT_64:
            nsects = struct.unpack_from('<I', data, off + 64)[0]
            sec = off + 72
            for _ in range(nsects):
                if sec + 80 > off + cmdsize:
                    raise SystemExit('Section table inválida')
                sectname = cstr(data[sec:sec+16])
                segname = cstr(data[sec+16:sec+32])
                size = struct.unpack_from('<Q', data, sec+40)[0]
                fileoff = struct.unpack_from('<I', data, sec+48)[0]
                found[(segname, sectname)] = (fileoff, size)
                sec += 80
        off += cmdsize
    return found

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dylib', required=True)
    ap.add_argument('--swift', required=True)
    args = ap.parse_args()

    dylib = Path(args.dylib)
    data = dylib.read_bytes()
    found = sections(data)

    ranges = []
    protected = bytearray()
    missing = []
    for key in PROTECTED:
        if key not in found:
            missing.append('/'.join(key))
            continue
        off, size = found[key]
        if size == 0:
            continue
        if off + size > len(data):
            raise SystemExit(f'Seção fora do arquivo: {key}')
        ranges.append((off, size, key[0], key[1]))
        protected += data[off:off+size]

    if ('__TEXT', '__text') not in found or ('__TEXT', '__cstring') not in found:
        raise SystemExit('Seções mínimas de autenticação ausentes')
    if len(ranges) < 8:
        raise SystemExit(f'Poucas seções protegidas: {len(ranges)}; ausentes={missing}')

    digest = hashlib.sha256(protected).hexdigest()
    swift_ranges = ',\n'.join(
        f'        (offset: {off}, size: {size}), // {seg},{sect}'
        for off, size, seg, sect in ranges
    )

    out = Path(args.swift)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(f'''import Foundation\n\nenum RemoteAuthIntegrity {{\n    static let expectedSHA256 = "{digest}"\n    static let minimumFileSize = {len(data)}\n    static let protectedRanges: [(offset: Int, size: Int)] = [\n{swift_ranges}\n    ]\n}}\n''')

    print('RemoteAuth integrity:', digest)
    print('Protected sections:', len(ranges), 'bytes:', len(protected), 'file:', len(data))
    for off, size, seg, sect in ranges:
        print(f'  {seg},{sect}: offset={off} size={size}')
    if missing:
        print('Optional sections absent:', ', '.join(missing))

if __name__ == '__main__':
    main()
