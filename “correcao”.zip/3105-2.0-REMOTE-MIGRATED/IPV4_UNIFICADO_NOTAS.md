# REMOTE iOS — IPv4 unificado

- `AuthSource/RemoteAuth.mm` e `ThreeOneOSFive/Auth/RemoteAuth.mm`: usam `GET https://remoteios.xyz/api/client-ip`, exatamente como o site.
- O login busca um IPv4 novo imediatamente antes de autenticar e envia `ip_proof` quando a API disponibiliza esse campo.
- A verificação periódica passa a consultar `GET /api/auth/me`, sem chamar `api.ipify.org`.
- KEY, token, AuthProtection, funções do painel, patches e demais arquivos permanecem inalterados.
- Compatibilidade com server.js antigo: `ip_proof` é opcional. Para vinculação consistente entre requisições, publique o server.js que valida o comprovante assinado.
- Se a IPA/site e o Assembly realmente saírem por VPNs/proxies distintos, a diferença de IP continuará existindo. Esta alteração não mascara IPs nem ignora vínculos do servidor.
- `build-ipa.yml` compila `AuthSource/RemoteAuth.mm` e mantém a proteção por hash da dylib.
- Validação realizada: comparação dos dois arquivos Auth, verificação estática dos pontos de integração, integridade do ZIP. Não foi possível compilar Xcode ou testar em aparelhos nesta sessão.
