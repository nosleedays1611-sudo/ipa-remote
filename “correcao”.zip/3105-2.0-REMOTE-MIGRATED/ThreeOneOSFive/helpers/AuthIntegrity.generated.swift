import Foundation

enum RemoteAuthIntegrity {
    static let expectedSHA256 = "68276a2fe0bd1236aba20557a78274b89c593deed43266db80c888f8d31dfa58"
    static let minimumFileSize = 4631200
    static let protectedRanges: [(offset: Int, size: Int)] = [
        (offset: 16384, size: 27212), // __TEXT,__text,
        (offset: 49472, size: 4), // __TEXT,__init_offsets,
        (offset: 49480, size: 964), // __TEXT,__objc_methlist,
        (offset: 54280, size: 432), // __TEXT,__const,
        (offset: 54712, size: 977), // __TEXT,__cstring,
        (offset: 55689, size: 4476), // __TEXT,__objc_methname,
        (offset: 60165, size: 94), // __TEXT,__objc_classname,
        (offset: 60259, size: 899), // __TEXT,__objc_methtype,
        (offset: 61158, size: 662), // __TEXT,__ustring,
        (offset: 66176, size: 608), // __DATA_CONST,__const,
        (offset: 66784, size: 2528), // __DATA_CONST,__cfstring,
        (offset: 69312, size: 24), // __DATA_CONST,__objc_classlist,
        (offset: 69336, size: 16), // __DATA_CONST,__objc_protolist,
        (offset: 69352, size: 8), // __DATA_CONST,__objc_imageinfo,
        (offset: 69360, size: 160), // __DATA_CONST,__objc_arraydata,
        (offset: 69520, size: 216), // __DATA_CONST,__objc_arrayobj,
        (offset: 81920, size: 1744), // __DATA,__objc_const,
        (offset: 83664, size: 1696), // __DATA,__objc_selrefs,
        (offset: 85360, size: 296), // __DATA,__objc_classrefs,
        (offset: 85656, size: 16), // __DATA,__objc_superrefs,
        (offset: 85672, size: 84), // __DATA,__objc_ivar,
        (offset: 85760, size: 240), // __DATA,__objc_data,
        (offset: 86000, size: 192), // __DATA,__data
    ]
}
