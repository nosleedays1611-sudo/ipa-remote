#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

FOUNDATION_EXPORT BOOL RARemoteAuthClassPresent(void);
FOUNDATION_EXPORT BOOL RARemoteAuthImagePathIsExpected(void);
FOUNDATION_EXPORT void RARemoteAuthEnsureStarted(void);
FOUNDATION_EXPORT BOOL RARemoteAuthIsUnlocked(void);
FOUNDATION_EXPORT NSString * _Nullable RARemoteAuthValidatedKey(void);
FOUNDATION_EXPORT NSString * _Nullable RARemoteAuthValidatedIPv4(void);
FOUNDATION_EXPORT NSString * _Nullable RARemoteAuthSessionToken(void);
FOUNDATION_EXPORT NSString * _Nullable RARemoteAuthSessionExpiresAt(void);
FOUNDATION_EXPORT NSString * _Nullable RARemoteAuthHeartbeatNonce(void);
FOUNDATION_EXPORT double RARemoteAuthLastServerSuccess(void);
FOUNDATION_EXPORT BOOL RASecurityEnvironmentIsClean(void);

NS_ASSUME_NONNULL_END
