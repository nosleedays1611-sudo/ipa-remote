#import "RemoteAuthRuntimeBridge.h"

#import <objc/message.h>
#import <objc/runtime.h>
#import <mach-o/dyld.h>
#import <sys/sysctl.h>
#import <unistd.h>
#import <limits.h>
#import <stdlib.h>
#import <string.h>

// RemoteAuth.dylib remains a strong Mach-O dependency, but startup validation
// is intentionally deferred until SwiftUI has a live scene. Hard-exiting from
// a pre-main constructor can terminate the app before UIKit/SwiftUI bootstrap.

static id RAManager(void) {
    Class cls = NSClassFromString(@"RemoteAuthManager");
    if (!cls) return nil;
    SEL sharedSel = NSSelectorFromString(@"shared");
    if (![cls respondsToSelector:sharedSel]) return nil;
    id (*sendObject)(id, SEL) = (id (*)(id, SEL))objc_msgSend;
    return sendObject((id)cls, sharedSel);
}

static NSString *RAStringProperty(NSString *selectorName) {
    id manager = RAManager();
    if (!manager) return nil;
    SEL selector = NSSelectorFromString(selectorName);
    if (![manager respondsToSelector:selector]) return nil;
    id (*sendObject)(id, SEL) = (id (*)(id, SEL))objc_msgSend;
    id value = sendObject(manager, selector);
    return [value isKindOfClass:[NSString class]] ? value : nil;
}

static NSString *RAResolvedPath(NSString *path) {
    if (path.length == 0) return nil;
    char resolved[PATH_MAX];
    if (realpath(path.fileSystemRepresentation, resolved) == NULL) return nil;
    return [NSString stringWithUTF8String:resolved];
}

BOOL RARemoteAuthImagePathIsExpected(void) {
    Class cls = NSClassFromString(@"RemoteAuthManager");
    if (!cls) return NO;

    const char *raw = class_getImageName(cls);
    if (!raw || raw[0] == '\0') return NO;

    NSString *actual = [NSString stringWithUTF8String:raw];
    NSString *expected = [[[NSBundle mainBundle] bundlePath]
        stringByAppendingPathComponent:@"Frameworks/RemoteAuth.dylib"];

    NSString *actualResolved = RAResolvedPath(actual);
    NSString *expectedResolved = RAResolvedPath(expected);
    if (actualResolved && expectedResolved) {
        return [actualResolved isEqualToString:expectedResolved];
    }

    return [actual hasSuffix:@"/Frameworks/RemoteAuth.dylib"];
}

BOOL RARemoteAuthClassPresent(void) {
    id manager = RAManager();
    if (!manager || !RARemoteAuthImagePathIsExpected()) return NO;

    NSArray<NSString *> *required = @[
        @"start", @"unlocked", @"validatedKey", @"validatedIPv4",
        @"securitySessionToken", @"securitySessionExpiresAt",
        @"heartbeatNonce", @"lastServerSuccess"
    ];

    for (NSString *name in required) {
        if (![manager respondsToSelector:NSSelectorFromString(name)]) return NO;
    }
    return YES;
}

void RARemoteAuthEnsureStarted(void) {
    id manager = RAManager();
    if (!manager || !RARemoteAuthImagePathIsExpected()) return;
    SEL selector = NSSelectorFromString(@"start");
    if (![manager respondsToSelector:selector]) return;
    void (*sendVoid)(id, SEL) = (void (*)(id, SEL))objc_msgSend;
    sendVoid(manager, selector);
}

BOOL RARemoteAuthIsUnlocked(void) {
    id manager = RAManager();
    if (!manager || !RARemoteAuthImagePathIsExpected()) return NO;
    SEL selector = NSSelectorFromString(@"unlocked");
    if (![manager respondsToSelector:selector]) return NO;
    BOOL (*sendBool)(id, SEL) = (BOOL (*)(id, SEL))objc_msgSend;
    return sendBool(manager, selector);
}

NSString *RARemoteAuthValidatedKey(void) {
    if (!RARemoteAuthImagePathIsExpected()) return nil;
    return RAStringProperty(@"validatedKey");
}

NSString *RARemoteAuthValidatedIPv4(void) {
    if (!RARemoteAuthImagePathIsExpected()) return nil;
    return RAStringProperty(@"validatedIPv4");
}

NSString *RARemoteAuthSessionToken(void) {
    if (!RARemoteAuthImagePathIsExpected()) return nil;
    return RAStringProperty(@"securitySessionToken");
}

NSString *RARemoteAuthSessionExpiresAt(void) {
    if (!RARemoteAuthImagePathIsExpected()) return nil;
    return RAStringProperty(@"securitySessionExpiresAt");
}

NSString *RARemoteAuthHeartbeatNonce(void) {
    if (!RARemoteAuthImagePathIsExpected()) return nil;
    return RAStringProperty(@"heartbeatNonce");
}

double RARemoteAuthLastServerSuccess(void) {
    id manager = RAManager();
    if (!manager || !RARemoteAuthImagePathIsExpected()) return 0.0;
    SEL selector = NSSelectorFromString(@"lastServerSuccess");
    if (![manager respondsToSelector:selector]) return 0.0;
    double (*sendDouble)(id, SEL) = (double (*)(id, SEL))objc_msgSend;
    return sendDouble(manager, selector);
}

static BOOL RAHasDebugger(void) {
    int mib[4] = { CTL_KERN, KERN_PROC, KERN_PROC_PID, getpid() };
    struct kinfo_proc info;
    size_t size = sizeof(info);
    memset(&info, 0, sizeof(info));
    if (sysctl(mib, 4, &info, &size, NULL, 0) != 0) return NO;
#if defined(P_TRACED)
    return (info.kp_proc.p_flag & P_TRACED) != 0;
#else
    return NO;
#endif
}

static BOOL RAHasSuspiciousEnvironment(void) {
    const char *keys[] = {
        "DYLD_INSERT_LIBRARIES", "DYLD_LIBRARY_PATH", "DYLD_FRAMEWORK_PATH",
        "DYLD_FALLBACK_LIBRARY_PATH"
    };
    for (NSUInteger i = 0; i < sizeof(keys) / sizeof(keys[0]); i++) {
        const char *value = getenv(keys[i]);
        if (value && value[0] != '\0') return YES;
    }
    return NO;
}

static BOOL RAHasSuspiciousLoadedImage(void) {
    NSArray<NSString *> *needles = @[
        @"frida", @"gadget", @"cydiasubstrate", @"mobilesubstrate",
        @"substitute", @"libhooker", @"ellekit", @"cycript",
        @"flexloader", @"sslkill"
    ];

    uint32_t count = _dyld_image_count();
    for (uint32_t i = 0; i < count; i++) {
        const char *rawName = _dyld_get_image_name(i);
        if (!rawName) continue;
        NSString *name = [[NSString stringWithUTF8String:rawName] lowercaseString];
        for (NSString *needle in needles) {
            if ([name containsString:needle]) return YES;
        }
    }
    return NO;
}

BOOL RASecurityEnvironmentIsClean(void) {
    if (RAHasDebugger()) return NO;
    if (RAHasSuspiciousEnvironment()) return NO;
    if (RAHasSuspiciousLoadedImage()) return NO;
    return YES;
}
