# 3105 2.0 + REMOTE — migration report

## Base and behavior

- The clean 3105 2.0 project is the foundation; original helpers, services, iOS compatibility policy, repository components, and translations were preserved.
- The personalized REMOTE screen is still the visible ContentView (GIF, particles, INJETAR/DESINJETAR, dialogs), using the existing patch apply/restore services from the clean source.
- The clean 2.0 original screen has been retained and registered as `Native3105ContentView.swift`; it is not the startup screen, so the REMOTE visual remains unchanged.
- AuthProtection, the RemoteAuth runtime bridge, the existing dylib/source, and both patch/resource vault bridges were transferred unchanged from the provided personalized source.
- The `.3105` source payload and build scripts are preserved; the GitHub workflow compiles RemoteAuth and produces an unsigned IPA. The build pipeline removes raw `.3105` after vault generation.
- `Info.plist` retains the clean 2.0 version number and minimum iOS target. Its display name is `Injetor`.
- Xcode project references are based on clean 2.0, extended only for the custom auth + vault files and the saved native screen.

## Validation scope

- ZIPs verified through CRC.
- Xcode project plist syntax and Swift parser checks must pass.
- Full iOS compilation/signing and device runtime testing require macOS Xcode/GitHub Actions. **This migration is not represented as runtime-verified or crash-free.**
- The original source includes platform-specific filesystem/exploit operations, which were not executed in this workspace.

## Usage

Upload only this ZIP to your GitHub repository and run `.github/workflows/build-ipa.yml` through workflow_dispatch. Keep it as the only 3105 source ZIP in the action input location.

