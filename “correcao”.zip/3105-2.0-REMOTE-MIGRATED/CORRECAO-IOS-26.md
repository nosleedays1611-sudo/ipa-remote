# Correção de inicialização iOS 26.x

## Diagnóstico verificado nos ZIPs entregues

A source personalizada original usa `ExploitSupportPolicy.supportsKernelExploit()`
para decidir quando chamar o motor de kernel. A migração anterior substituiu
essa condição por `ExploitSupportPolicy.isSupported()`. Isso disparava a rotina
`kexploit_opa334()` também no iOS 26.x, enquanto `kexploit/offsets.m` mantém
um limite interno anterior ao iOS 26.1. O motor abortava em 26.2, 26.3.1 e 26.5.

O limite em `offsets.m` existe em **ambos** os arquivos originais e não foi
alterado nesta correção. Ampliar esse limite sem implementar/validar offsets
para cada build de iOS e hardware seria inseguro.

## Alterações

- `helpers/KernelExploit.swift`: restaura o dispatch original (kernel somente
  nas versões 17/18 cobertas por `supportsKernelExploit()`); impede chamadas
  diretas à rotina em versões fora dessa faixa.
- `App.swift`: mantém `isSupported()` para reconhecer a versão do sistema,
  registra uso da alternativa de contêineres no iOS 26.x e evita inicialização
  manual/inadvertida do mecanismo incompatível.
- `ContentView.swift`: melhora a mensagem quando o contêiner de destino não
  pode ser resolvido, sem alterar interface, patches, validação auth ou lógica
  de aplicação de arquivos.

## Validação e limites

- iOS 26.2, 26.3.1 e 26.5 continuam **aceitos pela política do aplicativo**;
  o kernel exploit não é iniciado automaticamente nessas versões.
- A aplicação efetiva do patch depende das permissões e disponibilidade da
  rotina de resolução de contêineres no dispositivo. Não há garantia de sucesso
  sem teste real em cada versão/dispositivo.
- Testes estáticos e sintáticos foram executados no ambiente Linux. O projeto
  ainda precisa de compilação em Xcode no macOS e testes em dispositivos.
