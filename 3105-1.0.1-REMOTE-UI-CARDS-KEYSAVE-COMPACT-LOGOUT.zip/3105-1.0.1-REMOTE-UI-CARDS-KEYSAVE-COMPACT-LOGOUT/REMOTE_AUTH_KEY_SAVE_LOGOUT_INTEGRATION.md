# REMOTE auth integrated build

This source contains the updated `AuthSource/RemoteAuth.mm` directly inside the IPA project.

The included workflow already performs the complete chain in one run:

1. Compile `AuthSource/RemoteAuth.mm` as arm64 `RemoteAuth.dylib`.
2. Embed `AuthSource/icon.gif` into the dylib as `__DATA,__eaicon`.
3. Strip the dylib and generate `AuthIntegrity.generated.swift` from the exact compiled file.
4. Build the main 3105 REMOTE app.
5. Link/embed `RemoteAuth.dylib` into `3105.app/Frameworks/`.
6. Validate the Mach-O dependency and fingerprint.
7. Package the unsigned IPA.

Auth behavior in this integrated source:
- successful login persists `license-key` in Keychain;
- stored session token is reused after reopening when valid;
- when only the key remains, a fresh session is attempted automatically;
- `SAIR` revokes `/api/auth/logout`, removes the session token, and keeps the key;
- after manual logout, reopening keeps the login screen visible with the saved key until `Entrar` is pressed;
- old REMOTE scene/startup protection is preserved (no UIKit constructor auto-start).

- UI do botão de sair ajustada para o estilo compacto com ícone, semelhante ao layout de referência enviado pelo usuário.
