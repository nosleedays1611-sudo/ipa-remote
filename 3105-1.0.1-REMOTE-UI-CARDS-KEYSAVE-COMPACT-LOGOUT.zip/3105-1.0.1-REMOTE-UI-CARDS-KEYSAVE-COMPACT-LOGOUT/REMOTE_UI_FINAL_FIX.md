# REMOTE UI final fix

- Restored the REMOTE Apply/Restore action cards: `INJETAR` and `DESINJETAR (40%)`.
- Preserved saved-key + manual logout session behavior.
- Reworked logout UI into a compact 44x44 icon button in the upper-right corner.
- Removed the large `SAIR` text presentation and red border.
