import SwiftUI
import UIKit

@main
struct ThreeOneOSFiveApp: App {
    @StateObject private var appState: AppState
    @StateObject private var patchDraftCoordinator: PatchDraftCoordinator
    @StateObject private var fileOperationCoordinator: FileOperationCoordinator
    @StateObject private var authProtection: AuthProtection
    @AppStorage(AppLanguage.storageKey) private var languageCode = AppLanguage.english.rawValue

    private var language: AppLanguage {
        AppLanguage(rawValue: languageCode) ?? .english
    }

    init() {
        // Do not touch UIKit/auth UI from App.init. The main WindowGroup does not
        // exist yet here. The root stays black/fail-closed and bootstrap starts
        // from .task after SwiftUI has attached a scene.
        _appState = StateObject(wrappedValue: AppState())
        _patchDraftCoordinator = StateObject(wrappedValue: PatchDraftCoordinator())
        _fileOperationCoordinator = StateObject(wrappedValue: FileOperationCoordinator())
        _authProtection = StateObject(wrappedValue: AuthProtection.shared)
    }

    var body: some Scene {
        WindowGroup {
            ZStack {
                // Fail-closed screen under the auth UIWindow. Until the dylib
                // has a valid server-backed session, no main panel is rendered.
                Color.black.ignoresSafeArea()

                if authProtection.isAuthorized {
                    ContentView()
                        .environmentObject(appState)
                        .environmentObject(patchDraftCoordinator)
                        .environmentObject(fileOperationCoordinator)
                        .environment(\.appLanguage, language)
                        .environment(\.locale, language.locale)
                        .onAppear {
                            appState.detectSupport()
                        }
                        .onOpenURL { url in
                            patchDraftCoordinator.presentImport(url)
                        }
                }
            }
            .preferredColorScheme(.dark)
            .task {
                await authProtection.bootstrap()
            }
            .onReceive(NotificationCenter.default.publisher(for: UIApplication.didBecomeActiveNotification)) { _ in
                Task { @MainActor in
                    await authProtection.appBecameActive()
                }
            }
        }
    }
}

class AppState: ObservableObject {
    @Published var exploitStatus: ExploitStatus = .notStarted
    @Published var unsupportedMessage: String?

    var isSupported: Bool { unsupportedMessage == nil }

    func detectSupport() {
        let version = AppInfo.versionTuple
        let supported = ExploitSupportPolicy.isSupported(
            major: version.major,
            minor: version.minor,
            patch: version.patch,
            build: AppInfo.osBuild
        )

#if targetEnvironment(simulator)
        if ProcessInfo.processInfo.arguments.contains("--simulate-access") {
            exploitStatus = .success(method: "Simulator preview")
        }
#endif

        unsupportedMessage = supported ? nil : "iOS \(AppInfo.osVersion) (\(AppInfo.osBuild))"
        if let unsupportedMessage {
            exploitStatus = .unsupported(unsupportedMessage)
        }
    }
}
