# REMOTE cards Apply/Restore

Alteração feita exclusivamente sobre a source REMOTE enviada pelo usuário.

- Remove o Toggle único da tela REMOTE.
- Adiciona dois cards de ação no mesmo estilo do fluxo antigo:
  - `INJETAR` -> chama o caminho de Apply já existente (`RemotePatchRunner.setEnabled(true)` -> `DevicePatchService.apply`).
  - `DESINJETAR (40%)` -> chama o caminho de Restore já existente (`RemotePatchRunner.setEnabled(false)` -> `DevicePatchService.restore`).
- Mantém `remote.3105`, senha, autenticação, vault, backup/receipt e restante da arquitetura da REMOTE intactos.
- O estado aplicado continua derivado do receipt salvo em `PatchSlotBackupRegistry`.
