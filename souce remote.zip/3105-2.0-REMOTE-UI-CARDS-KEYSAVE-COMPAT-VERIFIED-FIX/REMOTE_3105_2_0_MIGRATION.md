# REMOTE -> 3105 2.0 migration

This source keeps the existing REMOTE presentation/authentication layer while moving the compatibility/runtime core to the supplied 3105 2.0 source.

Preserved from REMOTE:
- REMOTE SwiftUI screen and INJETAR / DESINJETAR (40%) cards
- RemoteAuth source, key persistence, manual logout and compact exit icon
- embedded patch/resource vault integration
- REMOTE assets, icon and existing build hardening flow

Taken from 3105 2.0:
- SupportPolicy.swift
- KernelExploit.swift
- FileBrowserMetadata.swift
- ContainerStore.swift
- DevicePatchService.swift
- PatchPackageCodec.swift
- PatchProjectModels.swift
- PatchTransaction.swift
- PatchProjectLibrary.swift
- PatchProjectStore.swift
- PatchWorkspaceService.swift
- Utils.swift
- exploit/*
- kexploit/*

App.swift was merged instead of replaced: REMOTE auth remains fail-closed, and the 3105 2.0 support/compatibility lifecycle is initialized after authorization.

The supplied 3105 2.0 policy is preserved rather than widening version checks artificially.
