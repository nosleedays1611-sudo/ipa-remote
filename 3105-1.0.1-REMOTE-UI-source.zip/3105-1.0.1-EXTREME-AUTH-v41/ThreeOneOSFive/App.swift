import SwiftUI

@main
struct ThreeOneOSFiveApp: App {
    @StateObject private var appState: AppState
    @StateObject private var patchDraftCoordinator: PatchDraftCoordinator
    @StateObject private var fileOperationCoordinator: FileOperationCoordinator
    @StateObject private var authProtection: AuthProtection
    @AppStorage(AppLanguage.storageKey) private var languageCode = AppLanguage.english.rawValue

    private var language: AppLanguage {
        AppLanguage(rawValue: languageCode) ?? .english
    }

    init() {
        // ExternalAuth.dylib is a REQUIRED Mach-O dependency. dyld loads it before
        // Swift reaches this @main App. This is the first application-level work:
        // verify/start auth before constructing any app state or showing ContentView.
        guard AuthDylibLoader.shared.loadAndVerify() else {
            fatalError("Required authentication module failed integrity.")
        }
        EAExternalAuthEnsureStarted()

        _appState = StateObject(wrappedValue: AppState())
        _patchDraftCoordinator = StateObject(wrappedValue: PatchDraftCoordinator())
        _fileOperationCoordinator = StateObject(wrappedValue: FileOperationCoordinator())
        _authProtection = StateObject(wrappedValue: AuthProtection.shared)
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(appState)
                .environmentObject(patchDraftCoordinator)
                .environmentObject(fileOperationCoordinator)
                .environmentObject(authProtection)
                .environment(\.appLanguage, language)
                .environment(\.locale, language.locale)
                .onAppear {
                    appState.detectSupport()
                }
                .onOpenURL { url in
                    patchDraftCoordinator.presentImport(url)
                }
        }
    }
}

class AppState: ObservableObject {
    @Published var exploitStatus: ExploitStatus = .notStarted
    @Published var unsupportedMessage: String?

    var isSupported: Bool { unsupportedMessage == nil }

    func detectSupport() {
        let v = AppInfo.versionTuple
        let supported = ExploitSupportPolicy.isSupported(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
#if targetEnvironment(simulator)
        if ProcessInfo.processInfo.arguments.contains("--simulate-access") {
            exploitStatus = .success(method: "Simulator preview")
        }
#endif

        unsupportedMessage = supported ? nil : "iOS \(AppInfo.osVersion) (\(AppInfo.osBuild))"
        if let unsupportedMessage {
            exploitStatus = .unsupported(unsupportedMessage)
        }
    }
}
