import Foundation
import SwiftUI
import UIKit
import ImageIO

struct ContentView: View {
    @EnvironmentObject private var auth: AuthProtection
    @Environment(\.scenePhase) private var scenePhase

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            RemoteMainView()
                .disabled(!auth.isAuthorized)
                .allowsHitTesting(auth.isAuthorized)

            if !auth.isAuthorized {
                AuthLockOverlay(message: auth.lockMessage, darkMode: true, showSpinner: auth.isChecking)
                    .zIndex(100)
            }
        }
        .environment(\.colorScheme, .dark)
        .preferredColorScheme(.dark)
        .task { await auth.bootstrap() }
        .onChange(of: scenePhase) { phase in
            guard phase == .active else { return }
            Task { @MainActor in await auth.appBecameActive() }
        }
    }
}

private struct RemoteMainView: View {
    @EnvironmentObject private var auth: AuthProtection
    @State private var injected = PatchSlotBackupRegistry.receipt(for: "remote.3105") != nil
    @State private var busy = false
    @State private var message: String?

    private let patchFile = "remote.3105"
    private let patchPassword = "realm"

    var body: some View {
        ZStack {
            RemoteParticleBackground().ignoresSafeArea()

            VStack(spacing: 0) {
                Spacer(minLength: 44)

                RemoteGIFView(assetName: "RemoteGIF")
                    .frame(height: 260)
                    .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(Color.white.opacity(0.9), lineWidth: 1.4))
                    .padding(.horizontal, 30)

                VStack(alignment: .leading, spacing: 14) {
                    Text("REMOTE")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundStyle(.white)

                    HStack(spacing: 14) {
                        VStack(alignment: .leading, spacing: 5) {
                            Text("INJETAR")
                                .font(.system(size: 17, weight: .semibold))
                                .foregroundStyle(.white)
                            Text("Remote iOS")
                                .font(.system(size: 13))
                                .foregroundStyle(.white.opacity(0.48))
                        }
                        Spacer()
                        if busy {
                            ProgressView().tint(.white)
                        } else {
                            Toggle("", isOn: Binding(
                                get: { injected },
                                set: { value in setInjected(value) }
                            ))
                            .labelsHidden()
                            .tint(.white)
                        }
                    }
                    .padding(.horizontal, 18)
                    .frame(height: 82)
                    .background(Color.white.opacity(0.075))
                    .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(Color.white.opacity(0.10), lineWidth: 1))
                }
                .padding(.horizontal, 30)
                .padding(.top, 24)

                Spacer()

                HStack {
                    Spacer()
                    VStack(spacing: 5) {
                        Image(systemName: "square.grid.2x2.fill")
                            .font(.system(size: 20, weight: .semibold))
                        Text("REMOTE")
                            .font(.system(size: 12, weight: .semibold))
                    }
                    .foregroundStyle(.white)
                    Spacer()
                }
                .frame(height: 70)
                .background(Color.white.opacity(0.075))
                .clipShape(Capsule())
                .overlay(Capsule().stroke(Color.white.opacity(0.10), lineWidth: 1))
                .padding(.horizontal, 30)
                .padding(.bottom, 8)
            }
        }
        .alert("REMOTE", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            Button("OK", role: .cancel) { message = nil }
        } message: { Text(message ?? "") }
    }

    private func setInjected(_ value: Bool) {
        guard !busy else { return }
        busy = true
        Task { @MainActor in
            let action: ProtectedAction = value ? .patchApply : .patchRestore
            guard let permit = await auth.permit(for: action), AuthProtection.validatePermit(permit, for: action) else {
                busy = false
                message = "Autenticação obrigatória."
                return
            }
            DispatchQueue.global(qos: .userInitiated).async {
                let result = PatchSlotRunner.setEnabled(value, fileName: patchFile, configuredPassword: patchPassword, permit: permit, action: action)
                DispatchQueue.main.async {
                    busy = false
                    switch result {
                    case .success:
                        injected = value
                        message = value ? "Injetado com sucesso!" : "Desinjetado com sucesso!"
                    case .failure(let error):
                        message = PatchSlotRunner.message(for: error)
                    }
                }
            }
        }
    }
}

private struct RemoteParticleBackground: View {
    private let points: [(Double, Double)] = [
        (0.08,0.16),(0.29,0.12),(0.48,0.19),(0.70,0.10),(0.90,0.20),
        (0.16,0.40),(0.39,0.34),(0.61,0.42),(0.84,0.35),
        (0.09,0.65),(0.31,0.72),(0.52,0.62),(0.73,0.74),(0.92,0.64),
        (0.19,0.90),(0.43,0.84),(0.67,0.92),(0.87,0.86)
    ]

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30.0)) { timeline in
            Canvas { context, size in
                let t = timeline.date.timeIntervalSinceReferenceDate
                let p = points.enumerated().map { i, q -> CGPoint in
                    let dx = sin(t * 0.32 + Double(i) * 1.71) * 13
                    let dy = cos(t * 0.27 + Double(i) * 1.23) * 11
                    return CGPoint(x: size.width * q.0 + dx, y: size.height * q.1 + dy)
                }
                for i in p.indices {
                    for j in (i+1)..<p.count {
                        let d = hypot(p[i].x-p[j].x, p[i].y-p[j].y)
                        if d < 155 {
                            var path = Path(); path.move(to:p[i]); path.addLine(to:p[j])
                            context.stroke(path, with:.color(.white.opacity(max(0.015, 0.11 * (1-d/155)))), lineWidth:0.6)
                        }
                    }
                }
                for point in p {
                    context.fill(Path(ellipseIn:CGRect(x:point.x-1.5,y:point.y-1.5,width:3,height:3)), with:.color(.white.opacity(0.55)))
                }
            }
        }
        .background(Color.black)
    }
}

private struct RemoteGIFView: UIViewRepresentable {
    let assetName: String
    func makeUIView(context: Context) -> UIImageView {
        let v=UIImageView(); v.contentMode = .scaleAspectFill; v.clipsToBounds=true
        if let data=NSDataAsset(name: assetName)?.data, let src=CGImageSourceCreateWithData(data as CFData,nil) {
            var frames:[UIImage]=[]
            for i in 0..<CGImageSourceGetCount(src) { if let cg=CGImageSourceCreateImageAtIndex(src,i,nil) { frames.append(UIImage(cgImage:cg)) } }
            v.image = frames.first
            v.animationImages = frames
            v.animationDuration = Double(frames.count) / 50.0
            v.animationRepeatCount = 0
            v.startAnimating()
        }
        return v
    }
    func updateUIView(_ uiView: UIImageView, context: Context) { if !uiView.isAnimating { uiView.startAnimating() } }
}

private struct AuthLockOverlay: View {
    let message: String
    let darkMode: Bool
    let showSpinner: Bool

    var body: some View {
        ZStack {
            (darkMode ? Color.black.opacity(0.96) : Color(uiColor: .systemBackground).opacity(0.96))
                .ignoresSafeArea()

            VStack(spacing: 14) {
                if showSpinner {
                    ProgressView()
                        .scaleEffect(1.05)
                } else {
                    Image(systemName: "key.fill")
                        .font(.system(size: 20, weight: .semibold))
                        .foregroundStyle(Color(red: 0.58, green: 0.77, blue: 0.94))
                }
                Text("External Auth")
                    .font(.system(size: 19, weight: .semibold))
                Text(message)
                    .font(.system(size: 14))
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 40)
            }
        }
        .allowsHitTesting(true)
    }
}

private struct PatchOption: Identifiable {
    let id: String
    let title: String
    let subtitle: String?
    let patchFile: String
    let patchPassword: String
    let withAntennaPatchFile: String?
    let withAntennaPatchPassword: String?

    init(
        id: String,
        title: String,
        subtitle: String?,
        patchFile: String,
        patchPassword: String,
        withAntennaPatchFile: String? = nil,
        withAntennaPatchPassword: String? = nil
    ) {
        self.id = id
        self.title = title
        self.subtitle = subtitle
        self.patchFile = patchFile
        self.patchPassword = patchPassword
        self.withAntennaPatchFile = withAntennaPatchFile
        self.withAntennaPatchPassword = withAntennaPatchPassword
    }
}

private enum PatchSlots {
    // EDITE SOMENTE os nomes e senhas abaixo.
    // password = "0" significa SEM SENHA.
    static let aimBotEsp = "aim-bot-esp.3105"
    static let aimBotEspPassword = "OG"

    // SLOT NOVO: coloque manualmente este arquivo em ThreeOneOSFive/Patches/.
    // O workflow transforma o .3105 cru no vault protegido durante o build.
    static let aimSilent4 = "aim-silent-4-dedos.3105"
    static let aimSilent4Password = "0"

    // HS ALTO + PESCOÇO: dois patches separados.
    static let hsAltoNeckSemAntena = "hs-alto-neck-sem-antena.3105"
    static let hsAltoNeckSemAntenaPassword = "0"
    static let hsAltoNeckComAntena = "hs-alto-neck-com-antena.3105"
    static let hsAltoNeckComAntenaPassword = "0"

    // HS ALTO: dois patches separados.
    static let hsAltoSemAntena = "hs-alto-sem-antena.3105"
    static let hsAltoSemAntenaPassword = "0"
    static let hsAlto = "hs-alto.3105"
    static let hsAltoPassword = "0"

    // HS PESCOÇO: dois patches separados.
    static let hsNeckSemAntena = "hs-neck-sem-antena.3105"
    static let hsNeckSemAntenaPassword = "0"
    static let hsNeckComAntena = "hs-neck-com-antena.3105"
    static let hsNeckComAntenaPassword = "0"

    // HS PEITO: dois patches separados.
    static let hsPeitoSemAntena = "hs-peito-sem-antena.3105"
    static let hsPeitoSemAntenaPassword = "0"
    static let hsPeito = "hs-peito.3105"
    static let hsPeitoPassword = "0"

    // NO RELOG / HEADSHOTS: slots separados.
    // Coloque manualmente estes .3105 em ThreeOneOSFive/Patches/.
    // Mantêm os mesmos pares sem/com antena da aba Function,
    // acrescentando "-cache" imediatamente antes da extensão.
    static let hsAltoNeckSemAntenaCache = "hs-alto-neck-sem-antena-cache.3105"
    static let hsAltoNeckSemAntenaCachePassword = "0"
    static let hsAltoNeckComAntenaCache = "hs-alto-neck-com-antena-cache.3105"
    static let hsAltoNeckComAntenaCachePassword = "0"

    static let hsAltoSemAntenaCache = "hs-alto-sem-antena-cache.3105"
    static let hsAltoSemAntenaCachePassword = "0"
    static let hsAltoCache = "hs-alto-cache.3105"
    static let hsAltoCachePassword = "0"

    static let hsNeckSemAntenaCache = "hs-neck-sem-antena-cache.3105"
    static let hsNeckSemAntenaCachePassword = "0"
    static let hsNeckComAntenaCache = "hs-neck-com-antena-cache.3105"
    static let hsNeckComAntenaCachePassword = "0"

    static let hsPeitoSemAntenaCache = "hs-peito-sem-antena-cache.3105"
    static let hsPeitoSemAntenaCachePassword = "0"
    static let hsPeitoCache = "hs-peito-cache.3105"
    static let hsPeitoCachePassword = "0"

    // NO RELOG / HS CAVEIRA: slot único, sem seletor de antena.
    static let hsCaveiraCache = "hs-caveira-cache.3105"
    static let hsCaveiraCachePassword = "0"

    // MAGIC BULLET: duas variantes, escolhidas pelo popup sem/com antena.
    // Coloque manualmente os dois .3105 em ThreeOneOSFive/Patches/.
    static let magicBulletSemAntena = "magic-bullet-sem-antena.3105"
    static let magicBulletSemAntenaPassword = "0"
    static let magicBulletComAntena = "magic-bullet-com-antena.3105"
    static let magicBulletComAntenaPassword = "0"

    static let fps120144 = "120-144-fps.3105"
    static let fps120144Password = "OG"

    static let hologramaPreto = "holograma-preto.3105"
    static let hologramaPretoPassword = "0"

    // FREE FIRE MAX / FUNCTION: mesmos esquemas da aba Normal,
    // sem HS Alto e sem os dois AIM 4 Dedos.
    static let hsAltoNeckSemAntenaMax = "hs-alto-neck-sem-antena-max.3105"
    static let hsAltoNeckSemAntenaMaxPassword = "0"
    static let hsAltoNeckComAntenaMax = "hs-alto-neck-com-antena-max.3105"
    static let hsAltoNeckComAntenaMaxPassword = "0"

    static let hsNeckSemAntenaMax = "hs-neck-sem-antena-max.3105"
    static let hsNeckSemAntenaMaxPassword = "0"
    static let hsNeckComAntenaMax = "hs-neck-com-antena-max.3105"
    static let hsNeckComAntenaMaxPassword = "0"

    static let hsPeitoSemAntenaMax = "hs-peito-sem-antena-max.3105"
    static let hsPeitoSemAntenaMaxPassword = "0"
    static let hsPeitoComAntenaMax = "hs-peito-com-antena-max.3105"
    static let hsPeitoComAntenaMaxPassword = "0"

    static let magicBulletSemAntenaMax = "magic-bullet-sem-antena-max.3105"
    static let magicBulletSemAntenaMaxPassword = "0"
    static let magicBulletComAntenaMax = "magic-bullet-com-antena-max.3105"
    static let magicBulletComAntenaMaxPassword = "0"

    static let fps120144Max = "120-144-fps-max.3105"
    static let fps120144MaxPassword = "OG"
    static let hologramaPretoMax = "holograma-preto-max.3105"
    static let hologramaPretoMaxPassword = "0"

    // FREE FIRE MAX / NO RELOG: versões cache, incluindo HS Alto.
    static let hsAltoNeckSemAntenaCacheMax = "hs-alto-neck-sem-antena-cache-max.3105"
    static let hsAltoNeckSemAntenaCacheMaxPassword = "0"
    static let hsAltoSemAntenaCacheMax = "hs-alto-sem-antena-cache-max.3105"
    static let hsAltoSemAntenaCacheMaxPassword = "0"
    static let hsNeckSemAntenaCacheMax = "hs-neck-sem-antena-cache-max.3105"
    static let hsNeckSemAntenaCacheMaxPassword = "0"
    static let hsPeitoSemAntenaCacheMax = "hs-peito-sem-antena-cache-max.3105"
    static let hsPeitoSemAntenaCacheMaxPassword = "0"
    static let hsCaveiraCacheMax = "hs-caveira-cache-max.3105"
    static let hsCaveiraCacheMaxPassword = "0"

    // TEXTURAS: Normal usa 1-5. No Max usa 4-5.
    static let textura1 = "textura-1.3105"
    static let textura1Password = "0"
    static let textura2 = "textura-2.3105"
    static let textura2Password = "0"
    static let textura3 = "textura-3.3105"
    static let textura3Password = "0"
    static let textura4 = "textura-4.3105"
    static let textura4Password = "0"
    static let textura5 = "textura-5.3105"
    static let textura5Password = "0"
    static let textura4Max = "textura-4-max.3105"
    static let textura4MaxPassword = "0"
    static let textura5Max = "textura-5-max.3105"
    static let textura5MaxPassword = "0"
}

private enum AntennaChoice {
    case withAntenna
    case withoutAntenna
}

private struct RuntimePatchConfig {
    let fileName: String
    let password: String
}

private enum PatchSelectionRules {
    static let headshotIDs: Set<String> = [
        "alto-pescoco",
        "alto",
        "pescoco",
        "peito",
        "caveira"
    ]

    static let aimIDs: Set<String> = [
        "aimbot-esp",
        "aim-silent-4-dedos"
    ]
    static let hologramID = "holograma-preto"

    static func isHeadshot(_ id: String) -> Bool {
        headshotIDs.contains(id)
    }

    static func isAim(_ id: String) -> Bool {
        aimIDs.contains(id)
    }

    // Combinações permitidas:
    // - uma opção sozinha;
    // - um único AIM + um único HS;
    // - HOLOGRAMA GUNS + um único HS.
    // Dois HS, dois AIMs ou AIM + HOLOGRAMA nunca permanecem ativos juntos.
    static func canEnable(_ id: String, current: Set<String>) -> Bool {
        let others = current.subtracting(Set([id]))
        guard !others.isEmpty else { return true }

        if isHeadshot(id) {
            let nonHeadshots = others.subtracting(headshotIDs)
            if nonHeadshots.isEmpty { return true }
            return nonHeadshots.count == 1 &&
                (nonHeadshots.isSubset(of: aimIDs) || nonHeadshots == Set([hologramID]))
        }

        if isAim(id) {
            return others.count == 1 && others.isSubset(of: headshotIDs)
        }

        if id == hologramID {
            return others.count == 1 && others.isSubset(of: headshotIDs)
        }

        return false
    }
}

private struct ExternalFunctionsView: View {
    @EnvironmentObject private var auth: AuthProtection
    let darkMode: Bool
    @State private var game = 0
    @State private var enabledNormal: Set<String> = []
    @State private var enabledMax: Set<String> = []

    private let aimEspNormal = [
        PatchOption(id: "aimbot-esp", title: "Aim Bot + Esp 4 Dedos", subtitle: nil, patchFile: PatchSlots.aimBotEsp, patchPassword: PatchSlots.aimBotEspPassword),
        PatchOption(id: "aim-silent-4-dedos", title: "Aim Silent + 4 Dedos", subtitle: nil, patchFile: PatchSlots.aimSilent4, patchPassword: PatchSlots.aimSilent4Password)
    ]

    private let headshotsNormal = [
        PatchOption(id: "alto-pescoco", title: "Hs Alto + Pescoço", subtitle: "Hs Acima da Cabeça e no Pescoço.", patchFile: PatchSlots.hsAltoNeckSemAntena, patchPassword: PatchSlots.hsAltoNeckSemAntenaPassword, withAntennaPatchFile: PatchSlots.hsAltoNeckComAntena, withAntennaPatchPassword: PatchSlots.hsAltoNeckComAntenaPassword),
        PatchOption(id: "alto", title: "Hs Alto", subtitle: "Hs Acima da Cabeça.", patchFile: PatchSlots.hsAltoSemAntena, patchPassword: PatchSlots.hsAltoSemAntenaPassword, withAntennaPatchFile: PatchSlots.hsAlto, withAntennaPatchPassword: PatchSlots.hsAltoPassword),
        PatchOption(id: "pescoco", title: "Hs Pescoco", subtitle: "Hs Apenas no Pescoço do inimigo.", patchFile: PatchSlots.hsNeckSemAntena, patchPassword: PatchSlots.hsNeckSemAntenaPassword, withAntennaPatchFile: PatchSlots.hsNeckComAntena, withAntennaPatchPassword: PatchSlots.hsNeckComAntenaPassword),
        PatchOption(id: "peito", title: "Hs Peito", subtitle: "Hs No Peito do inimigo.", patchFile: PatchSlots.hsPeitoSemAntena, patchPassword: PatchSlots.hsPeitoSemAntenaPassword, withAntennaPatchFile: PatchSlots.hsPeito, withAntennaPatchPassword: PatchSlots.hsPeitoPassword),
        PatchOption(id: "magic-bullet", title: "Magic Bullet", subtitle: "Bala magica", patchFile: PatchSlots.magicBulletSemAntena, patchPassword: PatchSlots.magicBulletSemAntenaPassword, withAntennaPatchFile: PatchSlots.magicBulletComAntena, withAntennaPatchPassword: PatchSlots.magicBulletComAntenaPassword),
        PatchOption(id: "120-144-fps", title: "120/144 FPS", subtitle: "Força 120/144 Fps o seu Jogo.", patchFile: PatchSlots.fps120144, patchPassword: PatchSlots.fps120144Password)
    ]

    // MAX replica os esquemas da Function Normal, mas sem HS Alto e sem AIM 4 Dedos.
    private let headshotsMax = [
        PatchOption(id: "alto-pescoco", title: "Hs Alto + Pescoço", subtitle: "Hs Acima da Cabeça e no Pescoço.", patchFile: PatchSlots.hsAltoNeckSemAntenaMax, patchPassword: PatchSlots.hsAltoNeckSemAntenaMaxPassword, withAntennaPatchFile: PatchSlots.hsAltoNeckComAntenaMax, withAntennaPatchPassword: PatchSlots.hsAltoNeckComAntenaMaxPassword),
        PatchOption(id: "pescoco", title: "Hs Pescoco", subtitle: "Hs Apenas no Pescoço do inimigo.", patchFile: PatchSlots.hsNeckSemAntenaMax, patchPassword: PatchSlots.hsNeckSemAntenaMaxPassword, withAntennaPatchFile: PatchSlots.hsNeckComAntenaMax, withAntennaPatchPassword: PatchSlots.hsNeckComAntenaMaxPassword),
        PatchOption(id: "peito", title: "Hs Peito", subtitle: "Hs No Peito do inimigo.", patchFile: PatchSlots.hsPeitoSemAntenaMax, patchPassword: PatchSlots.hsPeitoSemAntenaMaxPassword, withAntennaPatchFile: PatchSlots.hsPeitoComAntenaMax, withAntennaPatchPassword: PatchSlots.hsPeitoComAntenaMaxPassword),
        PatchOption(id: "magic-bullet", title: "Magic Bullet", subtitle: "Bala magica", patchFile: PatchSlots.magicBulletSemAntenaMax, patchPassword: PatchSlots.magicBulletSemAntenaMaxPassword, withAntennaPatchFile: PatchSlots.magicBulletComAntenaMax, withAntennaPatchPassword: PatchSlots.magicBulletComAntenaMaxPassword),
        PatchOption(id: "120-144-fps", title: "120/144 FPS", subtitle: "Força 120/144 Fps o seu Jogo.", patchFile: PatchSlots.fps120144Max, patchPassword: PatchSlots.fps120144MaxPassword)
    ]

    private let hologramsNormal = [
        PatchOption(id: "holograma-preto", title: "Holograma Guns", subtitle: "holograma nas armas", patchFile: PatchSlots.hologramaPreto, patchPassword: PatchSlots.hologramaPretoPassword)
    ]

    private let hologramsMax = [
        PatchOption(id: "holograma-preto", title: "Holograma Guns", subtitle: "holograma nas armas", patchFile: PatchSlots.hologramaPretoMax, patchPassword: PatchSlots.hologramaPretoMaxPassword)
    ]

    var body: some View {
        GeometryReader { proxy in
            VStack(alignment: .leading, spacing: 0) {
                HStack(spacing: 12) {
                    GameButton("Free Fire Normal", selected: game == 0, darkMode: darkMode) { requestGame(0) }
                    GameButton("Free Fire Max", selected: game == 1, darkMode: darkMode) { requestGame(1) }
                }

                if game == 0 {
                    SectionBlock(title: "AIM / ESP", rows: aimEspNormal, enabled: $enabledNormal, darkMode: darkMode, manualControls: false, cacheHeadshots: false).padding(.top, 24)
                    SectionBlock(title: "HEADSHOTS", rows: headshotsNormal, enabled: $enabledNormal, darkMode: darkMode, manualControls: true, cacheHeadshots: false).padding(.top, 24)
                    SectionBlock(title: "HOLOGRAMA", rows: hologramsNormal, enabled: $enabledNormal, darkMode: darkMode, manualControls: false, cacheHeadshots: false).padding(.top, 24)
                } else {
                    // Free Fire Max / Function: opções mantidas visíveis, porém totalmente desabilitadas.
                    SectionBlock(title: "HEADSHOTS", rows: headshotsMax, enabled: $enabledMax, darkMode: darkMode, manualControls: true, cacheHeadshots: false)
                        .padding(.top, 24)
                        .disabled(true)
                        .allowsHitTesting(false)
                        .opacity(0.32)

                    SectionBlock(title: "HOLOGRAMA", rows: hologramsMax, enabled: $enabledMax, darkMode: darkMode, manualControls: false, cacheHeadshots: false)
                        .padding(.top, 24)
                        .disabled(true)
                        .allowsHitTesting(false)
                        .opacity(0.32)
                }
            }
            .padding(.horizontal, 22)
            .frame(width: proxy.size.width)
            .frame(minHeight: proxy.size.height, alignment: .center)
        }
    }

    private func requestGame(_ newGame: Int) {
        Task { @MainActor in
            guard let permit = await auth.permit(for: .gameSelection),
                  AuthProtection.validatePermit(permit, for: .gameSelection) else { return }
            withAnimation(.easeOut(duration: 0.14)) {
                game = newGame
            }
        }
    }
}

private struct NoRelogFunctionsView: View {
    @EnvironmentObject private var auth: AuthProtection
    let darkMode: Bool
    @State private var game = 0
    @State private var enabledNormal: Set<String> = []
    @State private var enabledMax: Set<String> = []

    // NO RELOG usa somente um arquivo por HS, direto pelo switch.
    private let headshotsNormal = [
        PatchOption(id: "alto-pescoco", title: "Hs Alto + Pescoço", subtitle: "Hs Acima da Cabeça e no Pescoço.", patchFile: PatchSlots.hsAltoNeckSemAntenaCache, patchPassword: PatchSlots.hsAltoNeckSemAntenaCachePassword),
        PatchOption(id: "alto", title: "Hs Alto", subtitle: "Hs Acima da Cabeça.", patchFile: PatchSlots.hsAltoSemAntenaCache, patchPassword: PatchSlots.hsAltoSemAntenaCachePassword),
        PatchOption(id: "pescoco", title: "Hs Pescoco", subtitle: "Hs Apenas no Pescoço do inimigo.", patchFile: PatchSlots.hsNeckSemAntenaCache, patchPassword: PatchSlots.hsNeckSemAntenaCachePassword),
        PatchOption(id: "peito", title: "Hs Peito", subtitle: "Hs No Peito do inimigo.", patchFile: PatchSlots.hsPeitoSemAntenaCache, patchPassword: PatchSlots.hsPeitoSemAntenaCachePassword),
        PatchOption(id: "caveira", title: "Hs Caveira", subtitle: "Hs Caveira", patchFile: PatchSlots.hsCaveiraCache, patchPassword: PatchSlots.hsCaveiraCachePassword)
    ]

    // MAX mantém o mesmo comportamento direto/sem popup e inclui HS Alto.
    private let headshotsMax = [
        PatchOption(id: "alto-pescoco", title: "Hs Alto + Pescoço", subtitle: "Hs Acima da Cabeça e no Pescoço.", patchFile: PatchSlots.hsAltoNeckSemAntenaCacheMax, patchPassword: PatchSlots.hsAltoNeckSemAntenaCacheMaxPassword),
        PatchOption(id: "alto", title: "Hs Alto", subtitle: "Hs Acima da Cabeça.", patchFile: PatchSlots.hsAltoSemAntenaCacheMax, patchPassword: PatchSlots.hsAltoSemAntenaCacheMaxPassword),
        PatchOption(id: "pescoco", title: "Hs Pescoco", subtitle: "Hs Apenas no Pescoço do inimigo.", patchFile: PatchSlots.hsNeckSemAntenaCacheMax, patchPassword: PatchSlots.hsNeckSemAntenaCacheMaxPassword),
        PatchOption(id: "peito", title: "Hs Peito", subtitle: "Hs No Peito do inimigo.", patchFile: PatchSlots.hsPeitoSemAntenaCacheMax, patchPassword: PatchSlots.hsPeitoSemAntenaCacheMaxPassword),
        PatchOption(id: "caveira", title: "Hs Caveira", subtitle: "Hs Caveira", patchFile: PatchSlots.hsCaveiraCacheMax, patchPassword: PatchSlots.hsCaveiraCacheMaxPassword)
    ]

    private let hologramsNormal = [
        PatchOption(id: "holograma-preto", title: "Holograma Guns", subtitle: "holograma nas armas", patchFile: PatchSlots.hologramaPreto, patchPassword: PatchSlots.hologramaPretoPassword)
    ]

    private let hologramsMax = [
        PatchOption(id: "holograma-preto", title: "Holograma Guns", subtitle: "holograma nas armas", patchFile: PatchSlots.hologramaPretoMax, patchPassword: PatchSlots.hologramaPretoMaxPassword)
    ]

    var body: some View {
        GeometryReader { proxy in
            VStack(alignment: .leading, spacing: 0) {
                HStack(spacing: 12) {
                    GameButton("Free Fire Normal", selected: game == 0, darkMode: darkMode) { requestGame(0) }
                    GameButton("Free Fire Max", selected: game == 1, darkMode: darkMode) { requestGame(1) }
                }

                HStack(spacing: 6) {
                    Text("Sem antena")
                        .font(.system(size: 13.5, weight: .semibold))
                        .foregroundStyle(Color(red:0.60,green:0.77,blue:0.94))

                    Text("(com risco)")
                        .font(.system(size: 11.5, weight: .medium))
                        .foregroundStyle(darkMode ? Color.white.opacity(0.48) : Color.black.opacity(0.45))
                }
                .frame(maxWidth: .infinity)
                .frame(height: 34)
                .background(
                    RoundedRectangle(cornerRadius: 11)
                        .fill(darkMode ? Color.white.opacity(0.035) : Color.black.opacity(0.035))
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 11)
                        .stroke(Color(red:0.58,green:0.78,blue:0.98).opacity(0.55), lineWidth: 1)
                )
                .padding(.top, 24)

                if game == 0 {
                    SectionBlock(title: "HEADSHOTS", rows: headshotsNormal, enabled: $enabledNormal, darkMode: darkMode, manualControls: false, cacheHeadshots: true).padding(.top, 20)
                    SectionBlock(title: "HOLOGRAMA", rows: hologramsNormal, enabled: $enabledNormal, darkMode: darkMode, manualControls: false, cacheHeadshots: false).padding(.top, 22)
                } else {
                    SectionBlock(title: "HEADSHOTS", rows: headshotsMax, enabled: $enabledMax, darkMode: darkMode, manualControls: false, cacheHeadshots: true).padding(.top, 20)
                    SectionBlock(title: "HOLOGRAMA", rows: hologramsMax, enabled: $enabledMax, darkMode: darkMode, manualControls: false, cacheHeadshots: false).padding(.top, 22)
                }
            }
            .padding(.horizontal, 22)
            .frame(width: proxy.size.width)
            .frame(minHeight: proxy.size.height, alignment: .center)
        }
    }

    private func requestGame(_ newGame: Int) {
        Task { @MainActor in
            guard let permit = await auth.permit(for: .gameSelection),
                  AuthProtection.validatePermit(permit, for: .gameSelection) else { return }
            withAnimation(.easeOut(duration: 0.14)) {
                game = newGame
            }
        }
    }
}

private struct GameButton: View {
    let title: String; let selected: Bool; let darkMode: Bool; let action: () -> Void
    init(_ title: String, selected: Bool, darkMode: Bool, action: @escaping () -> Void) {
        self.title=title; self.selected=selected; self.darkMode=darkMode; self.action=action
    }
    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 14.5, weight: .semibold))
                .foregroundStyle(darkMode ? .white : .black)
                .frame(maxWidth: .infinity).frame(height: 54)
                .overlay(RoundedRectangle(cornerRadius: 14).stroke(
                    selected ? Color(red:0.58,green:0.78,blue:0.98) :
                        (darkMode ? Color.white.opacity(0.25) : Color.black.opacity(0.20)), lineWidth: 1.5))
        }.buttonStyle(.plain)
    }
}

private struct SectionBlock: View {
    @EnvironmentObject private var auth: AuthProtection
    let title: String
    let rows: [PatchOption]
    @Binding var enabled: Set<String>
    let darkMode: Bool
    let manualControls: Bool
    let cacheHeadshots: Bool

    @State private var busy: Set<String> = []
    @State private var successPresented = false
    @State private var successMessage = "Ativado com sucesso!"
    @State private var errorMessage: String?
    @State private var antennaPromptRow: PatchOption?
    @State private var antennaChoices: [String: AntennaChoice] = [:]
    @State private var crouchInstructionPresented = false

    var body: some View {
        VStack(alignment: .leading, spacing: 17) {
            Text(title)
                .font(.system(size: 14, weight: .bold))
                .foregroundStyle(Color(red:0.60,green:0.77,blue:0.94))

            ForEach(rows) { row in
                VStack(alignment: .leading, spacing: 12) {
                    HStack(spacing: 12) {
                        VStack(alignment: .leading, spacing: 3) {
                            Text(row.title)
                                .font(.system(size: 16, weight: .medium))
                                .foregroundStyle(darkMode ? .white : .black)

                            if let subtitle = displaySubtitle(for: row), !subtitle.isEmpty {
                                Text(subtitle)
                                    .font(.system(size: 12.5, weight: .regular))
                                    .foregroundStyle(
                                        darkMode ? Color.white.opacity(0.46) : Color.black.opacity(0.46)
                                    )
                            }
                        }

                        Spacer(minLength: 8)

                        if busy.contains(row.id) {
                            ProgressView().scaleEffect(0.85)
                        }

                        Toggle("", isOn: Binding(
                            get: { enabled.contains(row.id) },
                            set: { on in
                                handleToggle(row: row, enabledState: on)
                            }
                        ))
                        .labelsHidden()
                        .scaleEffect(0.88)
                        .disabled(busy.contains(row.id))
                    }
                    .frame(minHeight: 36)

                    if manualControls && row.id != "120-144-fps" && enabled.contains(row.id) && !isOptionDisabled(row) {
                        HStack(spacing: 12) {
                            actionCard("INJETAR (40%)") {
                                runManual(row: row, apply: true)
                            }
                            actionCard("LOBBY") {
                                runManual(row: row, apply: false)
                            }
                        }
                        .padding(.bottom, 4)
                    }
                }
                .disabled(isOptionDisabled(row))
                .opacity(isOptionDisabled(row) ? 0.32 : 1.0)
                .allowsHitTesting(!isOptionDisabled(row))
            }
        }
        .alert(
            "Ativar antena?",
            isPresented: Binding(
                get: { antennaPromptRow != nil },
                set: { if !$0 { antennaPromptRow = nil } }
            ),
            presenting: antennaPromptRow
        ) { row in
            Button("sem") {
                confirmAntennaChoice(.withoutAntenna, for: row)
            }
            .disabled(isWithoutAntennaDisabled(row))

            Button("com") {
                confirmAntennaChoice(.withAntenna, for: row)
            }
        } message: { _ in
            Text("Escolha qual versão deseja usar.")
        }
        .alert("Aviso", isPresented: $crouchInstructionPresented) {
            Button("OK") { }
        } message: {
            Text("Agache 2 vezes para alterar o aimbot")
        }
        .alert("Sucesso", isPresented: $successPresented) {
            Button("OK") { }
        } message: {
            Text(successMessage)
        }
        .alert("Canva", isPresented: Binding(
            get: { errorMessage != nil },
            set: { if !$0 { errorMessage = nil } }
        )) {
            Button("OK") { errorMessage = nil }
        } message: {
            Text(errorMessage ?? "")
        }
    }

    private func actionCard(_ title: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 13.5, weight: .bold))
                .foregroundStyle(.black)
                .frame(maxWidth: .infinity)
                .frame(height: 44)
                .background(Color.white)
                .clipShape(RoundedRectangle(cornerRadius: 11))
        }
        .buttonStyle(.plain)
    }

    private func handleToggle(row: PatchOption, enabledState: Bool) {
        guard !busy.contains(row.id), !isOptionDisabled(row) else { return }

        if enabledState && PatchSelectionRules.isHeadshot(row.id) {
            if cacheHeadshots {
                prepareDirectHeadshot(row)
            } else {
                prepareHeadshotSelection(row)
            }
            return
        }

        // Na aba No Relog os HEADSHOTS usam um único arquivo por opção.
        // Desligar o switch restaura exatamente o arquivo aplicado.
        if !enabledState && cacheHeadshots && PatchSelectionRules.isHeadshot(row.id) {
            restoreDirectHeadshot(row)
            return
        }

        if enabledState && !PatchSelectionRules.canEnable(row.id, current: enabled) {
            errorMessage = combinationErrorMessage
            return
        }

        // AIM BOT + ESP 4 DEDOS: show the crouch instruction immediately
        // when the user turns the switch on. Presenting it here avoids losing
        // the alert during the asynchronous authorization/state update.
        if enabledState && row.id == "aimbot-esp" {
            crouchInstructionPresented = true
        }

        // MAGIC BULLET usa o mesmo popup sem/com antena dos HS, mas mantém
        // as regras de combinação que já existiam para ele.
        if enabledState && row.id == "magic-bullet" && requiresAntennaChoice(row) {
            Task { @MainActor in
                busy.insert(row.id)
                defer { busy.remove(row.id) }

                guard let permit = await auth.permit(for: .patchToggle),
                      AuthProtection.validatePermit(permit, for: .patchToggle) else {
                    errorMessage = "Autenticação obrigatória. Valide sua key novamente."
                    return
                }

                antennaPromptRow = row
            }
            return
        }

        if manualControls && row.id != "120-144-fps" {
            if !enabledState, appliedConfig(for: row) != nil {
                // Turning a manually injected option off must not strand its backup.
                // Use the same restore path as LOBBY.
                runManual(row: row, apply: false)
                return
            }

            Task { @MainActor in
                busy.insert(row.id)
                defer { busy.remove(row.id) }

                guard let permit = await auth.permit(for: .patchToggle),
                      AuthProtection.validatePermit(permit, for: .patchToggle) else {
                    errorMessage = "Autenticação obrigatória. Valide sua key novamente."
                    return
                }

                if enabledState {
                    enabled.insert(row.id)
                } else {
                    enabled.remove(row.id)
                    if requiresAntennaChoice(row) {
                        antennaChoices.removeValue(forKey: row.id)
                    }
                }
            }
        } else {
            run(row: row, enabledState: enabledState)
        }
    }

    private func prepareDirectHeadshot(_ row: PatchOption) {
        guard PatchSelectionRules.isHeadshot(row.id), !busy.contains(row.id) else { return }

        Task { @MainActor in
            let previousRows = rows.filter { candidate in
                candidate.id != row.id &&
                PatchSelectionRules.isHeadshot(candidate.id) &&
                (enabled.contains(candidate.id) || appliedConfig(for: candidate) != nil)
            }

            busy.insert(row.id)
            previousRows.forEach { busy.insert($0.id) }
            defer {
                busy.remove(row.id)
                previousRows.forEach { busy.remove($0.id) }
            }

            guard let permit = await auth.permit(for: .patchToggle),
                  AuthProtection.validatePermit(permit, for: .patchToggle) else {
                errorMessage = "Autenticação obrigatória. Valide sua key novamente."
                return
            }

            // Mantém apenas um HS ativo na aba No Relog.
            for previous in previousRows {
                if let config = appliedConfig(for: previous) {
                    let restoreResult = await performPatchOperation(
                        false,
                        config: config,
                        permit: permit,
                        action: .patchToggle
                    )
                    if case .failure(let error) = restoreResult {
                        errorMessage = PatchSlotRunner.message(for: error)
                        return
                    }
                }
                enabled.remove(previous.id)
            }

            let config = RuntimePatchConfig(fileName: row.patchFile, password: row.patchPassword)
            let result = await performPatchOperation(
                true,
                config: config,
                permit: permit,
                action: .patchToggle
            )

            switch result {
            case .success:
                enabled.insert(row.id)
                successMessage = "Ativado com sucesso!"
                successPresented = true
            case .failure(let error):
                errorMessage = PatchSlotRunner.message(for: error)
            }
        }
    }

    private func restoreDirectHeadshot(_ row: PatchOption) {
        guard !busy.contains(row.id) else { return }

        guard let config = appliedConfig(for: row) ?? runtimeConfig(for: row, restoring: true) else {
            enabled.remove(row.id)
            antennaChoices.removeValue(forKey: row.id)
            return
        }

        busy.insert(row.id)

        Task { @MainActor in
            guard let permit = await auth.permit(for: .patchToggle),
                  AuthProtection.validatePermit(permit, for: .patchToggle) else {
                busy.remove(row.id)
                errorMessage = "Autenticação obrigatória. Valide sua key novamente."
                return
            }

            let result = await performPatchOperation(
                false,
                config: config,
                permit: permit,
                action: .patchToggle
            )

            busy.remove(row.id)

            switch result {
            case .success:
                enabled.remove(row.id)
                antennaChoices.removeValue(forKey: row.id)
                successMessage = "Desinjetado com sucesso!"
                successPresented = true
            case .failure(let error):
                errorMessage = PatchSlotRunner.message(for: error)
            }
        }
    }

    private func prepareHeadshotSelection(_ row: PatchOption) {
        guard PatchSelectionRules.isHeadshot(row.id), !busy.contains(row.id) else { return }

        guard PatchSelectionRules.canEnable(row.id, current: enabled) else {
            errorMessage = combinationErrorMessage
            return
        }

        Task { @MainActor in
            let previousRows = rows.filter { candidate in
                candidate.id != row.id &&
                PatchSelectionRules.isHeadshot(candidate.id) &&
                (enabled.contains(candidate.id) || appliedConfig(for: candidate) != nil)
            }

            busy.insert(row.id)
            previousRows.forEach { busy.insert($0.id) }
            defer {
                busy.remove(row.id)
                previousRows.forEach { busy.remove($0.id) }
            }

            guard let togglePermit = await auth.permit(for: .patchToggle),
                  AuthProtection.validatePermit(togglePermit, for: .patchToggle) else {
                errorMessage = "Autenticação obrigatória. Valide sua key novamente."
                return
            }

            // One HS at a time. If the previous HS was already injected, restore
            // its exact receipt first so the UI and the real files never diverge.
            for previous in previousRows {
                if let config = appliedConfig(for: previous) {
                    guard let restorePermit = await auth.permit(for: .patchRestore),
                          AuthProtection.validatePermit(restorePermit, for: .patchRestore) else {
                        errorMessage = "Autenticação obrigatória. Valide sua key novamente."
                        return
                    }

                    let result = await performPatchOperation(
                        false,
                        config: config,
                        permit: restorePermit,
                        action: .patchRestore
                    )

                    if case .failure(let error) = result {
                        errorMessage = PatchSlotRunner.message(for: error)
                        return
                    }
                }

                enabled.remove(previous.id)
                antennaChoices.removeValue(forKey: previous.id)
            }

            if requiresAntennaChoice(row) {
                // Keep the new switch OFF until sem/com is chosen.
                antennaPromptRow = row
            } else {
                enabled.insert(row.id)
            }
        }
    }

    private func confirmAntennaChoice(_ choice: AntennaChoice, for row: PatchOption) {
        guard requiresAntennaChoice(row), !busy.contains(row.id) else { return }

        if choice == .withoutAntenna && isWithoutAntennaDisabled(row) {
            return
        }

        guard PatchSelectionRules.canEnable(row.id, current: enabled) else {
            errorMessage = combinationErrorMessage
            return
        }

        Task { @MainActor in
            busy.insert(row.id)
            defer { busy.remove(row.id) }

            guard let permit = await auth.permit(for: .patchToggle),
                  AuthProtection.validatePermit(permit, for: .patchToggle) else {
                errorMessage = "Autenticação obrigatória. Valide sua key novamente."
                return
            }

            // If a variant is currently applied, do not let the UI silently switch
            // to the other file before the original backup has been restored.
            if let applied = appliedVariant(for: row), applied != choice {
                errorMessage = manualControls
                    ? "Use LOBBY para restaurar a opção anterior antes de trocar sem/com."
                    : "Desative a opção atual antes de trocar sem/com."
                return
            }

            antennaChoices[row.id] = choice

            if cacheHeadshots && !manualControls {
                guard let config = antennaConfig(for: row, choice: choice) else {
                    antennaChoices.removeValue(forKey: row.id)
                    errorMessage = "Patch não encontrado."
                    return
                }

                let result = await performPatchOperation(
                    true,
                    config: config,
                    permit: permit,
                    action: .patchToggle
                )

                switch result {
                case .success:
                    enabled.insert(row.id)
                    successMessage = "Ativado com sucesso!"
                    successPresented = true
                case .failure(let error):
                    antennaChoices.removeValue(forKey: row.id)
                    errorMessage = PatchSlotRunner.message(for: error)
                    return
                }
            } else {
                enabled.insert(row.id)
            }

            antennaPromptRow = nil

            if row.id == "alto-pescoco" && choice == .withAntenna {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
                    crouchInstructionPresented = true
                }
            }
        }
    }

    private func run(row: PatchOption, enabledState: Bool) {
        guard !busy.contains(row.id) else { return }
        busy.insert(row.id)

        Task { @MainActor in
            guard let permit = await auth.permit(for: .patchToggle),
                  AuthProtection.validatePermit(permit, for: .patchToggle) else {
                busy.remove(row.id)
                errorMessage = "Autenticação obrigatória. Valide sua key novamente."
                return
            }

            DispatchQueue.global(qos: .userInitiated).async {
                let result = PatchSlotRunner.setEnabled(
                    enabledState,
                    fileName: row.patchFile,
                    configuredPassword: row.patchPassword,
                    permit: permit,
                    action: .patchToggle
                )
                DispatchQueue.main.async {
                    busy.remove(row.id)
                    switch result {
                    case .success:
                        if enabledState {
                            enabled.insert(row.id)
                            successMessage = row.id == "120-144-fps" ? "Ativado. Feche seu jogo e abra de novo." : "Ativado com sucesso!"
                            successPresented = true
                        }
                        else {
                            enabled.remove(row.id)
                            if requiresAntennaChoice(row) {
                                antennaChoices.removeValue(forKey: row.id)
                            }
                            successMessage = "Desinjetado com sucesso!"
                            successPresented = true
                        }
                    case .failure(let error):
                        errorMessage = PatchSlotRunner.message(for: error)
                    }
                }
            }
        }
    }

    private func runManual(row: PatchOption, apply: Bool) {
        guard !busy.contains(row.id) else { return }

        guard let config = runtimeConfig(for: row, restoring: !apply) else {
            errorMessage = requiresAntennaChoice(row)
                ? "Selecione sem ou com antena primeiro."
                : "Patch não encontrado."
            return
        }

        if apply, requiresAntennaChoice(row), let applied = appliedVariant(for: row) {
            let selected = antennaChoices[row.id]
            if selected != applied {
                errorMessage = "Use LOBBY para restaurar a opção anterior antes de trocar sem/com."
                return
            }
        }

        busy.insert(row.id)

        Task { @MainActor in
            let action: ProtectedAction = apply ? .patchApply : .patchRestore
            guard let permit = await auth.permit(for: action),
                  AuthProtection.validatePermit(permit, for: action) else {
                busy.remove(row.id)
                errorMessage = "Autenticação obrigatória. Valide sua key novamente."
                return
            }

            DispatchQueue.global(qos: .userInitiated).async {
                let result = PatchSlotRunner.setEnabled(
                    apply,
                    fileName: config.fileName,
                    configuredPassword: config.password,
                    permit: permit,
                    action: action
                )
                DispatchQueue.main.async {
                    busy.remove(row.id)
                    switch result {
                    case .success:
                        if apply {
                            successMessage = "Ativado com sucesso!"
                            successPresented = true
                        } else {
                            enabled.remove(row.id)
                            if requiresAntennaChoice(row) {
                                antennaChoices.removeValue(forKey: row.id)
                            }
                            successMessage = "Desinjetado com sucesso!"
                            successPresented = true
                        }
                    case .failure(let error):
                        errorMessage = PatchSlotRunner.message(for: error)
                    }
                }
            }
        }
    }

    private var combinationErrorMessage: String {
        "Combinação não permitida. Use apenas um AIM e um HS por vez; um AIM ou HOLOGRAMA GUNS pode ser usado junto de um único HS."
    }

    private func appliedConfig(for row: PatchOption) -> RuntimePatchConfig? {
        if requiresAntennaChoice(row) {
            guard let applied = appliedVariant(for: row) else { return nil }
            return antennaConfig(for: row, choice: applied)
        }

        let config = RuntimePatchConfig(fileName: row.patchFile, password: row.patchPassword)
        return PatchSlotBackupRegistry.receipt(for: config.fileName) == nil ? nil : config
    }

    private func performPatchOperation(
        _ enabledState: Bool,
        config: RuntimePatchConfig,
        permit: ActionPermit,
        action: ProtectedAction
    ) async -> Result<String, Error> {
        await withCheckedContinuation { continuation in
            DispatchQueue.global(qos: .userInitiated).async {
                let result = PatchSlotRunner.setEnabled(
                    enabledState,
                    fileName: config.fileName,
                    configuredPassword: config.password,
                    permit: permit,
                    action: action
                )
                continuation.resume(returning: result)
            }
        }
    }

    private func requiresAntennaChoice(_ row: PatchOption) -> Bool {
        guard !cacheHeadshots else { return false }
        return row.id == "alto-pescoco" || row.id == "alto" || row.id == "pescoco" || row.id == "peito" || row.id == "magic-bullet"
    }

    private func isWithoutAntennaDisabled(_ row: PatchOption) -> Bool {
        false
    }

    private func isOptionDisabled(_ row: PatchOption) -> Bool {
        false
    }

    private func displaySubtitle(for row: PatchOption) -> String? {
        row.subtitle
    }

    private func runtimeConfig(for row: PatchOption, restoring: Bool) -> RuntimePatchConfig? {
        guard requiresAntennaChoice(row) else {
            return RuntimePatchConfig(fileName: row.patchFile, password: row.patchPassword)
        }

        if restoring, let applied = appliedVariant(for: row) {
            return antennaConfig(for: row, choice: applied)
        }

        guard let choice = antennaChoices[row.id] else { return nil }
        return antennaConfig(for: row, choice: choice)
    }

    private func antennaConfig(for row: PatchOption, choice: AntennaChoice) -> RuntimePatchConfig? {
        // Cada linha carrega os próprios arquivos sem/com antena. Assim Normal e
        // Max podem usar slots diferentes sem alterar o comportamento do popup.
        switch choice {
        case .withoutAntenna:
            return RuntimePatchConfig(fileName: row.patchFile, password: row.patchPassword)
        case .withAntenna:
            guard let fileName = row.withAntennaPatchFile,
                  let password = row.withAntennaPatchPassword else { return nil }
            return RuntimePatchConfig(fileName: fileName, password: password)
        }
    }

    private func appliedVariant(for row: PatchOption) -> AntennaChoice? {
        guard requiresAntennaChoice(row) else { return nil }

        if let withConfig = antennaConfig(for: row, choice: .withAntenna),
           PatchSlotBackupRegistry.receipt(for: withConfig.fileName) != nil {
            return .withAntenna
        }

        if let withoutConfig = antennaConfig(for: row, choice: .withoutAntenna),
           PatchSlotBackupRegistry.receipt(for: withoutConfig.fileName) != nil {
            return .withoutAntenna
        }

        return nil
    }

}

private enum PatchSlotRunner {
    // Uses the SAME package decoder + DevicePatchService used by the original
    // project's Apply/Restore buttons. PatchTransaction therefore creates and
    // validates the original backup/journal before replacing files.
    static func setEnabled(
        _ enabled: Bool,
        fileName: String,
        configuredPassword: String,
        permit: ActionPermit,
        action: ProtectedAction
    ) -> Result<String, Error> {
        do {
            guard AuthProtection.validatePermit(permit, for: action),
                  AuthDylibLoader.shared.verifyIntegrity() else {
                throw PatchSlotError.authorizationRequired
            }

            if enabled {
                let data: Data
                do {
                    data = try EmbeddedPatchVault.data(named: fileName)
                } catch EmbeddedPatchVaultError.missingPatch {
                    throw PatchSlotError.missingPatch
                }

                // "0" = package without password. Any other value is passed to the
                // same decoder used by the original 3105 password flow.
                let password: String? = configuredPassword == "0" ? nil : configuredPassword
                let decoded = try PatchPackageCodec.decode(data, password: password)

                // PatchTransaction creates + verifies every original backup before
                // it writes the first replacement byte. Persist the exact receipt
                // by UI slot so Restore never needs the patch package again.
                let receipt = try DevicePatchService.apply(project: decoded.project)
                PatchSlotBackupRegistry.save(receipt, for: fileName)
                return .success("Patch aplicado. Backup original criado.")
            } else {
                guard let receipt = PatchSlotBackupRegistry.receipt(for: fileName) else {
                    throw PatchSlotError.noBackup
                }
                try DevicePatchService.restore(receipt: receipt)
                PatchSlotBackupRegistry.remove(for: fileName)
                return .success("Backup restaurado. Arquivos originais recuperados.")
            }
        } catch {
            return .failure(error)
        }
    }

    static func message(for error: Error) -> String {
        if let slotError = error as? PatchSlotError {
            switch slotError {
            case .missingPatch:
                return "Patch não encontrado."
            case .noBackup:
                return "Backup não encontrado."
            case .authorizationRequired:
                return "Autenticação obrigatória."
            }
        }
        if let patchError = error as? PatchPackageError {
            switch patchError {
            case .restoreFailed:
                return "Falha ao restaurar backup."
            default:
                return "Falha ao aplicar patch."
            }
        }
        return "Operação não concluída."
    }


    private enum PatchSlotError: Error {
        case missingPatch
        case noBackup
        case authorizationRequired
    }
}

private enum PatchSlotBackupRegistry {
    private struct Entry: Codable {
        let transactionID: UUID
        let projectID: UUID
    }

    private static let defaultsKey = "external.patch.slot.backups.v1"

    static func save(_ receipt: PatchTransactionReceipt, for slot: String) {
        var entries = load()
        entries[slot] = Entry(
            transactionID: receipt.id,
            projectID: receipt.projectID
        )
        persist(entries)
    }

    static func receipt(for slot: String) -> PatchTransactionReceipt? {
        var entries = load()
        guard let entry = entries[slot],
              let backupRoot = try? PatchProjectLibrary.backupRootURL() else {
            return nil
        }

        let journalURL = backupRoot
            .appendingPathComponent(entry.projectID.uuidString, isDirectory: true)
            .appendingPathComponent(entry.transactionID.uuidString, isDirectory: true)
            .appendingPathComponent("journal.plist")

        guard FileManager.default.fileExists(atPath: journalURL.path) else {
            entries.removeValue(forKey: slot)
            persist(entries)
            return nil
        }

        return PatchTransactionReceipt(
            id: entry.transactionID,
            projectID: entry.projectID,
            journalURL: journalURL
        )
    }

    static func remove(for slot: String) {
        var entries = load()
        entries.removeValue(forKey: slot)
        persist(entries)
    }

    private static func load() -> [String: Entry] {
        guard let data = UserDefaults.standard.data(forKey: defaultsKey),
              let entries = try? PropertyListDecoder().decode([String: Entry].self, from: data) else {
            return [:]
        }
        return entries
    }

    private static func persist(_ entries: [String: Entry]) {
        if entries.isEmpty {
            UserDefaults.standard.removeObject(forKey: defaultsKey)
            return
        }
        guard let data = try? PropertyListEncoder().encode(entries) else { return }
        UserDefaults.standard.set(data, forKey: defaultsKey)
    }
}

private struct TextureCardOption: Identifiable {
    let id: String
    let title: String
    let subtitle: String
    let imageName: String
    let patchFile: String
    let patchPassword: String
    let game: Int
}

private struct TexturasView: View {
    @EnvironmentObject private var auth: AuthProtection
    let darkMode: Bool

    @State private var game = 0
    @State private var enabledNormal: Set<String> = []
    @State private var enabledMax: Set<String> = []
    @State private var busy: Set<String> = []
    @State private var successPresented = false
    @State private var successMessage = "Ativado com sucesso!"
    @State private var errorMessage: String?

    private let normalTextures = [
        TextureCardOption(id: "textura-1", title: "Textura 1", subtitle: "personagem: santino", imageName: "Texture1Card", patchFile: PatchSlots.textura1, patchPassword: PatchSlots.textura1Password, game: 0),
        TextureCardOption(id: "textura-2", title: "Textura 2", subtitle: "personagem: santino", imageName: "Texture2Card", patchFile: PatchSlots.textura2, patchPassword: PatchSlots.textura2Password, game: 0),
        TextureCardOption(id: "textura-3", title: "Textura 3", subtitle: "personagem: santino", imageName: "Texture3Card", patchFile: PatchSlots.textura3, patchPassword: PatchSlots.textura3Password, game: 0),
        TextureCardOption(id: "textura-4", title: "Textura 4", subtitle: "personagem: alok avançado", imageName: "Texture4Card", patchFile: PatchSlots.textura4, patchPassword: PatchSlots.textura4Password, game: 0),
        TextureCardOption(id: "textura-5", title: "Textura 5", subtitle: "personagem: alok avançado", imageName: "Texture5Card", patchFile: PatchSlots.textura5, patchPassword: PatchSlots.textura5Password, game: 0)
    ]

    private let maxTextures = [
        TextureCardOption(id: "textura-4-max", title: "Textura 4", subtitle: "personagem: alok avançado", imageName: "Texture4Card", patchFile: PatchSlots.textura4Max, patchPassword: PatchSlots.textura4MaxPassword, game: 1),
        TextureCardOption(id: "textura-5-max", title: "Textura 5", subtitle: "personagem: alok avançado", imageName: "Texture5Card", patchFile: PatchSlots.textura5Max, patchPassword: PatchSlots.textura5MaxPassword, game: 1)
    ]

    private var visibleTextures: [TextureCardOption] {
        game == 0 ? normalTextures : maxTextures
    }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 16) {
                Spacer().frame(height: 102)

                HStack(spacing: 12) {
                    GameButton("Free Fire Normal", selected: game == 0, darkMode: darkMode) { requestGame(0) }
                    GameButton("Free Fire Max", selected: game == 1, darkMode: darkMode) { requestGame(1) }
                }
                .padding(.bottom, 5)

                Text("SELECIONE A TEXTURA")
                    .font(.system(size: 14, weight: .bold))
                    .tracking(1.6)
                    .foregroundStyle(Color(red: 0.60, green: 0.77, blue: 0.94))
                    .padding(.bottom, 3)

                ForEach(visibleTextures) { texture in
                    textureCard(texture)
                }

                Spacer().frame(height: 92)
            }
            .padding(.horizontal, 22)
        }
        .background(
            (darkMode ? Color.black : Color(uiColor: .systemGroupedBackground))
                .ignoresSafeArea()
        )
        .alert("Sucesso", isPresented: $successPresented) {
            Button("OK") { }
        } message: {
            Text(successMessage)
        }
        .alert("Canva", isPresented: Binding(
            get: { errorMessage != nil },
            set: { if !$0 { errorMessage = nil } }
        )) {
            Button("OK") { errorMessage = nil }
        } message: {
            Text(errorMessage ?? "")
        }
    }

    @ViewBuilder
    private func textureCard(_ texture: TextureCardOption) -> some View {
        HStack(spacing: 16) {
            Image(texture.imageName)
                .resizable()
                .scaledToFit()
                .frame(width: 82, height: 108)
                .padding(7)
                .background(Color.white.opacity(darkMode ? 0.96 : 1.0))
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))

            VStack(alignment: .leading, spacing: 5) {
                Text(texture.title)
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundStyle(darkMode ? Color.white : Color.black)

                Text(texture.subtitle)
                    .font(.system(size: 12.5, weight: .regular))
                    .foregroundStyle(darkMode ? Color.white.opacity(0.48) : Color.black.opacity(0.48))
            }

            Spacer(minLength: 8)

            if busy.contains(texture.id) {
                ProgressView().scaleEffect(0.82)
            }

            Toggle("", isOn: Binding(
                get: { isEnabled(texture) },
                set: { value in setTexture(texture, enabledState: value) }
            ))
            .labelsHidden()
            .scaleEffect(0.88)
            .disabled(busy.contains(texture.id))
        }
        .padding(.horizontal, 15)
        .padding(.vertical, 14)
        .frame(maxWidth: .infinity, minHeight: 142)
        .background {
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .fill(darkMode ? Color.white.opacity(0.012) : Color.black.opacity(0.018))
        }
        .overlay {
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(Color(red: 0.58, green: 0.78, blue: 0.98).opacity(0.95), lineWidth: 1.5)
        }
        .shadow(
            color: Color(red: 0.58, green: 0.78, blue: 0.98).opacity(darkMode ? 0.10 : 0.06),
            radius: 10,
            x: 0,
            y: 0
        )
    }

    private func requestGame(_ newGame: Int) {
        Task { @MainActor in
            guard let permit = await auth.permit(for: .gameSelection),
                  AuthProtection.validatePermit(permit, for: .gameSelection) else { return }
            withAnimation(.easeOut(duration: 0.14)) {
                game = newGame
            }
        }
    }

    private func isEnabled(_ texture: TextureCardOption) -> Bool {
        texture.game == 0 ? enabledNormal.contains(texture.id) : enabledMax.contains(texture.id)
    }

    private func textures(for game: Int) -> [TextureCardOption] {
        game == 0 ? normalTextures : maxTextures
    }

    private func insertEnabled(_ texture: TextureCardOption) {
        if texture.game == 0 { enabledNormal.insert(texture.id) }
        else { enabledMax.insert(texture.id) }
    }

    private func removeEnabled(_ texture: TextureCardOption) {
        if texture.game == 0 { enabledNormal.remove(texture.id) }
        else { enabledMax.remove(texture.id) }
    }

    private func setTexture(_ texture: TextureCardOption, enabledState: Bool) {
        guard !busy.contains(texture.id) else { return }

        Task { @MainActor in
            guard let permit = await auth.permit(for: .patchToggle),
                  AuthProtection.validatePermit(permit, for: .patchToggle) else {
                errorMessage = "Autenticação obrigatória. Valide sua key novamente."
                return
            }

            busy.insert(texture.id)
            defer { busy.remove(texture.id) }

            // Uma textura ativa por jogo. Normal e Max mantêm seleções independentes.
            if enabledState {
                let previousTextures = textures(for: texture.game).filter {
                    $0.id != texture.id && isEnabled($0)
                }

                for previous in previousTextures {
                    let restoreResult = await performTextureOperation(false, texture: previous, permit: permit)
                    if case .failure(let error) = restoreResult {
                        errorMessage = PatchSlotRunner.message(for: error)
                        return
                    }
                    removeEnabled(previous)
                }
            }

            let result = await performTextureOperation(enabledState, texture: texture, permit: permit)

            switch result {
            case .success:
                if enabledState {
                    insertEnabled(texture)
                    successMessage = "Ativado com sucesso!"
                } else {
                    removeEnabled(texture)
                    successMessage = "Desinjetado com sucesso!"
                }
                successPresented = true
            case .failure(let error):
                errorMessage = PatchSlotRunner.message(for: error)
            }
        }
    }

    private func performTextureOperation(
        _ enabledState: Bool,
        texture: TextureCardOption,
        permit: ActionPermit
    ) async -> Result<String, Error> {
        await withCheckedContinuation { continuation in
            DispatchQueue.global(qos: .userInitiated).async {
                let result = PatchSlotRunner.setEnabled(
                    enabledState,
                    fileName: texture.patchFile,
                    configuredPassword: texture.patchPassword,
                    permit: permit,
                    action: .patchToggle
                )
                continuation.resume(returning: result)
            }
        }
    }
}

private struct ConfigDashboardView: View {
    @EnvironmentObject private var appState: AppState
    @EnvironmentObject private var auth: AuthProtection
    @Binding var darkMode: Bool
    @State private var showSettings = false

    var body: some View {
        NavigationStack {
            List {
                Section("CONTA") {
                    HStack(spacing: 10) {
                        Text("Key")
                        Spacer(minLength: 12)
                        Text(auth.displayedKey)
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                            .minimumScaleFactor(0.75)

                        Button {
                            guard auth.displayedKey != "–" else { return }
                            UIPasteboard.general.string = auth.displayedKey
                        } label: {
                            Image(systemName: "doc.on.doc")
                                .font(.system(size: 15, weight: .semibold))
                        }
                        .buttonStyle(.plain)
                        .disabled(auth.displayedKey == "–")
                        .accessibilityLabel("Copiar key")
                    }

                    LabeledContent("Expira em", value: auth.expirationDisplay)
                    LabeledContent("Build", value: "10")
                    LabeledContent("Versão", value: "1.10")
                }
                Section {
                    LabeledContent("Phone", value: DeviceInfo.machine)
                    LabeledContent("Modelo de hardware", value: DeviceInfo.machine)
                    LabeledContent("Versão do iOS", value: UIDevice.current.systemVersion)
                    HStack {
                        Text("Compatibilidade"); Spacer()
                        Label(appState.isSupported ? "Suportado" : "Não suportado",
                              systemImage: appState.isSupported ? "checkmark.circle.fill" : "xmark.circle.fill")
                            .foregroundStyle(appState.isSupported ? Color.green : Color.red)
                    }
                } header: { Text("DISPOSITIVO") }
                footer: { Text("Verificado: iOS 26.0–26.6.1 e builds listados do iOS 27.") }

                Section("APARÊNCIA") {
                    Toggle(isOn: Binding(get: { darkMode }, set: { darkMode = $0 })) {
                        Label(darkMode ? "Modo escuro" : "Modo claro",
                              systemImage: darkMode ? "moon.fill" : "sun.max.fill")
                    }
                }
                Section("INSTALAÇÃO") {
                    Label("Certificado enterprise", systemImage: "checkmark.seal")
                }
            }
            .font(.system(size: 15))
            .navigationTitle("Config")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showSettings = true } label: { Image(systemName:"gearshape") }
                }
            }
            .tint(Color(red:0.58,green:0.77,blue:0.94))
            .sheet(isPresented: $showSettings) {
                SettingsView().preferredColorScheme(darkMode ? .dark : .light)
            }
        }
    }
}

private enum DeviceInfo {
    static var machine: String {
        var systemInfo = utsname(); uname(&systemInfo)
        let mirror = Mirror(reflecting: systemInfo.machine)
        return mirror.children.reduce(into: "") { result, element in
            guard let value = element.value as? Int8, value != 0 else { return }
            result.append(Character(UnicodeScalar(UInt8(value))))
        }
    }
}

private struct BottomItem: View {
    let icon:String; let title:String; let selected:Bool; let darkMode:Bool; let action:()->Void
    var body: some View {
        Button(action:action) {
            VStack(spacing:3) {
                Image(systemName:icon).font(.system(size:19))
                Text(title).font(.system(size:11.5))
            }
            .foregroundStyle(selected ? Color(red:0.58,green:0.77,blue:0.94) :
                                (darkMode ? Color.white.opacity(0.50) : Color.black.opacity(0.48)))
            .frame(maxWidth:.infinity).frame(height:56)
            .background(selected ? (darkMode ? Color.white.opacity(0.09) : Color.black.opacity(0.07)) : .clear,
                        in: RoundedRectangle(cornerRadius:24))
        }
        .buttonStyle(.plain)
        .animation(.easeOut(duration: 0.14), value: selected)
    }
}
