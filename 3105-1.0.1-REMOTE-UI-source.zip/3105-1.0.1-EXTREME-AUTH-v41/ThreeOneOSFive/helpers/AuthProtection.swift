import Foundation
import SwiftUI
import Security
import CryptoKit
import Darwin

enum ProtectedAction: String {
    case tabNavigation = "tab-navigation"
    case gameSelection = "game-selection"
    case patchToggle = "patch-toggle"
    case patchApply = "patch-apply"
    case patchRestore = "patch-restore"
    case settings = "settings"
}

struct ActionPermit {
    let action: String
    let issuedAt: TimeInterval
    let nonce: String
    let generation: UInt64
    let signature: String
}

enum AuthGateError: LocalizedError {
    case blocked

    var errorDescription: String? {
        "Autenticação obrigatória. Ação bloqueada."
    }
}

private struct AuthRuntimeSnapshot {
    let key: String
    let hwid: String
    let sessionToken: String
    let sessionExpiresAt: Date?
    let heartbeatNonce: String
    let lastServerSuccess: TimeInterval

    static func capture() -> AuthRuntimeSnapshot? {
        guard EAExternalAuthClassPresent(),
              EAExternalAuthImagePathIsExpected(),
              EAExternalAuthIsUnlocked(),
              EASecurityEnvironmentIsClean() else {
            return nil
        }

        let key = (EAExternalAuthValidatedKey() ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let hwid = (EAExternalAuthValidatedHWID() ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let token = (EAExternalAuthSessionToken() ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let heartbeat = (EAExternalAuthHeartbeatNonce() ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let expiryText = (EAExternalAuthSessionExpiresAt() ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let lastServerSuccess = EAExternalAuthLastServerSuccess()

        guard !key.isEmpty,
              hwid.count >= 8,
              token.count >= 32,
              heartbeat.count >= 16,
              lastServerSuccess > 0 else {
            return nil
        }

        guard let savedKey = KeychainReader.read(account: KeychainReader.keyAccount),
              let savedHWID = KeychainReader.read(account: KeychainReader.hwidAccount),
              constantTimeEqual(savedKey, key),
              constantTimeEqual(savedHWID, hwid) else {
            return nil
        }

        let uptime = ProcessInfo.processInfo.systemUptime
        let heartbeatAge = uptime - lastServerSuccess
        guard heartbeatAge >= -3, heartbeatAge <= 75 else {
            return nil
        }

        let expiry = expiryText.isEmpty ? nil : AuthDateParser.parse(expiryText)
        if !expiryText.isEmpty && expiry == nil { return nil }
        if let expiry, expiry <= Date() { return nil }

        return AuthRuntimeSnapshot(
            key: key,
            hwid: hwid,
            sessionToken: token,
            sessionExpiresAt: expiry,
            heartbeatNonce: heartbeat,
            lastServerSuccess: lastServerSuccess
        )
    }

    private static func constantTimeEqual(_ lhs: String, _ rhs: String) -> Bool {
        let a = Array(lhs.utf8)
        let b = Array(rhs.utf8)
        guard a.count == b.count else { return false }
        var diff: UInt8 = 0
        for index in a.indices { diff |= a[index] ^ b[index] }
        return diff == 0
    }
}

private final class AuthRuntimeGate {
    static let shared = AuthRuntimeGate()

    private let lock = NSLock()
    private let processNonce = UUID().uuidString + UUID().uuidString + UUID().uuidString
    private var sessionSecret: String?
    private var sessionIdentity: String?
    private var serverExpiry: Date?
    private var generation: UInt64 = 0

    private init() {}

    func sync(snapshot: AuthRuntimeSnapshot) {
        let identity = Self.sha256([
            snapshot.key,
            snapshot.hwid,
            snapshot.sessionToken,
            AuthDylibLoader.expectedIntegritySHA256
        ].joined(separator: "|"))

        lock.lock()
        defer { lock.unlock() }

        if sessionIdentity != identity || sessionSecret == nil {
            generation &+= 1
            sessionIdentity = identity
            sessionSecret = Self.sha256("\(identity)|\(processNonce)|\(generation)")
        }
        serverExpiry = snapshot.sessionExpiresAt
    }

    func close() {
        lock.lock()
        generation &+= 1
        sessionSecret = nil
        sessionIdentity = nil
        serverExpiry = nil
        lock.unlock()
    }

    func makePermit(for action: ProtectedAction) -> ActionPermit? {
        lock.lock()
        defer { lock.unlock() }

        guard let secret = sessionSecret else { return nil }
        if let serverExpiry, serverExpiry <= Date() { return nil }

        let issuedAt = Date().timeIntervalSince1970
        let nonce = UUID().uuidString + UUID().uuidString
        let signature = Self.sha256("\(secret)|\(action.rawValue)|\(issuedAt)|\(nonce)|\(generation)")
        return ActionPermit(
            action: action.rawValue,
            issuedAt: issuedAt,
            nonce: nonce,
            generation: generation,
            signature: signature
        )
    }

    func validate(_ permit: ActionPermit, for action: ProtectedAction) -> Bool {
        lock.lock()
        defer { lock.unlock() }

        guard let secret = sessionSecret,
              permit.action == action.rawValue,
              permit.generation == generation else { return false }

        if let serverExpiry, serverExpiry <= Date() { return false }

        let age = Date().timeIntervalSince1970 - permit.issuedAt
        guard age >= -2, age <= 12 else { return false }

        let expected = Self.sha256("\(secret)|\(action.rawValue)|\(permit.issuedAt)|\(permit.nonce)|\(permit.generation)")
        return Self.constantTimeEqual(expected, permit.signature)
    }

    func isOpen() -> Bool {
        lock.lock()
        defer { lock.unlock() }
        guard sessionSecret != nil else { return false }
        if let serverExpiry, serverExpiry <= Date() { return false }
        return true
    }

    private static func sha256(_ text: String) -> String {
        let digest = SHA256.hash(data: Data(text.utf8))
        return digest.map { String(format: "%02x", $0) }.joined()
    }

    private static func constantTimeEqual(_ lhs: String, _ rhs: String) -> Bool {
        let a = Array(lhs.utf8)
        let b = Array(rhs.utf8)
        guard a.count == b.count else { return false }
        var diff: UInt8 = 0
        for index in a.indices { diff |= a[index] ^ b[index] }
        return diff == 0
    }
}

final class AuthDylibLoader {
    static let shared = AuthDylibLoader()

    // SHA-256 de __TEXT,__text + __TEXT,__cstring. A assinatura da IPA pode mudar
    // sem alterar esta impressão digital estável do módulo de autenticação.
    static let expectedIntegritySHA256 = "1eac44bac5430383f18d17d88ca36185db26e7fe5bfba1953cd40f925e3e1ac0"
    private static let textRange = 0x4000..<(0x4000 + 0x9034)
    private static let cstringRange = 0x10ed0..<(0x10ed0 + 0x473)
    private static let minimumFileSize = 0x468000

    private let lock = NSLock()
    private var handle: UnsafeMutableRawPointer?
    private var lastIntegrityCheck: Date?
    private var lastIntegrityResult = false
    private(set) var lastError: String?

    private init() {}

    @discardableResult
    func loadAndVerify() -> Bool {
        lock.lock()
        defer { lock.unlock() }

        guard EASecurityEnvironmentIsClean() else {
            lastError = "Ambiente de execução não confiável."
            return false
        }

        guard let url = dylibURL() else {
            lastError = "ExternalAuth.dylib não encontrada."
            return false
        }

        guard verifyHash(url: url) else {
            lastIntegrityCheck = Date()
            lastIntegrityResult = false
            lastError = "Integridade da ExternalAuth.dylib inválida."
            return false
        }

        lastIntegrityCheck = Date()
        lastIntegrityResult = true

        if handle == nil {
            handle = dlopen(url.path, RTLD_NOW | RTLD_LOCAL)
            guard handle != nil else {
                if let error = dlerror() {
                    lastError = String(cString: error)
                } else {
                    lastError = "Falha ao carregar ExternalAuth.dylib."
                }
                return false
            }
        }

        guard EAExternalAuthClassPresent(), EAExternalAuthImagePathIsExpected() else {
            lastError = "Runtime da autenticação indisponível ou fora do bundle esperado."
            return false
        }

        EAExternalAuthEnsureStarted()
        lastError = nil
        return true
    }

    func verifyIntegrity() -> Bool {
        lock.lock()
        defer { lock.unlock() }

        guard handle != nil,
              EASecurityEnvironmentIsClean(),
              EAExternalAuthClassPresent(),
              EAExternalAuthImagePathIsExpected(),
              let url = dylibURL() else {
            return false
        }

        if let lastIntegrityCheck,
           Date().timeIntervalSince(lastIntegrityCheck) < 0.75 {
            return lastIntegrityResult
        }

        let result = verifyHash(url: url)
        lastIntegrityCheck = Date()
        lastIntegrityResult = result
        return result
    }

    private func dylibURL() -> URL? {
        let frameworkURL = Bundle.main.bundleURL
            .appendingPathComponent("Frameworks", isDirectory: true)
            .appendingPathComponent("ExternalAuth.dylib", isDirectory: false)

        if FileManager.default.fileExists(atPath: frameworkURL.path) {
            return frameworkURL
        }

        let fallback = Bundle.main.bundleURL.appendingPathComponent("ExternalAuth.dylib")
        if FileManager.default.fileExists(atPath: fallback.path) {
            return fallback
        }
        return nil
    }

    private func verifyHash(url: URL) -> Bool {
        guard let data = try? Data(contentsOf: url, options: [.mappedIfSafe]),
              data.count >= Self.minimumFileSize,
              data.count >= Self.textRange.upperBound,
              data.count >= Self.cstringRange.upperBound else {
            return false
        }

        // Mach-O 64-bit little endian ARM64.
        guard data.count >= 12 else { return false }
        let magic = data.withUnsafeBytes { $0.load(fromByteOffset: 0, as: UInt32.self) }
        let cpuType = data.withUnsafeBytes { $0.load(fromByteOffset: 4, as: Int32.self) }
        guard magic == 0xFEEDFACF, cpuType == 0x0100000C else { return false }

        var protectedBytes = Data()
        protectedBytes.append(data.subdata(in: Self.textRange))
        protectedBytes.append(data.subdata(in: Self.cstringRange))

        let digest = SHA256.hash(data: protectedBytes)
            .map { String(format: "%02x", $0) }
            .joined()
        return constantTimeEqual(digest, Self.expectedIntegritySHA256)
    }

    private func constantTimeEqual(_ lhs: String, _ rhs: String) -> Bool {
        let a = Array(lhs.utf8)
        let b = Array(rhs.utf8)
        guard a.count == b.count else { return false }
        var diff: UInt8 = 0
        for index in a.indices { diff |= a[index] ^ b[index] }
        return diff == 0
    }
}

final class AuthProtection: ObservableObject {
    static let shared = AuthProtection()

    enum State: Equatable {
        case checking
        case waitingForAuth
        case authorized
        case denied(String)
    }

    @Published private(set) var state: State = .checking
    @Published private(set) var licenseKey: String?
    // Expiração REAL da licença/key. A expiração curta da sessão segura da
    // ExternalAuth continua sendo usada somente pelo AuthRuntimeGate.
    @Published private(set) var expiresAt: Date?
    @Published private(set) var lastValidation: Date?
    @Published private(set) var expirationKnown = false
    @Published private(set) var lifetimeLicense = false

    private var pollTimer: Timer?
    private var refreshInProgress = false
    private var licenseLookupInProgress = false
    private var lastLicenseLookup = Date.distantPast
    private var lastLicenseLookupKey: String?

    private init() {}

    var isAuthorized: Bool {
        if case .authorized = state { return true }
        return false
    }

    var isChecking: Bool {
        if case .checking = state { return true }
        return false
    }

    var displayedKey: String { licenseKey ?? "–" }

    var expirationDisplay: String {
        guard isAuthorized else { return "–" }
        guard expirationKnown else { return "Carregando…" }
        if lifetimeLicense { return "Sem expiração" }
        guard let expiresAt else { return "–" }

        let totalSeconds = Int(expiresAt.timeIntervalSinceNow)
        guard totalSeconds > 0 else { return "Expirada" }

        let days = totalSeconds / 86_400
        let hours = (totalSeconds % 86_400) / 3_600
        let minutes = (totalSeconds % 3_600) / 60
        let seconds = totalSeconds % 60

        if days > 0 { return "\(days)d \(hours)h \(minutes)min" }
        if hours > 0 { return "\(hours)h \(minutes)min \(seconds)s" }
        if minutes > 0 { return "\(minutes)min \(seconds)s" }
        return "\(max(seconds, 1))s"
    }

    var lockMessage: String {
        switch state {
        case .checking:
            return "Verificando autenticação…"
        case .waitingForAuth:
            return "Valide sua key na External Auth para liberar o aplicativo."
        case .authorized:
            return ""
        case .denied(let reason):
            return reason
        }
    }

    @MainActor
    func bootstrap() async {
        guard AuthDylibLoader.shared.loadAndVerify() else {
            deny(AuthDylibLoader.shared.lastError ?? "External Auth obrigatória não carregou.")
            startPolling()
            return
        }

        EAExternalAuthEnsureStarted()
        startPolling()
        _ = refreshFromRuntime()
    }

    @MainActor
    func appBecameActive() async {
        guard AuthDylibLoader.shared.loadAndVerify() else {
            deny(AuthDylibLoader.shared.lastError ?? "External Auth indisponível.")
            return
        }
        EAExternalAuthEnsureStarted()
        _ = refreshFromRuntime()
    }

    @MainActor
    func permit(for action: ProtectedAction) async -> ActionPermit? {
        guard refreshFromRuntime(),
              let permit = AuthRuntimeGate.shared.makePermit(for: action),
              AuthRuntimeGate.shared.validate(permit, for: action) else {
            return nil
        }
        return permit
    }

    @MainActor
    @discardableResult
    private func refreshFromRuntime() -> Bool {
        if refreshInProgress { return isAuthorized }
        refreshInProgress = true
        defer { refreshInProgress = false }

        guard AuthDylibLoader.shared.verifyIntegrity() || AuthDylibLoader.shared.loadAndVerify() else {
            deny(AuthDylibLoader.shared.lastError ?? "Módulo de autenticação inválido.")
            return false
        }

        guard EASecurityEnvironmentIsClean() else {
            deny("Ambiente de execução não autorizado.")
            return false
        }

        guard let snapshot = AuthRuntimeSnapshot.capture() else {
            AuthRuntimeGate.shared.close()
            licenseKey = nil
            expiresAt = nil
            expirationKnown = false
            lifetimeLicense = false
            state = .waitingForAuth

            // Quando a key/HWID é resetada ou a sessão é revogada, a dylib
            // pode bloquear enquanto a UI principal já está aberta. Chamar
            // start novamente é intencional: a ExternalAuth é idempotente e,
            // se estiver locked, reapresenta automaticamente a tela de login.
            EAExternalAuthEnsureStarted()
            return false
        }

        AuthRuntimeGate.shared.sync(snapshot: snapshot)
        licenseKey = snapshot.key
        lastValidation = Date()
        state = .authorized
        refreshLicenseExpirationIfNeeded(for: snapshot.key)
        return true
    }

    @MainActor
    private func deny(_ reason: String) {
        AuthRuntimeGate.shared.close()
        licenseKey = nil
        expiresAt = nil
        expirationKnown = false
        lifetimeLicense = false
        state = .denied(reason)
    }

    @MainActor
    private func refreshLicenseExpirationIfNeeded(for key: String, force: Bool = false) {
        let now = Date()
        let sameKey = lastLicenseLookupKey == key
        let recentlyChecked = now.timeIntervalSince(lastLicenseLookup) < 12

        guard !licenseLookupInProgress else { return }
        guard force || !sameKey || !recentlyChecked else { return }

        licenseLookupInProgress = true
        lastLicenseLookupKey = key
        lastLicenseLookup = now

        Task { @MainActor [weak self] in
            guard let self else { return }
            let info = await AuthLicenseLookup.fetch(key: key)
            self.licenseLookupInProgress = false

            // A resposta pode chegar depois de uma troca/reset de key.
            guard self.licenseKey == key, self.isAuthorized else { return }

            guard let info else {
                // Mantém o último valor real conhecido se a rede oscilar.
                return
            }

            self.expirationKnown = true
            self.lifetimeLicense = info.isLifetime
            self.expiresAt = info.expiresAt
        }
    }

    @MainActor
    private func startPolling() {
        guard pollTimer == nil else { return }
        pollTimer = Timer.scheduledTimer(withTimeInterval: 0.8, repeats: true) { [weak self] _ in
            guard let self else { return }
            Task { @MainActor in
                _ = self.refreshFromRuntime()
            }
        }
    }

    static func validatePermit(_ permit: ActionPermit, for action: ProtectedAction) -> Bool {
        guard AuthDylibLoader.shared.verifyIntegrity(),
              EASecurityEnvironmentIsClean(),
              let snapshot = AuthRuntimeSnapshot.capture() else {
            AuthRuntimeGate.shared.close()
            return false
        }

        AuthRuntimeGate.shared.sync(snapshot: snapshot)
        return AuthRuntimeGate.shared.validate(permit, for: action)
    }

    static func runtimeAccessAllowed() -> Bool {
        guard AuthDylibLoader.shared.verifyIntegrity(),
              EASecurityEnvironmentIsClean(),
              let snapshot = AuthRuntimeSnapshot.capture() else {
            AuthRuntimeGate.shared.close()
            return false
        }

        AuthRuntimeGate.shared.sync(snapshot: snapshot)
        return AuthRuntimeGate.shared.isOpen()
    }
}

private struct AuthLicenseInfo {
    let expiresAt: Date?
    let isLifetime: Bool
}

private enum AuthLicenseLookup {
    private static let endpoint = URL(string: "https://externalconfig.shardweb.app/api/keys/check")!

    private struct Response: Decodable {
        let success: Bool?
        let found: Bool?
        let status: String?
        let expiresAt: String?

        enum CodingKeys: String, CodingKey {
            case success
            case found
            case status
            case expiresAt = "expires_at"
        }
    }

    static func fetch(key: String) async -> AuthLicenseInfo? {
        guard !key.isEmpty else { return nil }

        var request = URLRequest(url: endpoint)
        request.httpMethod = "POST"
        request.timeoutInterval = 10
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")

        guard let body = try? JSONSerialization.data(withJSONObject: ["key": key]) else {
            return nil
        }
        request.httpBody = body

        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse,
                  (200..<300).contains(http.statusCode) else {
                return nil
            }

            let decoded = try JSONDecoder().decode(Response.self, from: data)
            guard decoded.success == true,
                  decoded.found == true else {
                return nil
            }

            let expiry = decoded.expiresAt.flatMap(AuthDateParser.parse)
            let active = decoded.status?.lowercased() == "active"
            let lifetime = active && decoded.expiresAt == nil

            return AuthLicenseInfo(expiresAt: expiry, isLifetime: lifetime)
        } catch {
            return nil
        }
    }
}

private enum KeychainReader {
    static let service = "app.external.auth"
    static let keyAccount = "license-key"
    static let hwidAccount = "hwid-v1"

    static func read(account: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]

        var result: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        guard status == errSecSuccess,
              let data = result as? Data,
              let value = String(data: data, encoding: .utf8) else {
            return nil
        }
        return value
    }
}

private enum AuthDateParser {
    static func parse(_ value: String) -> Date? {
        let fractional = ISO8601DateFormatter()
        fractional.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let date = fractional.date(from: value) { return date }

        let standard = ISO8601DateFormatter()
        standard.formatOptions = [.withInternetDateTime]
        return standard.date(from: value)
    }
}
