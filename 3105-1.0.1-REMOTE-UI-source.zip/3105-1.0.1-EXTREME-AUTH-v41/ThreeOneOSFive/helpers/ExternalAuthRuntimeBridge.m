#import "ExternalAuthRuntimeBridge.h"

#import <objc/message.h>
#import <objc/runtime.h>
#import <mach-o/dyld.h>
#import <sys/sysctl.h>
#import <unistd.h>
#import <limits.h>
#import <stdlib.h>
#import <string.h>

// Runs before SwiftUI @main. Because ExternalAuth.dylib is a strong/needed
// dependency, dyld must have loaded it before this constructor executes.
// If the expected auth runtime is missing, terminate before any app UI/state exists.
__attribute__((constructor(101)))
static void EARequireAuthImageBeforeSwiftMain(void) {
    @autoreleasepool {
        Class cls = NSClassFromString(@"ExternalAuthManager");
        if (!cls) {
            _exit(173);
        }
    }
}

static id EAManager(void) {
    Class cls = NSClassFromString(@"ExternalAuthManager");
    if (!cls) return nil;

    SEL sharedSel = NSSelectorFromString(@"shared");
    if (![cls respondsToSelector:sharedSel]) return nil;

    id (*sendObject)(id, SEL) = (id (*)(id, SEL))objc_msgSend;
    return sendObject((id)cls, sharedSel);
}

static NSString *EAStringProperty(NSString *selectorName) {
    id manager = EAManager();
    if (!manager) return nil;

    SEL selector = NSSelectorFromString(selectorName);
    if (![manager respondsToSelector:selector]) return nil;

    id (*sendObject)(id, SEL) = (id (*)(id, SEL))objc_msgSend;
    id value = sendObject(manager, selector);
    return [value isKindOfClass:[NSString class]] ? value : nil;
}

static NSString *EAResolvedPath(NSString *path) {
    if (path.length == 0) return nil;
    char resolved[PATH_MAX];
    if (realpath(path.fileSystemRepresentation, resolved) == NULL) return nil;
    return [NSString stringWithUTF8String:resolved];
}

BOOL EAExternalAuthImagePathIsExpected(void) {
    Class cls = NSClassFromString(@"ExternalAuthManager");
    if (!cls) return NO;

    const char *raw = class_getImageName(cls);
    if (!raw || raw[0] == '\0') return NO;

    NSString *actual = [NSString stringWithUTF8String:raw];
    NSString *expected = [[[NSBundle mainBundle] bundlePath]
        stringByAppendingPathComponent:@"Frameworks/ExternalAuth.dylib"];

    NSString *actualResolved = EAResolvedPath(actual);
    NSString *expectedResolved = EAResolvedPath(expected);
    if (actualResolved && expectedResolved) {
        return [actualResolved isEqualToString:expectedResolved];
    }

    // realpath can fail very early during launch on some signing/runtime setups;
    // keep a strict bundle-local suffix check as the fallback.
    NSString *suffix = @"/Frameworks/ExternalAuth.dylib";
    return [actual hasSuffix:suffix] && [expected hasSuffix:suffix];
}

BOOL EAExternalAuthClassPresent(void) {
    id manager = EAManager();
    if (!manager || !EAExternalAuthImagePathIsExpected()) return NO;

    NSArray<NSString *> *required = @[
        @"start",
        @"unlocked",
        @"validatedKey",
        @"validatedHWID",
        @"securitySessionToken",
        @"securitySessionExpiresAt",
        @"heartbeatNonce",
        @"lastServerSuccess"
    ];

    for (NSString *name in required) {
        if (![manager respondsToSelector:NSSelectorFromString(name)]) {
            return NO;
        }
    }
    return YES;
}

void EAExternalAuthEnsureStarted(void) {
    id manager = EAManager();
    if (!manager || !EAExternalAuthImagePathIsExpected()) return;

    SEL selector = NSSelectorFromString(@"start");
    if (![manager respondsToSelector:selector]) return;

    void (*sendVoid)(id, SEL) = (void (*)(id, SEL))objc_msgSend;
    sendVoid(manager, selector);
}

BOOL EAExternalAuthIsUnlocked(void) {
    id manager = EAManager();
    if (!manager || !EAExternalAuthImagePathIsExpected()) return NO;

    SEL selector = NSSelectorFromString(@"unlocked");
    if (![manager respondsToSelector:selector]) return NO;

    BOOL (*sendBool)(id, SEL) = (BOOL (*)(id, SEL))objc_msgSend;
    return sendBool(manager, selector);
}

NSString *EAExternalAuthValidatedKey(void) {
    if (!EAExternalAuthImagePathIsExpected()) return nil;
    return EAStringProperty(@"validatedKey");
}

NSString *EAExternalAuthValidatedHWID(void) {
    if (!EAExternalAuthImagePathIsExpected()) return nil;
    return EAStringProperty(@"validatedHWID");
}

NSString *EAExternalAuthSessionToken(void) {
    if (!EAExternalAuthImagePathIsExpected()) return nil;
    return EAStringProperty(@"securitySessionToken");
}

NSString *EAExternalAuthSessionExpiresAt(void) {
    if (!EAExternalAuthImagePathIsExpected()) return nil;
    return EAStringProperty(@"securitySessionExpiresAt");
}

NSString *EAExternalAuthHeartbeatNonce(void) {
    if (!EAExternalAuthImagePathIsExpected()) return nil;
    return EAStringProperty(@"heartbeatNonce");
}

double EAExternalAuthLastServerSuccess(void) {
    id manager = EAManager();
    if (!manager || !EAExternalAuthImagePathIsExpected()) return 0.0;

    SEL selector = NSSelectorFromString(@"lastServerSuccess");
    if (![manager respondsToSelector:selector]) return 0.0;

    double (*sendDouble)(id, SEL) = (double (*)(id, SEL))objc_msgSend;
    return sendDouble(manager, selector);
}

static BOOL EAHasDebugger(void) {
    int mib[4] = { CTL_KERN, KERN_PROC, KERN_PROC_PID, getpid() };
    struct kinfo_proc info;
    size_t size = sizeof(info);
    memset(&info, 0, sizeof(info));

    if (sysctl(mib, 4, &info, &size, NULL, 0) != 0) {
        return NO;
    }

#if defined(P_TRACED)
    return (info.kp_proc.p_flag & P_TRACED) != 0;
#else
    return NO;
#endif
}

static BOOL EAHasSuspiciousEnvironment(void) {
    const char *keys[] = {
        "DYLD_INSERT_LIBRARIES",
        "DYLD_LIBRARY_PATH",
        "DYLD_FRAMEWORK_PATH",
        "DYLD_FALLBACK_LIBRARY_PATH"
    };

    for (NSUInteger i = 0; i < sizeof(keys) / sizeof(keys[0]); i++) {
        const char *value = getenv(keys[i]);
        if (value && value[0] != '\0') return YES;
    }
    return NO;
}

static BOOL EAHasSuspiciousLoadedImage(void) {
    NSArray<NSString *> *needles = @[
        @"frida",
        @"gadget",
        @"cydiasubstrate",
        @"mobilesubstrate",
        @"substitute",
        @"libhooker",
        @"ellekit",
        @"cycript",
        @"flexloader",
        @"sslkill"
    ];

    uint32_t count = _dyld_image_count();
    for (uint32_t i = 0; i < count; i++) {
        const char *rawName = _dyld_get_image_name(i);
        if (!rawName) continue;

        NSString *name = [[NSString stringWithUTF8String:rawName] lowercaseString];
        for (NSString *needle in needles) {
            if ([name containsString:needle]) return YES;
        }
    }
    return NO;
}

BOOL EASecurityEnvironmentIsClean(void) {
    if (EAHasDebugger()) return NO;
    if (EAHasSuspiciousEnvironment()) return NO;
    if (EAHasSuspiciousLoadedImage()) return NO;
    return YES;
}
