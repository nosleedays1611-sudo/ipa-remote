#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

FOUNDATION_EXPORT BOOL EAExternalAuthClassPresent(void);
FOUNDATION_EXPORT BOOL EAExternalAuthImagePathIsExpected(void);
FOUNDATION_EXPORT void EAExternalAuthEnsureStarted(void);
FOUNDATION_EXPORT BOOL EAExternalAuthIsUnlocked(void);
FOUNDATION_EXPORT NSString * _Nullable EAExternalAuthValidatedKey(void);
FOUNDATION_EXPORT NSString * _Nullable EAExternalAuthValidatedHWID(void);
FOUNDATION_EXPORT NSString * _Nullable EAExternalAuthSessionToken(void);
FOUNDATION_EXPORT NSString * _Nullable EAExternalAuthSessionExpiresAt(void);
FOUNDATION_EXPORT NSString * _Nullable EAExternalAuthHeartbeatNonce(void);
FOUNDATION_EXPORT double EAExternalAuthLastServerSuccess(void);
FOUNDATION_EXPORT BOOL EASecurityEnvironmentIsClean(void);

NS_ASSUME_NONNULL_END
