import Foundation
import SwiftUI
import Security
import CryptoKit
import Darwin

enum ProtectedAction: String {
    case patchToggle = "patch-toggle"
}

struct ActionPermit {
    let action: String
    let issuedAt: TimeInterval
    let nonce: String
    let generation: UInt64
    let signature: String
}

enum AuthGateError: LocalizedError {
    case blocked
    var errorDescription: String? { "Autenticação obrigatória. Ação bloqueada." }
}

private struct RemoteAuthSnapshot {
    let key: String
    let ipv4: String
    let token: String
    let expiresAt: Date?
    let heartbeat: String
    let lastServerSuccess: TimeInterval

    static func capture() -> RemoteAuthSnapshot? {
        guard RARemoteAuthClassPresent(),
              RARemoteAuthImagePathIsExpected(),
              RARemoteAuthIsUnlocked(),
              RASecurityEnvironmentIsClean() else { return nil }

        let key = (RARemoteAuthValidatedKey() ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let ipv4 = (RARemoteAuthValidatedIPv4() ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let token = (RARemoteAuthSessionToken() ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let heartbeat = (RARemoteAuthHeartbeatNonce() ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let expiryText = (RARemoteAuthSessionExpiresAt() ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let lastSuccess = RARemoteAuthLastServerSuccess()

        guard key.range(of: #"^REMOTE-IOS-[A-Z0-9]{6}$"#, options: .regularExpression) != nil,
              isIPv4(ipv4), token.count >= 20, heartbeat.count >= 16, lastSuccess > 0 else { return nil }

        guard let savedKey = RemoteKeychain.read(account: "license-key"),
              let savedToken = RemoteKeychain.read(account: "session-token"),
              constantTimeEqual(savedKey, key),
              constantTimeEqual(savedToken, token) else { return nil }

        let age = ProcessInfo.processInfo.systemUptime - lastSuccess
        guard age >= -3, age <= 75 else { return nil }

        let expiry = expiryText.isEmpty ? nil : AuthDateParser.parse(expiryText)
        if !expiryText.isEmpty && expiry == nil { return nil }
        if let expiry, expiry <= Date() { return nil }

        return RemoteAuthSnapshot(
            key: key, ipv4: ipv4, token: token, expiresAt: expiry,
            heartbeat: heartbeat, lastServerSuccess: lastSuccess
        )
    }

    private static func isIPv4(_ value: String) -> Bool {
        let parts = value.split(separator: ".", omittingEmptySubsequences: false)
        guard parts.count == 4 else { return false }
        return parts.allSatisfy { part in
            guard !part.isEmpty, part.count <= 3, part.allSatisfy { $0.isNumber }, let n = Int(part) else { return false }
            return (0...255).contains(n)
        }
    }

    private static func constantTimeEqual(_ lhs: String, _ rhs: String) -> Bool {
        let a = Array(lhs.utf8), b = Array(rhs.utf8)
        guard a.count == b.count else { return false }
        var diff: UInt8 = 0
        for i in a.indices { diff |= a[i] ^ b[i] }
        return diff == 0
    }
}

private final class RuntimePermitGate {
    static let shared = RuntimePermitGate()
    private let lock = NSLock()
    private let processNonce = UUID().uuidString + UUID().uuidString
    private var sessionSecret: String?
    private var identity: String?
    private var expiry: Date?
    private var generation: UInt64 = 0

    private init() {}

    func sync(_ snapshot: RemoteAuthSnapshot) {
        let newIdentity = Self.sha256([
            snapshot.key, snapshot.ipv4, snapshot.token,
            RemoteAuthIntegrity.expectedSHA256
        ].joined(separator: "|"))

        lock.lock(); defer { lock.unlock() }
        if identity != newIdentity || sessionSecret == nil {
            generation &+= 1
            identity = newIdentity
            sessionSecret = Self.sha256("\(newIdentity)|\(processNonce)|\(generation)")
        }
        expiry = snapshot.expiresAt
    }

    func close() {
        lock.lock()
        generation &+= 1
        sessionSecret = nil
        identity = nil
        expiry = nil
        lock.unlock()
    }

    func makePermit(for action: ProtectedAction) -> ActionPermit? {
        lock.lock(); defer { lock.unlock() }
        guard let secret = sessionSecret else { return nil }
        if let expiry, expiry <= Date() { return nil }
        let issued = Date().timeIntervalSince1970
        let nonce = UUID().uuidString + UUID().uuidString
        let sig = Self.sha256("\(secret)|\(action.rawValue)|\(issued)|\(nonce)|\(generation)")
        return ActionPermit(action: action.rawValue, issuedAt: issued, nonce: nonce, generation: generation, signature: sig)
    }

    func validate(_ permit: ActionPermit, for action: ProtectedAction) -> Bool {
        lock.lock(); defer { lock.unlock() }
        guard let secret = sessionSecret,
              permit.action == action.rawValue,
              permit.generation == generation else { return false }
        if let expiry, expiry <= Date() { return false }
        let age = Date().timeIntervalSince1970 - permit.issuedAt
        guard age >= -2, age <= 12 else { return false }
        let expected = Self.sha256("\(secret)|\(action.rawValue)|\(permit.issuedAt)|\(permit.nonce)|\(permit.generation)")
        return Self.constantTimeEqual(expected, permit.signature)
    }

    func isOpen() -> Bool {
        lock.lock(); defer { lock.unlock() }
        guard sessionSecret != nil else { return false }
        if let expiry, expiry <= Date() { return false }
        return true
    }

    private static func sha256(_ value: String) -> String {
        SHA256.hash(data: Data(value.utf8)).map { String(format: "%02x", $0) }.joined()
    }

    private static func constantTimeEqual(_ lhs: String, _ rhs: String) -> Bool {
        let a = Array(lhs.utf8), b = Array(rhs.utf8)
        guard a.count == b.count else { return false }
        var diff: UInt8 = 0
        for i in a.indices { diff |= a[i] ^ b[i] }
        return diff == 0
    }
}

final class AuthDylibLoader {
    static let shared = AuthDylibLoader()
    private let lock = NSLock()
    private var handle: UnsafeMutableRawPointer?
    private var lastCheck: Date?
    private var lastResult = false
    private(set) var lastError: String?

    private init() {}

    @discardableResult
    func loadAndVerify() -> Bool {
        lock.lock(); defer { lock.unlock() }

        guard RASecurityEnvironmentIsClean() else {
            lastError = "Ambiente de execução não autorizado."
            return false
        }
        guard let url = dylibURL(), verifyHash(url) else {
            lastCheck = Date(); lastResult = false
            lastError = "Integridade da RemoteAuth.dylib inválida."
            return false
        }
        lastCheck = Date(); lastResult = true

        if handle == nil {
            handle = dlopen(url.path, RTLD_NOW | RTLD_LOCAL)
            guard handle != nil else {
                lastError = dlerror().map { String(cString: $0) } ?? "Falha ao carregar RemoteAuth.dylib."
                return false
            }
        }

        guard RARemoteAuthClassPresent(), RARemoteAuthImagePathIsExpected() else {
            lastError = "Runtime da autenticação fora do bundle esperado."
            return false
        }
        // UI startup is owned by AuthProtection.bootstrap/appBecameActive, where
        // a UIWindowScene already exists. Keep this loader side-effect free.
        lastError = nil
        return true
    }

    func verifyIntegrity() -> Bool {
        lock.lock(); defer { lock.unlock() }
        guard handle != nil, RASecurityEnvironmentIsClean(),
              RARemoteAuthClassPresent(), RARemoteAuthImagePathIsExpected(),
              let url = dylibURL() else { return false }

        if let lastCheck, Date().timeIntervalSince(lastCheck) < 0.5 { return lastResult }
        let ok = verifyHash(url)
        lastCheck = Date(); lastResult = ok
        return ok
    }

    private func dylibURL() -> URL? {
        let url = Bundle.main.bundleURL
            .appendingPathComponent("Frameworks", isDirectory: true)
            .appendingPathComponent("RemoteAuth.dylib")
        return FileManager.default.fileExists(atPath: url.path) ? url : nil
    }

    private func verifyHash(_ url: URL) -> Bool {
        guard let data = try? Data(contentsOf: url, options: [.mappedIfSafe]),
              data.count >= RemoteAuthIntegrity.minimumFileSize,
              data.count >= 12,
              !RemoteAuthIntegrity.protectedRanges.isEmpty else { return false }

        let magic: UInt32 = data.withUnsafeBytes { $0.load(fromByteOffset: 0, as: UInt32.self) }
        let cpu: Int32 = data.withUnsafeBytes { $0.load(fromByteOffset: 4, as: Int32.self) }
        guard magic == 0xFEEDFACF, cpu == 0x0100000C else { return false }

        var protectedBytes = Data()
        for range in RemoteAuthIntegrity.protectedRanges {
            guard range.offset >= 0, range.size > 0 else { return false }
            let end = range.offset + range.size
            guard end <= data.count else { return false }
            protectedBytes.append(data.subdata(in: range.offset..<end))
        }

        let digest = SHA256.hash(data: protectedBytes).map { String(format: "%02x", $0) }.joined()
        return Self.constantTimeEqual(digest, RemoteAuthIntegrity.expectedSHA256)
    }

    private static func constantTimeEqual(_ lhs: String, _ rhs: String) -> Bool {
        let a = Array(lhs.utf8), b = Array(rhs.utf8)
        guard a.count == b.count else { return false }
        var diff: UInt8 = 0
        for i in a.indices { diff |= a[i] ^ b[i] }
        return diff == 0
    }
}

@MainActor
final class AuthProtection: ObservableObject {
    static let shared = AuthProtection()

    enum State: Equatable {
        case checking
        case waitingForAuth
        case authorized
        case denied(String)
    }

    @Published private(set) var state: State = .checking
    private var pollTimer: Timer?
    private var refreshing = false

    private init() {}

    var isAuthorized: Bool {
        if case .authorized = state { return true }
        return false
    }

    func bootstrap() async {
        guard AuthDylibLoader.shared.loadAndVerify() else {
            state = .denied(AuthDylibLoader.shared.lastError ?? "RemoteAuth indisponível.")
            startPolling()
            return
        }
        RARemoteAuthEnsureStarted()
        startPolling()
        _ = refreshFromRuntime()
    }

    func appBecameActive() async {
        guard AuthDylibLoader.shared.loadAndVerify() else {
            state = .denied(AuthDylibLoader.shared.lastError ?? "RemoteAuth indisponível.")
            return
        }
        RARemoteAuthEnsureStarted()
        _ = refreshFromRuntime()
    }

    func permit(for action: ProtectedAction) -> ActionPermit? {
        guard refreshFromRuntime(),
              let permit = RuntimePermitGate.shared.makePermit(for: action),
              RuntimePermitGate.shared.validate(permit, for: action) else { return nil }
        return permit
    }

    @discardableResult
    private func refreshFromRuntime() -> Bool {
        if refreshing { return isAuthorized }
        refreshing = true; defer { refreshing = false }

        guard AuthDylibLoader.shared.verifyIntegrity() || AuthDylibLoader.shared.loadAndVerify(),
              RASecurityEnvironmentIsClean() else {
            RuntimePermitGate.shared.close()
            state = .denied(AuthDylibLoader.shared.lastError ?? "Proteção de integridade bloqueou o aplicativo.")
            return false
        }

        guard let snapshot = RemoteAuthSnapshot.capture() else {
            RuntimePermitGate.shared.close()
            let wasWaiting: Bool
            if case .waitingForAuth = state { wasWaiting = true } else { wasWaiting = false }
            state = .waitingForAuth
            // Do not call start every 0.5 s. Repeated starts used to reset the
            // fields while the user was typing and could re-enter presentation.
            if !wasWaiting { RARemoteAuthEnsureStarted() }
            return false
        }

        RuntimePermitGate.shared.sync(snapshot)
        state = .authorized
        return true
    }

    private func startPolling() {
        guard pollTimer == nil else { return }
        pollTimer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in
            guard let self else { return }
            Task { @MainActor in _ = self.refreshFromRuntime() }
        }
    }

    nonisolated static func validatePermit(_ permit: ActionPermit, for action: ProtectedAction) -> Bool {
        guard AuthDylibLoader.shared.verifyIntegrity(), RASecurityEnvironmentIsClean(),
              let snapshot = RemoteAuthSnapshot.capture() else {
            RuntimePermitGate.shared.close(); return false
        }
        RuntimePermitGate.shared.sync(snapshot)
        return RuntimePermitGate.shared.validate(permit, for: action)
    }

    nonisolated static func runtimeAccessAllowed() -> Bool {
        guard AuthDylibLoader.shared.verifyIntegrity(), RASecurityEnvironmentIsClean(),
              let snapshot = RemoteAuthSnapshot.capture() else {
            RuntimePermitGate.shared.close(); return false
        }
        RuntimePermitGate.shared.sync(snapshot)
        return RuntimePermitGate.shared.isOpen()
    }
}

private enum RemoteKeychain {
    static let service = "app.remote.auth"

    static func read(account: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        guard status == errSecSuccess, let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }
}

private enum AuthDateParser {
    static func parse(_ value: String) -> Date? {
        let fractional = ISO8601DateFormatter()
        fractional.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let date = fractional.date(from: value) { return date }
        let standard = ISO8601DateFormatter()
        standard.formatOptions = [.withInternetDateTime]
        return standard.date(from: value)
    }
}
