import Foundation
import SwiftUI
import UIKit
import ImageIO

struct ContentView: View {
    var body: some View {
        RemoteMainView()
            .environment(\.colorScheme, .dark)
            .preferredColorScheme(.dark)
    }
}

private struct RemoteMainView: View {
    @State private var injected = PatchSlotBackupRegistry.receipt(for: RemotePatchConfig.fileName) != nil
    @State private var busy = false
    @State private var successPresented = false
    @State private var successMessage = ""
    @State private var errorMessage: String?

    var body: some View {
        ZStack {
            RemoteParticleBackground()
                .ignoresSafeArea()

            RemoteScreen(
                injected: $injected,
                busy: busy,
                onToggle: setInjected
            )
        }
        .alert("Sucesso", isPresented: $successPresented) {
            Button("OK") { }
        } message: {
            Text(successMessage)
        }
        .alert(
            "REMOTE",
            isPresented: Binding(
                get: { errorMessage != nil },
                set: { if !$0 { errorMessage = nil } }
            )
        ) {
            Button("OK") { errorMessage = nil }
        } message: {
            Text(errorMessage ?? "")
        }
    }

    private func setInjected(_ value: Bool) {
        guard !busy else { return }
        busy = true

        DispatchQueue.global(qos: .userInitiated).async {
            let result = RemotePatchRunner.setEnabled(value)

            DispatchQueue.main.async {
                busy = false

                switch result {
                case .success:
                    injected = value
                    successMessage = value
                        ? "Injetado! ja pode me desinstalar ;)"
                        : "Desinjetado com sucesso!"
                    successPresented = true

                case .failure(let error):
                    errorMessage = RemotePatchRunner.message(for: error)
                }
            }
        }
    }
}

private struct RemoteScreen: View {
    @Binding var injected: Bool
    let busy: Bool
    let onToggle: (Bool) -> Void

    var body: some View {
        VStack(spacing: 0) {
            Spacer(minLength: 44)
            gifCard
            remoteSection
            Spacer()
            bottomBar
        }
    }

    private var gifCard: some View {
        RemoteGIFView(assetName: "RemoteGIF")
            .frame(height: 260)
            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .stroke(Color.white.opacity(0.90), lineWidth: 1.4)
            )
            .padding(.horizontal, 30)
    }

    private var remoteSection: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("REMOTE")
                .font(.system(size: 18, weight: .bold))
                .foregroundStyle(.white)

            RemoteInjectCard(
                injected: $injected,
                busy: busy,
                onToggle: onToggle
            )
        }
        .padding(.horizontal, 30)
        .padding(.top, 24)
    }

    private var bottomBar: some View {
        HStack {
            Spacer()

            VStack(spacing: 5) {
                Image(systemName: "square.grid.2x2.fill")
                    .font(.system(size: 20, weight: .semibold))

                Text("REMOTE")
                    .font(.system(size: 12, weight: .semibold))
            }
            .foregroundStyle(.white)

            Spacer()
        }
        .frame(height: 70)
        .background(Color.white.opacity(0.075))
        .clipShape(Capsule())
        .overlay(
            Capsule()
                .stroke(Color.white.opacity(0.10), lineWidth: 1)
        )
        .padding(.horizontal, 30)
        .padding(.bottom, 8)
    }
}

private struct RemoteInjectCard: View {
    @Binding var injected: Bool
    let busy: Bool
    let onToggle: (Bool) -> Void

    var body: some View {
        HStack(spacing: 14) {
            VStack(alignment: .leading, spacing: 5) {
                Text("INJETAR")
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundStyle(.white)

                Text("Remote iOS")
                    .font(.system(size: 13))
                    .foregroundStyle(.white.opacity(0.48))
            }

            Spacer()

            trailingControl
        }
        .padding(.horizontal, 18)
        .frame(height: 82)
        .background(Color.white.opacity(0.075))
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .stroke(Color.white.opacity(0.10), lineWidth: 1)
        )
    }

    @ViewBuilder
    private var trailingControl: some View {
        if busy {
            ProgressView()
                .tint(.white)
        } else {
            Toggle(
                "",
                isOn: Binding(
                    get: { injected },
                    set: { onToggle($0) }
                )
            )
            .labelsHidden()
            .tint(.white)
        }
    }
}

private struct RemoteParticleBackground: View {
    private static let normalizedPoints: [CGPoint] = [
        CGPoint(x: 0.08, y: 0.16), CGPoint(x: 0.29, y: 0.12),
        CGPoint(x: 0.48, y: 0.19), CGPoint(x: 0.70, y: 0.10),
        CGPoint(x: 0.90, y: 0.20), CGPoint(x: 0.16, y: 0.40),
        CGPoint(x: 0.39, y: 0.34), CGPoint(x: 0.61, y: 0.42),
        CGPoint(x: 0.84, y: 0.35), CGPoint(x: 0.09, y: 0.65),
        CGPoint(x: 0.31, y: 0.72), CGPoint(x: 0.52, y: 0.62),
        CGPoint(x: 0.73, y: 0.74), CGPoint(x: 0.92, y: 0.64),
        CGPoint(x: 0.19, y: 0.90), CGPoint(x: 0.43, y: 0.84),
        CGPoint(x: 0.67, y: 0.92), CGPoint(x: 0.87, y: 0.86)
    ]

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30.0)) { timeline in
            ParticleCanvas(time: timeline.date.timeIntervalSinceReferenceDate)
        }
        .background(Color.black)
    }

    private struct ParticleCanvas: View {
        let time: TimeInterval

        var body: some View {
            Canvas { context, size in
                let points = animatedPoints(in: size)
                drawConnections(points, context: &context)
                drawDots(points, context: &context)
            }
        }

        private func animatedPoints(in size: CGSize) -> [CGPoint] {
            var result: [CGPoint] = []
            result.reserveCapacity(RemoteParticleBackground.normalizedPoints.count)

            for (index, point) in RemoteParticleBackground.normalizedPoints.enumerated() {
                let phaseX = time * 0.32 + Double(index) * 1.71
                let phaseY = time * 0.27 + Double(index) * 1.23
                let offsetX = sin(phaseX) * 13.0
                let offsetY = cos(phaseY) * 11.0

                result.append(
                    CGPoint(
                        x: size.width * point.x + offsetX,
                        y: size.height * point.y + offsetY
                    )
                )
            }

            return result
        }

        private func drawConnections(_ points: [CGPoint], context: inout GraphicsContext) {
            guard points.count > 1 else { return }

            for firstIndex in 0..<(points.count - 1) {
                for secondIndex in (firstIndex + 1)..<points.count {
                    let first = points[firstIndex]
                    let second = points[secondIndex]
                    let dx = first.x - second.x
                    let dy = first.y - second.y
                    let distance = sqrt(dx * dx + dy * dy)

                    guard distance < 155.0 else { continue }

                    let opacity = max(0.015, 0.11 * (1.0 - distance / 155.0))
                    var path = Path()
                    path.move(to: first)
                    path.addLine(to: second)

                    context.stroke(
                        path,
                        with: .color(Color.white.opacity(opacity)),
                        lineWidth: 0.6
                    )
                }
            }
        }

        private func drawDots(_ points: [CGPoint], context: inout GraphicsContext) {
            for point in points {
                let rect = CGRect(
                    x: point.x - 1.5,
                    y: point.y - 1.5,
                    width: 3.0,
                    height: 3.0
                )
                context.fill(
                    Path(ellipseIn: rect),
                    with: .color(Color.white.opacity(0.55))
                )
            }
        }
    }
}

private struct RemoteGIFView: UIViewRepresentable {
    let assetName: String

    func makeUIView(context: Context) -> UIImageView {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        configure(imageView)
        return imageView
    }

    func updateUIView(_ uiView: UIImageView, context: Context) {
        if !uiView.isAnimating {
            uiView.startAnimating()
        }
    }

    private func configure(_ imageView: UIImageView) {
        guard let data = NSDataAsset(name: assetName)?.data,
              let source = CGImageSourceCreateWithData(data as CFData, nil) else {
            return
        }

        let count = CGImageSourceGetCount(source)
        guard count > 0 else { return }

        var frames: [UIImage] = []
        frames.reserveCapacity(count)

        for index in 0..<count {
            if let cgImage = CGImageSourceCreateImageAtIndex(source, index, nil) {
                frames.append(UIImage(cgImage: cgImage))
            }
        }

        guard !frames.isEmpty else { return }

        imageView.image = frames[0]
        imageView.animationImages = frames
        imageView.animationDuration = Double(frames.count) / 50.0
        imageView.animationRepeatCount = 0
        imageView.startAnimating()
    }
}

private enum RemotePatchConfig {
    static let fileName = "remote.3105"
    static let password = "realm"
}

private enum RemotePatchRunner {
    static func setEnabled(_ enabled: Bool) -> Result<String, Error> {
        do {
            if enabled {
                let data: Data
                do {
                    data = try EmbeddedPatchVault.data(named: RemotePatchConfig.fileName)
                } catch EmbeddedPatchVaultError.missingPatch {
                    throw RemotePatchError.missingPatch
                }

                let decoded = try PatchPackageCodec.decode(
                    data,
                    password: RemotePatchConfig.password
                )
                let receipt = try DevicePatchService.apply(project: decoded.project)
                PatchSlotBackupRegistry.save(receipt, for: RemotePatchConfig.fileName)
                return .success("Patch aplicado.")
            }

            guard let receipt = PatchSlotBackupRegistry.receipt(for: RemotePatchConfig.fileName) else {
                throw RemotePatchError.noBackup
            }

            try DevicePatchService.restore(receipt: receipt)
            PatchSlotBackupRegistry.remove(for: RemotePatchConfig.fileName)
            return .success("Backup restaurado.")
        } catch {
            return .failure(error)
        }
    }

    static func message(for error: Error) -> String {
        if let remoteError = error as? RemotePatchError {
            switch remoteError {
            case .missingPatch:
                return "remote.3105 não encontrado."
            case .noBackup:
                return "Backup não encontrado."
            }
        }

        if let patchError = error as? PatchPackageError {
            switch patchError {
            case .restoreFailed:
                return "Falha ao restaurar backup."
            default:
                return "Falha ao aplicar remote.3105."
            }
        }

        return "Operação não concluída."
    }

    private enum RemotePatchError: Error {
        case missingPatch
        case noBackup
    }
}

private enum PatchSlotBackupRegistry {
    private struct Entry: Codable {
        let transactionID: UUID
        let projectID: UUID
    }

    private static let defaultsKey = "remote.patch.slot.backups.v1"

    static func save(_ receipt: PatchTransactionReceipt, for slot: String) {
        var entries = load()
        entries[slot] = Entry(
            transactionID: receipt.id,
            projectID: receipt.projectID
        )
        persist(entries)
    }

    static func receipt(for slot: String) -> PatchTransactionReceipt? {
        var entries = load()

        guard let entry = entries[slot],
              let backupRoot = try? PatchProjectLibrary.backupRootURL() else {
            return nil
        }

        let journalURL = backupRoot
            .appendingPathComponent(entry.projectID.uuidString, isDirectory: true)
            .appendingPathComponent(entry.transactionID.uuidString, isDirectory: true)
            .appendingPathComponent("journal.plist")

        guard FileManager.default.fileExists(atPath: journalURL.path) else {
            entries.removeValue(forKey: slot)
            persist(entries)
            return nil
        }

        return PatchTransactionReceipt(
            id: entry.transactionID,
            projectID: entry.projectID,
            journalURL: journalURL
        )
    }

    static func remove(for slot: String) {
        var entries = load()
        entries.removeValue(forKey: slot)
        persist(entries)
    }

    private static func load() -> [String: Entry] {
        guard let data = UserDefaults.standard.data(forKey: defaultsKey),
              let entries = try? PropertyListDecoder().decode([String: Entry].self, from: data) else {
            return [:]
        }
        return entries
    }

    private static func persist(_ entries: [String: Entry]) {
        if entries.isEmpty {
            UserDefaults.standard.removeObject(forKey: defaultsKey)
            return
        }

        guard let data = try? PropertyListEncoder().encode(entries) else { return }
        UserDefaults.standard.set(data, forKey: defaultsKey)
    }
}
