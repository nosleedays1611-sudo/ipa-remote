import Foundation
import SwiftUI
import UIKit
import ImageIO
import Security

struct ContentView: View {
    @StateObject private var auth = RemoteAuthStore()

    var body: some View {
        Group {
            if auth.authenticated {
                RemoteMainView(onSessionInvalid: auth.forceLogout)
            } else {
                RemoteAuthView(auth: auth)
            }
        }
        .environment(\.colorScheme, .dark)
        .preferredColorScheme(.dark)
        .task { await auth.restoreSession() }
    }
}

private struct RemoteMainView: View {
    let onSessionInvalid: () -> Void
    @State private var injected = PatchSlotBackupRegistry.receipt(for: RemotePatchConfig.fileName) != nil
    @State private var busy = false
    @State private var successPresented = false
    @State private var successMessage = ""
    @State private var errorMessage: String?

    var body: some View {
        GeometryReader { proxy in
            ZStack {
                RemoteParticleBackground()
                    .ignoresSafeArea()

                RemoteScreen(
                    injected: $injected,
                    busy: busy,
                    onToggle: setInjected
                )
                .frame(width: proxy.size.width, height: proxy.size.height)
                .clipped()
            }
            .frame(width: proxy.size.width, height: proxy.size.height)
        }
        .alert("Sucesso", isPresented: $successPresented) {
            Button("OK") { }
        } message: {
            Text(successMessage)
        }
        .alert(
            "REMOTE",
            isPresented: Binding(
                get: { errorMessage != nil },
                set: { if !$0 { errorMessage = nil } }
            )
        ) {
            Button("OK") { errorMessage = nil }
        } message: {
            Text(errorMessage ?? "")
        }
    }

    private func setInjected(_ value: Bool) {
        guard !busy else { return }
        busy = true

        Task {
            do {
                try await RemoteAuthAPI.shared.checkCurrentSession()

                let result = await Task.detached(priority: .userInitiated) {
                    RemotePatchRunner.setEnabled(value)
                }.value

                await MainActor.run {
                    busy = false
                    switch result {
                    case .success:
                        injected = value
                        successMessage = value
                            ? "Injetado! ja pode me desinstalar ;)"
                            : "Desinjetado com sucesso!"
                        successPresented = true
                    case .failure(let error):
                        errorMessage = RemotePatchRunner.message(for: error)
                    }
                }
            } catch {
                await MainActor.run {
                    busy = false
                    errorMessage = (error as? RemoteAuthError)?.message ?? "Sessão inválida."
                    onSessionInvalid()
                }
            }
        }
    }
}

private struct RemoteScreen: View {
    @Binding var injected: Bool
    let busy: Bool
    let onToggle: (Bool) -> Void

    var body: some View {
        VStack(spacing: 0) {
            Spacer(minLength: 44)
            gifCard
            remoteSection
            Spacer()
            bottomBar
        }
    }

    private var gifCard: some View {
        RemoteGIFView(assetName: "RemoteGIF")
            .frame(height: 260)
            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .stroke(Color.white.opacity(0.90), lineWidth: 1.4)
            )
            .padding(.horizontal, 30)
    }

    private var remoteSection: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("REMOTE")
                .font(.system(size: 18, weight: .bold))
                .foregroundStyle(.white)

            RemoteInjectCard(
                injected: $injected,
                busy: busy,
                onToggle: onToggle
            )
        }
        .padding(.horizontal, 30)
        .padding(.top, 24)
    }

    private var bottomBar: some View {
        HStack {
            Spacer()

            VStack(spacing: 5) {
                Image(systemName: "square.grid.2x2.fill")
                    .font(.system(size: 20, weight: .semibold))

                Text("REMOTE")
                    .font(.system(size: 12, weight: .semibold))
            }
            .foregroundStyle(.white)

            Spacer()
        }
        .frame(height: 70)
        .background(Color.white.opacity(0.075))
        .clipShape(Capsule())
        .overlay(
            Capsule()
                .stroke(Color.white.opacity(0.10), lineWidth: 1)
        )
        .padding(.horizontal, 30)
        .padding(.bottom, 8)
    }
}

private struct RemoteInjectCard: View {
    @Binding var injected: Bool
    let busy: Bool
    let onToggle: (Bool) -> Void

    var body: some View {
        HStack(spacing: 14) {
            VStack(alignment: .leading, spacing: 5) {
                Text("INJETAR")
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundStyle(.white)

                Text("Remote iOS")
                    .font(.system(size: 13))
                    .foregroundStyle(.white.opacity(0.48))
            }

            Spacer()

            trailingControl
        }
        .padding(.horizontal, 18)
        .frame(height: 82)
        .background(Color.white.opacity(0.075))
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .stroke(Color.white.opacity(0.10), lineWidth: 1)
        )
    }

    @ViewBuilder
    private var trailingControl: some View {
        if busy {
            ProgressView()
                .tint(.white)
        } else {
            Toggle(
                "",
                isOn: Binding(
                    get: { injected },
                    set: { onToggle($0) }
                )
            )
            .labelsHidden()
            .tint(.white)
        }
    }
}

private struct RemoteParticleBackground: View {
    private static let normalizedPoints: [CGPoint] = [
        CGPoint(x: 0.08, y: 0.16), CGPoint(x: 0.29, y: 0.12),
        CGPoint(x: 0.48, y: 0.19), CGPoint(x: 0.70, y: 0.10),
        CGPoint(x: 0.90, y: 0.20), CGPoint(x: 0.16, y: 0.40),
        CGPoint(x: 0.39, y: 0.34), CGPoint(x: 0.61, y: 0.42),
        CGPoint(x: 0.84, y: 0.35), CGPoint(x: 0.09, y: 0.65),
        CGPoint(x: 0.31, y: 0.72), CGPoint(x: 0.52, y: 0.62),
        CGPoint(x: 0.73, y: 0.74), CGPoint(x: 0.92, y: 0.64),
        CGPoint(x: 0.19, y: 0.90), CGPoint(x: 0.43, y: 0.84),
        CGPoint(x: 0.67, y: 0.92), CGPoint(x: 0.87, y: 0.86)
    ]

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 60.0)) { timeline in
            ParticleCanvas(time: timeline.date.timeIntervalSinceReferenceDate)
        }
        .background(Color.black)
    }

    private struct ParticleCanvas: View {
        let time: TimeInterval

        var body: some View {
            Canvas { context, size in
                let points = animatedPoints(in: size)
                drawConnections(points, context: &context)
                drawDots(points, context: &context)
            }
        }

        private func animatedPoints(in size: CGSize) -> [CGPoint] {
            var result: [CGPoint] = []
            result.reserveCapacity(RemoteParticleBackground.normalizedPoints.count)

            for (index, point) in RemoteParticleBackground.normalizedPoints.enumerated() {
                let phaseX = time * (0.72 + Double(index % 4) * 0.08) + Double(index) * 1.71
                let phaseY = time * (0.60 + Double(index % 5) * 0.065) + Double(index) * 1.23
                let offsetX = sin(phaseX) * (15.0 + Double(index % 3) * 4.0)
                let offsetY = cos(phaseY) * (13.0 + Double(index % 4) * 3.0)

                result.append(
                    CGPoint(
                        x: size.width * point.x + offsetX,
                        y: size.height * point.y + offsetY
                    )
                )
            }

            return result
        }

        private func drawConnections(_ points: [CGPoint], context: inout GraphicsContext) {
            guard points.count > 1 else { return }

            for firstIndex in 0..<(points.count - 1) {
                for secondIndex in (firstIndex + 1)..<points.count {
                    let first = points[firstIndex]
                    let second = points[secondIndex]
                    let dx = first.x - second.x
                    let dy = first.y - second.y
                    let distance = sqrt(dx * dx + dy * dy)

                    // Cada partícula tem um alcance diferente para evitar uma malha uniforme.
                    let pairSeed = (firstIndex * 31 + secondIndex * 17) % 5
                    let connectionRange = 125.0 + Double(pairSeed) * 18.0
                    guard distance < connectionRange else { continue }

                    // Nem todo par próximo fica conectado: cria grupos e linhas irregulares.
                    let connectionSeed = (firstIndex * 13 + secondIndex * 7) % 4
                    guard connectionSeed != 0 || distance < 92.0 else { continue }

                    let opacity = max(0.012, 0.12 * (1.0 - distance / connectionRange))
                    var path = Path()
                    path.move(to: first)
                    path.addLine(to: second)

                    context.stroke(
                        path,
                        with: .color(Color.white.opacity(opacity)),
                        lineWidth: 0.6
                    )
                }
            }
        }

        private func drawDots(_ points: [CGPoint], context: inout GraphicsContext) {
            for point in points {
                let rect = CGRect(
                    x: point.x - 1.5,
                    y: point.y - 1.5,
                    width: 3.0,
                    height: 3.0
                )
                context.fill(
                    Path(ellipseIn: rect),
                    with: .color(Color.white.opacity(0.55))
                )
            }
        }
    }
}

private struct RemoteGIFView: UIViewRepresentable {
    let assetName: String

    func makeUIView(context: Context) -> UIImageView {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        configure(imageView)
        return imageView
    }

    func updateUIView(_ uiView: UIImageView, context: Context) {
        if !uiView.isAnimating {
            uiView.startAnimating()
        }
    }

    private func configure(_ imageView: UIImageView) {
        guard let data = NSDataAsset(name: assetName)?.data,
              let source = CGImageSourceCreateWithData(data as CFData, nil) else {
            return
        }

        let count = CGImageSourceGetCount(source)
        guard count > 0 else { return }

        var frames: [UIImage] = []
        frames.reserveCapacity(count)

        for index in 0..<count {
            if let cgImage = CGImageSourceCreateImageAtIndex(source, index, nil) {
                frames.append(UIImage(cgImage: cgImage))
            }
        }

        guard !frames.isEmpty else { return }

        imageView.image = frames[0]
        imageView.animationImages = frames
        imageView.animationDuration = Double(frames.count) / 50.0
        imageView.animationRepeatCount = 0
        imageView.startAnimating()
    }
}


@MainActor
private final class RemoteAuthStore: ObservableObject {
    @Published var authenticated = false
    @Published var busy = false
    @Published var errorMessage: String?
    @Published var key = RemoteKeychain.string(account: "remote-license-key") ?? ""
    @Published var ipv4 = ""
    @Published var expiresAt = ""

    func restoreSession() async {
        guard RemoteKeychain.string(account: "remote-session-token") != nil else { return }
        do {
            let info = try await RemoteAuthAPI.shared.me()
            apply(info)
            authenticated = true
            startHeartbeat()
        } catch {
            clearLocalSession()
        }
    }

    func login() {
        let normalized = key.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        guard !normalized.isEmpty else {
            errorMessage = "Digite sua key."
            return
        }
        busy = true
        errorMessage = nil
        Task {
            do {
                let info = try await RemoteAuthAPI.shared.activate(key: normalized)
                RemoteKeychain.set(normalized, account: "remote-license-key")
                apply(info)
                authenticated = true
                busy = false
                startHeartbeat()
            } catch {
                busy = false
                errorMessage = (error as? RemoteAuthError)?.message ?? "Falha ao autenticar."
            }
        }
    }

    func forceLogout() {
        clearLocalSession()
    }

    private func apply(_ info: RemoteAuthInfo) {
        if !info.key.isEmpty { key = info.key }
        ipv4 = info.ipv4
        expiresAt = info.expiresAt
    }

    private func clearLocalSession() {
        RemoteKeychain.delete(account: "remote-session-token")
        authenticated = false
    }

    private func startHeartbeat() {
        Task { [weak self] in
            while let self, self.authenticated {
                try? await Task.sleep(nanoseconds: 60_000_000_000)
                guard self.authenticated else { return }
                do {
                    let info = try await RemoteAuthAPI.shared.check()
                    self.apply(info)
                } catch {
                    self.clearLocalSession()
                    return
                }
            }
        }
    }
}

private struct RemoteAuthView: View {
    @ObservedObject var auth: RemoteAuthStore

    var body: some View {
        GeometryReader { proxy in
            ZStack {
                RemoteParticleBackground().ignoresSafeArea()
                VStack(spacing: 22) {
                Spacer()
                RemoteGIFView(assetName: "RemoteGIF")
                    .frame(height: 250)
                    .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white.opacity(0.85), lineWidth: 1.2))
                    .padding(.horizontal, 30)

                VStack(spacing: 14) {
                    Text("REMOTE")
                        .font(.system(size: 25, weight: .bold))
                        .foregroundStyle(.white)

                    TextField("REMOTE-IOS-XXXXXX", text: $auth.key)
                        .textInputAutocapitalization(.characters)
                        .autocorrectionDisabled()
                        .foregroundStyle(.white)
                        .padding(.horizontal, 16)
                        .frame(height: 52)
                        .background(Color.white.opacity(0.075))
                        .clipShape(RoundedRectangle(cornerRadius: 15))
                        .overlay(RoundedRectangle(cornerRadius: 15).stroke(Color.white.opacity(0.14), lineWidth: 1))

                    Button(action: auth.login) {
                        Group {
                            if auth.busy { ProgressView().tint(.black) }
                            else { Text("ENTRAR").fontWeight(.bold) }
                        }
                        .foregroundStyle(.black)
                        .frame(maxWidth: .infinity)
                        .frame(height: 52)
                        .background(Color.white)
                        .clipShape(RoundedRectangle(cornerRadius: 15))
                    }
                    .disabled(auth.busy)

                    if let message = auth.errorMessage {
                        Text(message)
                            .font(.system(size: 13, weight: .medium))
                            .foregroundStyle(.white.opacity(0.72))
                            .multilineTextAlignment(.center)
                    }
                }
                .padding(.horizontal, 30)
                Spacer()
                }
                .frame(width: proxy.size.width, height: proxy.size.height)
                .clipped()
            }
            .frame(width: proxy.size.width, height: proxy.size.height)
        }
    }
}

private struct RemoteAuthInfo {
    let key: String
    let ipv4: String
    let expiresAt: String
}

private struct RemoteAuthError: Error {
    let code: String
    let message: String
}

private final class RemoteAuthAPI {
    static let shared = RemoteAuthAPI()
    private let baseURL = URL(string: "https://externalconfig.shardweb.app")!

    func activate(key: String) async throws -> RemoteAuthInfo {
        var request = URLRequest(url: baseURL.appendingPathComponent("api/auth/activate"))
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONSerialization.data(withJSONObject: ["key": key])
        let json = try await send(request)
        guard let token = string(json, "token", "session_token", "access_token"), !token.isEmpty else {
            throw RemoteAuthError(code: "invalid_response", message: "Servidor não retornou a sessão.")
        }
        RemoteKeychain.set(token, account: "remote-session-token")
        return info(json, fallbackKey: key)
    }

    func me() async throws -> RemoteAuthInfo {
        try await authenticatedRequest(path: "api/auth/me", method: "GET")
    }

    func check() async throws -> RemoteAuthInfo {
        try await authenticatedRequest(path: "api/auth/check", method: "POST")
    }

    func checkCurrentSession() async throws {
        _ = try await check()
    }

    private func authenticatedRequest(path: String, method: String) async throws -> RemoteAuthInfo {
        guard let token = RemoteKeychain.string(account: "remote-session-token"), !token.isEmpty else {
            throw RemoteAuthError(code: "unauthorized", message: "Faça login novamente.")
        }
        var request = URLRequest(url: baseURL.appendingPathComponent(path))
        request.httpMethod = method
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        if method == "POST" {
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = Data("{}".utf8)
        }
        let json = try await send(request)
        return info(json, fallbackKey: RemoteKeychain.string(account: "remote-license-key") ?? "")
    }

    private func send(_ request: URLRequest) async throws -> [String: Any] {
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else {
            throw RemoteAuthError(code: "network", message: "Resposta inválida do servidor.")
        }
        let json = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:]
        let ok = (json["ok"] as? Bool) ?? (json["success"] as? Bool) ?? false
        let authenticated = json["authenticated"] as? Bool
        let valid = json["valid"] as? Bool
        if !(200..<300).contains(http.statusCode) || !ok || authenticated == false || valid == false {
            let code = string(json, "error", "code") ?? "unauthorized"
            let serverMessage = string(json, "message")
            throw RemoteAuthError(code: code, message: serverMessage ?? message(for: code))
        }
        return json
    }

    private func info(_ json: [String: Any], fallbackKey: String) -> RemoteAuthInfo {
        RemoteAuthInfo(
            key: string(json, "key") ?? fallbackKey,
            ipv4: string(json, "ipv4", "bound_ipv4") ?? "",
            expiresAt: string(json, "expires_at") ?? ""
        )
    }

    private func string(_ json: [String: Any], _ keys: String...) -> String? {
        for key in keys {
            if let value = json[key] as? String { return value }
        }
        if let data = json["data"] as? [String: Any] {
            for key in keys {
                if let value = data[key] as? String { return value }
            }
        }
        return nil
    }

    private func message(for code: String) -> String {
        switch code.lowercased() {
        case "invalid_key": return "Key inválida."
        case "disabled": return "Key desativada."
        case "paused": return "Key pausada."
        case "expired": return "Key expirada."
        case "ipv4_mismatch": return "IPv4 diferente do vinculado à key."
        case "token_expired": return "Sessão expirada. Entre novamente."
        case "session_revoked": return "Sessão revogada. Entre novamente."
        case "rate_limited": return "Muitas tentativas. Tente novamente em instantes."
        default: return "Não foi possível autenticar."
        }
    }
}

private enum RemoteKeychain {
    private static let service = "app.remote.ios.auth"

    static func set(_ value: String, account: String) {
        delete(account: account)
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecValueData as String: Data(value.utf8),
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        ]
        SecItemAdd(query as CFDictionary, nil)
    }

    static func string(account: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var item: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &item) == errSecSuccess,
              let data = item as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    static func delete(account: String) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(query as CFDictionary)
    }
}

private enum RemotePatchConfig {
    static let fileName = "remote.3105"
    static let password = "realm"
}

private enum RemotePatchRunner {
    static func setEnabled(_ enabled: Bool) -> Result<String, Error> {
        do {
            if enabled {
                let data: Data
                do {
                    data = try EmbeddedPatchVault.data(named: RemotePatchConfig.fileName)
                } catch EmbeddedPatchVaultError.missingPatch {
                    throw RemotePatchError.missingPatch
                }

                let decoded = try PatchPackageCodec.decode(
                    data,
                    password: RemotePatchConfig.password
                )
                let receipt = try DevicePatchService.apply(project: decoded.project)
                PatchSlotBackupRegistry.save(receipt, for: RemotePatchConfig.fileName)
                return .success("Patch aplicado.")
            }

            guard let receipt = PatchSlotBackupRegistry.receipt(for: RemotePatchConfig.fileName) else {
                throw RemotePatchError.noBackup
            }

            try DevicePatchService.restore(receipt: receipt)
            PatchSlotBackupRegistry.remove(for: RemotePatchConfig.fileName)
            return .success("Backup restaurado.")
        } catch {
            return .failure(error)
        }
    }

    static func message(for error: Error) -> String {
        if let remoteError = error as? RemotePatchError {
            switch remoteError {
            case .missingPatch:
                return "remote.3105 não encontrado."
            case .noBackup:
                return "Backup não encontrado."
            }
        }

        if let patchError = error as? PatchPackageError {
            switch patchError {
            case .restoreFailed:
                return "Falha ao restaurar backup."
            default:
                return "Falha ao aplicar remote.3105."
            }
        }

        return "Operação não concluída."
    }

    private enum RemotePatchError: Error {
        case missingPatch
        case noBackup
    }
}

private enum PatchSlotBackupRegistry {
    private struct Entry: Codable {
        let transactionID: UUID
        let projectID: UUID
    }

    private static let defaultsKey = "remote.patch.slot.backups.v1"

    static func save(_ receipt: PatchTransactionReceipt, for slot: String) {
        var entries = load()
        entries[slot] = Entry(
            transactionID: receipt.id,
            projectID: receipt.projectID
        )
        persist(entries)
    }

    static func receipt(for slot: String) -> PatchTransactionReceipt? {
        var entries = load()

        guard let entry = entries[slot],
              let backupRoot = try? PatchProjectLibrary.backupRootURL() else {
            return nil
        }

        let journalURL = backupRoot
            .appendingPathComponent(entry.projectID.uuidString, isDirectory: true)
            .appendingPathComponent(entry.transactionID.uuidString, isDirectory: true)
            .appendingPathComponent("journal.plist")

        guard FileManager.default.fileExists(atPath: journalURL.path) else {
            entries.removeValue(forKey: slot)
            persist(entries)
            return nil
        }

        return PatchTransactionReceipt(
            id: entry.transactionID,
            projectID: entry.projectID,
            journalURL: journalURL
        )
    }

    static func remove(for slot: String) {
        var entries = load()
        entries.removeValue(forKey: slot)
        persist(entries)
    }

    private static func load() -> [String: Entry] {
        guard let data = UserDefaults.standard.data(forKey: defaultsKey),
              let entries = try? PropertyListDecoder().decode([String: Entry].self, from: data) else {
            return [:]
        }
        return entries
    }

    private static func persist(_ entries: [String: Entry]) {
        if entries.isEmpty {
            UserDefaults.standard.removeObject(forKey: defaultsKey)
            return
        }

        guard let data = try? PropertyListEncoder().encode(entries) else { return }
        UserDefaults.standard.set(data, forKey: defaultsKey)
    }
}
