require("dotenv").config();

const express = require("express");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const jwt = require("jsonwebtoken");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");

const app = express();

const PORT = Number(process.env.PORT || 3000);
const RAFAELA_API_URL = "https://rafaelagenerator.shardweb.app";
const REMOTE_SESSION_SECRET = process.env.REMOTE_SESSION_SECRET;
const STATE_FILE = process.env.REMOTE_STATE_FILE || path.join(__dirname, "remote-state.json");

const STATE_VERSION = 4;
const LICENSE_CACHE_MS = 10000;
const ASSEMBLY_ONLINE_MS = 12000;
const IPV4_CONFLICT_ACTIVE_MS = 30000;
// Alias de transporte dura só até o primeiro vínculo com o dispositivo.
// Ele NÃO substitui o IPv4 real vinculado à licença no gerador.
const TRANSPORT_PAIR_WINDOW_MS = 10 * 60 * 1000;
const CONFIG_SETTLE_MS = 400;
const OVERLAY_MIN_INTERVAL_MS = 33;
const DEVICE_PENDING_MS = 60000;
const REQUIRED_SITE = "zeex-remote-ios-v1";
const AUTH_DENIED_BODY = "ZEEX_AUTH_DENIED!";

if (!REMOTE_SESSION_SECRET) {
  console.error("ERRO: configure REMOTE_SESSION_SECRET no .env.");
  process.exit(1);
}

app.disable("x-powered-by");
app.disable("etag");
app.set("trust proxy", 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "32kb" }));

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 60,
  standardHeaders: true,
  legacyHeaders: false
});

function normalizeKey(value) {
  return String(value || "").trim().toUpperCase();
}

function normalizeIpv4(value) {
  return String(value || "").trim().replace(/^::ffff:/, "");
}

function validIpv4(value) {
  const parts = normalizeIpv4(value).split(".");
  if (parts.length !== 4) return false;
  return parts.every(part => {
    if (!/^\d{1,3}$/.test(part)) return false;
    const n = Number(part);
    return Number.isInteger(n) && n >= 0 && n <= 255;
  });
}

function requestIpv4(req) {
  const forwarded = String(req.headers["x-forwarded-for"] || "")
    .split(",")
    .map(value => value.trim())
    .filter(Boolean);

  const candidates = [
    req.headers["cf-connecting-ip"],
    req.headers["x-real-ip"],
    ...forwarded,
    req.ip,
    req.socket?.remoteAddress
  ];

  for (const value of candidates) {
    const ip = normalizeIpv4(value);
    if (validIpv4(ip)) return ip;
  }

  return "";
}

function requestSite(req) {
  return String(req.headers["x-zeex-site"] || "").trim();
}

function rawDeviceId(req) {
  const value = String(req.headers["x-zeex-device"] || "").trim();
  if (value.length < 8 || value.length > 256) return "";
  return value;
}

function hashDeviceId(raw) {
  return crypto.createHash("sha256").update(String(raw)).digest("hex");
}

function requestDeviceHash(req) {
  const raw = rawDeviceId(req);
  return raw ? hashDeviceId(raw) : "";
}

// Apenas memória. Serve para associar o Assembly que já está consultando
// ao login KEY+IPv4 feito no site.
const pendingDevices = new Map();

function rememberPendingDevice(ipv4, deviceHash) {
  if (!validIpv4(ipv4) || !deviceHash) return;
  pendingDevices.set(ipv4, {
    device_hash: deviceHash,
    seen_at: Date.now()
  });
}

function recentPendingDevice(ipv4) {
  const item = pendingDevices.get(ipv4);
  if (!item) return null;
  if (Date.now() - item.seen_at > DEVICE_PENDING_MS) {
    pendingDevices.delete(ipv4);
    return null;
  }
  return item;
}

function bool(value, fallback = false) {
  if (typeof value === "boolean") return value;
  if (value === 1 || value === "1" || value === "true") return true;
  if (value === 0 || value === "0" || value === "false") return false;
  return fallback;
}

function int(value, min, max, fallback) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(min, Math.min(max, Math.round(n)));
}

/*
  IMPORTANTE:
  Todo cliente novo começa 100% desligado.
  Valores como target/fov/alokLevel continuam preenchidos, mas não ativam nada
  enquanto seus gates principais estiverem OFF.
*/
function defaultConfig() {
  return {
    aimMode: null,
    target: "Head",
    fov: 252,
    showFov: false,
    overlayEsp: false,
    espBox: false,
    espHealth: false,
    espName: false,
    espSkeleton: false,
    chams: false,
    boxStyle: "Cornered",
    boxFilled: false,
    fastMedkit: false,
    alokMode: "Desligado",
    alokLevel: "Lv 1",
    attributeLevel: "Desligado",
    noRecoil: false
  };
}

function normalizeConfig(input = {}) {
  const base = defaultConfig();
  const src = input && typeof input === "object" ? input : {};

  let aimMode = src.aimMode;
  if (
    aimMode === false ||
    aimMode === null ||
    aimMode === "" ||
    aimMode === "off" ||
    aimMode === "Desligado" ||
    aimMode === undefined
  ) {
    aimMode = null;
  } else if (aimMode !== "aimbot" && aimMode !== "silent") {
    aimMode = base.aimMode;
  }

  const targetAliases = {
    Head: "Head",
    Neck: "Neck",
    Chest: "Chest",
    "Cabeça": "Head",
    "Cabeca": "Head",
    "Pescoço": "Neck",
    "Pescoco": "Neck",
    "Peito": "Chest"
  };
  const boxStyles = ["Full", "Cornered"];
  const alokModes = ["Desligado", "Sempre ativo", "Somente com Alok ativo"];
  const alokLevels = ["Lv 1", "Lv 2", "Lv 3", "Lv 4", "Lv 5"];
  const attributes = ["Desligado", "Nível 1", "Nível 2", "Nível 3", "Nível 4"];

  return {
    aimMode,
    target: targetAliases[String(src.target || "")] || base.target,
    fov: int(src.fov, 0, 360, base.fov),
    showFov: bool(src.showFov, base.showFov),
    overlayEsp: bool(src.overlayEsp, base.overlayEsp),
    espBox: bool(src.espBox, base.espBox),
    espHealth: bool(src.espHealth, base.espHealth),
    espName: bool(src.espName, base.espName),
    espSkeleton: bool(src.espSkeleton, base.espSkeleton),
    chams: bool(src.chams, base.chams),
    boxStyle: boxStyles.includes(src.boxStyle) ? src.boxStyle : base.boxStyle,
    boxFilled: bool(src.boxFilled, base.boxFilled),
    fastMedkit: bool(src.fastMedkit, base.fastMedkit),
    alokMode: alokModes.includes(src.alokMode) ? src.alokMode : base.alokMode,
    alokLevel: alokLevels.includes(src.alokLevel) ? src.alokLevel : base.alokLevel,
    attributeLevel: attributes.includes(src.attributeLevel) ? src.attributeLevel : base.attributeLevel,
    noRecoil: bool(src.noRecoil, base.noRecoil)
  };
}

function everythingOff(configInput) {
  const c = normalizeConfig(configInput);
  return (
    c.aimMode === null &&
    c.showFov === false &&
    c.overlayEsp === false &&
    c.espBox === false &&
    c.espHealth === false &&
    c.espName === false &&
    c.espSkeleton === false &&
    c.chams === false &&
    c.boxFilled === false &&
    c.fastMedkit === false &&
    c.noRecoil === false &&
    c.alokMode === "Desligado" &&
    c.attributeLevel === "Desligado"
  );
}

/*
  Protocolo do Assembly atual:
  00 version = 7
  01 ESP Box
  02 ESP Health
  03 Aim master
  04 Target: 0 Head / 1 Neck / 2 Chest
  05-07 FOV 000..360
  08 Atributo: 0..4
  09 ESP Name
  10 ESP Skeleton
  11 Box Style: 0 Full / 1 Cornered
  12 Box Filled
  13 Fast Medkit
  14 No Recoil
  15 Alok Mode: 0..2
  16 Alok Level: 1..5
  17 Overlay ESP
  18 Aim Mode: 0 Aimbot / 1 Aim Silent
  19 Chams/Test
  20 FOV wire (somente sf=2): 0 mostrar / 1 ocultar
*/
function assemblyPayload(configInput, includeHideFov = false) {
  const c = normalizeConfig(configInput);

  const target = { Head: "0", Neck: "1", Chest: "2" }[c.target];
  const attribute = {
    "Desligado": "0",
    "Nível 1": "1",
    "Nível 2": "2",
    "Nível 3": "3",
    "Nível 4": "4"
  }[c.attributeLevel];
  const alokMode = {
    "Desligado": "0",
    "Sempre ativo": "1",
    "Somente com Alok ativo": "2"
  }[c.alokMode];
  const alokLevel = {
    "Lv 1": "1",
    "Lv 2": "2",
    "Lv 3": "3",
    "Lv 4": "4",
    "Lv 5": "5"
  }[c.alokLevel];

  const aimEnabled = c.aimMode !== null;
  const aimMode = c.aimMode === "silent" ? "1" : "0";
  const fov = String(c.fov).padStart(3, "0");

  const payload = [
    "7",
    c.espBox ? "1" : "0",
    c.espHealth ? "1" : "0",
    aimEnabled ? "1" : "0",
    target,
    fov,
    attribute,
    c.espName ? "1" : "0",
    c.espSkeleton ? "1" : "0",
    c.boxStyle === "Cornered" ? "1" : "0",
    c.boxFilled ? "1" : "0",
    c.fastMedkit ? "1" : "0",
    c.noRecoil ? "1" : "0",
    alokMode,
    alokLevel,
    c.overlayEsp ? "1" : "0",
    aimMode,
    c.chams ? "1" : "0"
  ].join("");

  if (payload.length !== 20) {
    throw new Error(`assembly_payload_length_${payload.length}`);
  }

  if (!/^7[01]{3}[0-2]\d{3}[0-4][01]{6}[0-2][1-5][01]{3}$/.test(payload)) {
    throw new Error(`assembly_payload_invalid_${payload}`);
  }

  if (includeHideFov) {
    return payload + (c.showFov ? "0" : "1");
  }

  return payload;
}

function clientIdFor(key, ipv4) {
  return crypto
    .createHash("sha256")
    .update(`${normalizeKey(key)}|${normalizeIpv4(ipv4)}`)
    .digest("hex");
}

function emptyState() {
  return {
    version: STATE_VERSION,
    clients: {},
    bindings: {},
    revoked_sessions: {}
  };
}

function persistentClient(client) {
  return {
    id: client.id,
    key: client.key,
    ipv4: client.ipv4,
    desired_config: normalizeConfig(client.desired_config),
    applied_config: normalizeConfig(client.applied_config),
    config_updated_at: Number(client.config_updated_at || 0),
    applied_updated_at: Number(client.applied_updated_at || 0),
    pending_apply_at: Number(client.pending_apply_at || 0),
    device_hash: String(client.device_hash || ""),
    transport_ipv4: normalizeIpv4(client.transport_ipv4 || ""),
    transport_pair_at: Number(client.transport_pair_at || 0),
    created_at: Number(client.created_at || Date.now())
  };
}

function persistentSnapshot() {
  const clients = {};
  for (const [id, client] of Object.entries(state.clients)) {
    clients[id] = persistentClient(client);
  }

  const bindings = {};
  for (const [ipv4, binding] of Object.entries(state.bindings)) {
    if (binding && clients[binding.client_id]) {
      bindings[ipv4] = {
        client_id: binding.client_id,
        bound_at: Number(binding.bound_at || Date.now())
      };
    }
  }

  return {
    version: STATE_VERSION,
    clients,
    bindings,
    revoked_sessions: activeRevokedSessions(state.revoked_sessions)
  };
}

// Apenas hashes de tokens são persistidos; nenhum bearer é armazenado em disco.
function tokenFingerprint(token) {
  return crypto.createHash("sha256").update(String(token)).digest("hex");
}

function activeRevokedSessions(sessions) {
  const now = Date.now();
  return Object.fromEntries(Object.entries(sessions || {}).filter(([id, until]) =>
    /^[a-f0-9]{64}$/.test(id) && Number(until) > now
  ));
}

function revokeCurrentSession(token, expiresAt) {
  if (!token) return;
  const expiryMs = Number.isFinite(Number(expiresAt)) && Number(expiresAt) > 0
    ? Number(expiresAt) * 1000
    : Date.now() + 12 * 60 * 60 * 1000;
  state.revoked_sessions = activeRevokedSessions(state.revoked_sessions);
  state.revoked_sessions[tokenFingerprint(token)] = expiryMs;
  saveState();
}

function backupLegacyState() {
  try {
    if (!fs.existsSync(STATE_FILE)) return;
    const backup = `${STATE_FILE}.legacy-backup-${Date.now()}.json`;
    fs.copyFileSync(STATE_FILE, backup);
    console.log(`[STATE] backup legado criado: ${backup}`);
  } catch (error) {
    console.error("[STATE BACKUP]", error.message);
  }
}

function hydrateClient(raw) {
  const now = Date.now();
  const desired = normalizeConfig(raw?.desired_config || defaultConfig());
  const applied = normalizeConfig(raw?.applied_config || desired);

  return {
    id: String(raw?.id || ""),
    key: normalizeKey(raw?.key),
    ipv4: normalizeIpv4(raw?.ipv4),
    desired_config: desired,
    applied_config: applied,
    config_updated_at: Number(raw?.config_updated_at || now),
    applied_updated_at: Number(raw?.applied_updated_at || now),
    pending_apply_at: Number(raw?.pending_apply_at || 0),
    device_hash: String(raw?.device_hash || ""),
    transport_ipv4: normalizeIpv4(raw?.transport_ipv4 || ""),
    transport_pair_at: Number(raw?.transport_pair_at || 0),
    created_at: Number(raw?.created_at || now),

    // EPHEMERAL — nunca persistir frame de overlay no disco.
    overlay: "",
    overlay_updated_at: 0,
    last_overlay_ingest_at: 0,
    assembly_last_seen_at: 0,
    site_last_seen_at: 0
  };
}

function loadState() {
  try {
    if (!fs.existsSync(STATE_FILE)) return emptyState();

    const parsed = JSON.parse(fs.readFileSync(STATE_FILE, "utf8"));

    // v2 guardava clientes por key e um mapa IPv4->key.
    // Para impedir herança/cross-talk, não migramos configs antigas ativadas.
    if (Number(parsed?.version) !== STATE_VERSION) {
      backupLegacyState();
      console.log("[STATE] schema antigo detectado; iniciando v3 limpo (tudo OFF).");
      return emptyState();
    }

    const next = emptyState();

    for (const [id, raw] of Object.entries(parsed?.clients || {})) {
      const client = hydrateClient({ ...raw, id });
      if (!client.key || !validIpv4(client.ipv4)) continue;

      const expectedId = clientIdFor(client.key, client.ipv4);
      client.id = expectedId;
      next.clients[expectedId] = client;
    }

    for (const [ipv4, binding] of Object.entries(parsed?.bindings || {})) {
      const ip = normalizeIpv4(ipv4);
      const cid = String(binding?.client_id || "");
      if (validIpv4(ip) && next.clients[cid]) {
        next.bindings[ip] = {
          client_id: cid,
          bound_at: Number(binding?.bound_at || Date.now())
        };
      }
    }
    next.revoked_sessions = activeRevokedSessions(parsed?.revoked_sessions);

    return next;
  } catch (error) {
    console.error("[STATE LOAD]", error.message);
    return emptyState();
  }
}

let state = loadState();

function saveState() {
  try {
    const tmp = `${STATE_FILE}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(persistentSnapshot(), null, 2), "utf8");
    fs.renameSync(tmp, STATE_FILE);
  } catch (error) {
    console.error("[STATE SAVE]", error.message);
  }
}

function ensurePairClient(keyInput, ipv4Input) {
  const key = normalizeKey(keyInput);
  const ipv4 = normalizeIpv4(ipv4Input);
  const id = clientIdFor(key, ipv4);
  const now = Date.now();

  let client = state.clients[id];

  if (!client) {
    const config = defaultConfig();
    client = {
      id,
      key,
      ipv4,
      desired_config: config,
      applied_config: { ...config },
      config_updated_at: now,
      applied_updated_at: now,
      pending_apply_at: 0,
      device_hash: "",
      transport_ipv4: "",
      transport_pair_at: 0,
      created_at: now,

      overlay: "",
      overlay_updated_at: 0,
      last_overlay_ingest_at: 0,
      assembly_last_seen_at: 0,
      site_last_seen_at: now
    };
    state.clients[id] = client;
  } else {
    client.key = key;
    client.ipv4 = ipv4;
    client.desired_config = normalizeConfig(client.desired_config);
    client.applied_config = normalizeConfig(client.applied_config);
    client.site_last_seen_at = now;
  }

  return client;
}

function currentBinding(ipv4) {
  const ip = normalizeIpv4(ipv4);
  const binding = state.bindings[ip];
  if (!binding) return null;

  const client = state.clients[binding.client_id];
  if (!client || client.ipv4 !== ip) {
    delete state.bindings[ip];
    return null;
  }

  return { binding, client };
}

function claimBinding(client) {
  const existing = currentBinding(client.ipv4);

  if (existing && existing.client.id !== client.id) {
    const activeRecently =
      existing.client.assembly_last_seen_at > 0 &&
      Date.now() - existing.client.assembly_last_seen_at < IPV4_CONFLICT_ACTIVE_MS;

    if (activeRecently) {
      const error = new Error("ipv4_in_use");
      error.status = 409;
      throw error;
    }
  }

  state.bindings[client.ipv4] = {
    client_id: client.id,
    bound_at: Date.now()
  };
}

function releaseBinding(client) {
  const binding = state.bindings[client.ipv4];
  if (binding?.client_id === client.id) {
    delete state.bindings[client.ipv4];
  }
}

function attachRecentDeviceToClient(client) {
  const pending = recentPendingDevice(client.ipv4);
  if (!pending) return false;

  // Explicit valid KEY+IPv4 login is allowed to bind/rebind the Assembly
  // currently seen on that same public IPv4.
  client.device_hash = pending.device_hash;
  state.clients[client.id] = client;
  return true;
}

function commitPendingConfig(client) {
  const due = Number(client.pending_apply_at || 0);

  if (due > 0 && Date.now() >= due) {
    client.applied_config = normalizeConfig(client.desired_config);
    client.applied_updated_at = Date.now();
    client.pending_apply_at = 0;
    state.clients[client.id] = client;
    return true;
  }

  return false;
}

async function validateWithRafaela(key, ipv4) {
  let response;

  try {
    response = await fetch(`${RAFAELA_API_URL}/api/client/activate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ key, ipv4 }),
      signal: AbortSignal.timeout(2500)
    });
  } catch (cause) {
    const error = new Error("rafaela_unavailable");
    error.status = 503;
    error.cause = cause;
    throw error;
  }

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    const error = new Error(data.error || "rafaela_validation_failed");
    error.status = response.status;
    error.payload = data;
    throw error;
  }

  return data;
}

function normalizeValidationStatus(error) {
  const status = Number(error?.status);
  if (status === 400 || status === 401 || status === 403 || status === 404 || status === 409) {
    return status;
  }
  if (status >= 500) return 503;
  return 503;
}

const licenseCache = new Map();

async function validateLicenseCached(key, ipv4) {
  const cacheKey = `${normalizeKey(key)}|${normalizeIpv4(ipv4)}`;
  const cached = licenseCache.get(cacheKey);
  const now = Date.now();

  if (cached && now - cached.checked_at < LICENSE_CACHE_MS) {
    if (cached.ok) return cached.license;

    const error = new Error(cached.error || "license_invalid");
    error.status = cached.status || 403;
    throw error;
  }

  try {
    const license = await validateWithRafaela(key, ipv4);
    licenseCache.set(cacheKey, {
      ok: true,
      license,
      checked_at: now
    });
    return license;
  } catch (error) {
    licenseCache.set(cacheKey, {
      ok: false,
      error: error.payload?.error || error.message,
      status: normalizeValidationStatus(error),
      checked_at: now
    });
    throw error;
  }
}

function issueSession(client) {
  return jwt.sign(
    {
      sub: client.key,
      cid: client.id,
      ipv4: client.ipv4,
      scope: "remote-client-v3",
      jti: crypto.randomUUID() // Logins no site e no iPhone nunca compartilham JWT.
    },
    REMOTE_SESSION_SECRET,
    { expiresIn: "12h" }
  );
}

function readBearer(req) {
  const header = String(req.headers.authorization || "");
  return header.startsWith("Bearer ") ? header.slice(7).trim() : "";
}

function decodeSession(token) {
  const payload = jwt.verify(token, REMOTE_SESSION_SECRET);
  if (payload.scope !== "remote-client-v3") throw new Error("invalid_scope");
  if (Number(state.revoked_sessions[tokenFingerprint(token)] || 0) > Date.now()) {
    throw new Error("session_revoked");
  }
  return payload;
}

function clientAuth(req, res, next) {
  try {
    const token = readBearer(req);
    if (!token) {
      return res.status(401).json({ error: "unauthorized" });
    }

    const session = decodeSession(token);
    // A sessão web autenticada identifica o par KEY+IPv4.
    // req.ip pode apontar ao proxy da Shard, e não à IPA.
    const client = state.clients[session.cid];

    if (
      !client ||
      client.key !== normalizeKey(session.sub) ||
      client.ipv4 !== normalizeIpv4(session.ipv4)
    ) {
      return res.status(401).json({ error: "unauthorized" });
    }

    client.site_last_seen_at = Date.now();
    req.client = session;
    req.clientRecord = client;
    next();
  } catch {
    return res.status(401).json({ error: "unauthorized" });
  }
}


// Retorna um cliente AUTORIZADO para a requisição nativa.
// O login web pode chegar pelo IPv4 do proxy, mas a licença permanece vinculada
// ao IPv4 real informado no login. Em caso de ambiguidade: DENIED, nunca mistura contas.
function matchingAssemblyClient(observedIp, deviceHash) {
  const active = Object.values(state.clients).filter(client =>
    currentBinding(client.ipv4)?.client.id === client.id
  );
  // Prioridade para dispositivo já pareado com essa KEY+IPv4.
  const deviceMatches = active.filter(client =>
    client.device_hash === deviceHash &&
    (client.ipv4 === observedIp || client.transport_ipv4 === observedIp)
  );
  if (deviceMatches.length === 1) return deviceMatches[0];
  if (deviceMatches.length > 1) return null;

  // Compatibilidade com o caminho antigo, quando os IPs eram idênticos.
  const direct = currentBinding(observedIp)?.client;
  if (direct && (!direct.device_hash || direct.device_hash === deviceHash)) return direct;

  // Primeiro pareamento: só se exatamente UM login recente no mesmo canal
  // de transporte ainda não tiver dispositivo vinculado.
  const now = Date.now();
  const possible = active.filter(client =>
    client.transport_ipv4 === observedIp &&
    client.transport_pair_at > 0 &&
    now - client.transport_pair_at < TRANSPORT_PAIR_WINDOW_MS &&
    !client.device_hash
  );
  return possible.length === 1 ? possible[0] : null;
}

async function assemblyClient(req) {
  const ipv4 = requestIpv4(req);
  const site = requestSite(req);
  const deviceHash = requestDeviceHash(req);

  if (!ipv4) {
    const error = new Error("invalid_ipv4");
    error.status = 400;
    throw error;
  }

  if (site !== REQUIRED_SITE) {
    const error = new Error("invalid_site");
    error.status = 403;
    throw error;
  }

  if (!deviceHash) {
    const error = new Error("device_missing");
    error.status = 403;
    throw error;
  }

  // Mesmo antes do login, guardamos temporariamente qual Assembly está
  // consultando por esse IPv4. A resposta continua DENIED sem vínculo.
  rememberPendingDevice(ipv4, deviceHash);

  const client = matchingAssemblyClient(ipv4, deviceHash);
  if (!client) {
    const error = new Error("assembly_not_linked");
    error.status = 403;
    throw error;
  }

  // Primeiro request depois de um login válido pode completar o vínculo.
  if (!client.device_hash) {
    client.device_hash = deviceHash;
    state.clients[client.id] = client;
    saveState();
  }

  if (client.device_hash !== deviceHash) {
    const error = new Error("device_mismatch");
    error.status = 403;
    throw error;
  }

  // KEY + IPv4 são revalidados no gerador, e o device precisa ser o
  // mesmo que foi vinculado para esse cliente.
  // Validar com a KEY + IPv4 REAL vinculado no gerador, nunca IP do proxy.
  await validateLicenseCached(client.key, client.ipv4);

  client.assembly_last_seen_at = Date.now();
  state.clients[client.id] = client;

  return { client, ipv4, device_hash: deviceHash };
}

/* =========================================================
   AUTH
========================================================= */

app.get("/api/client-ip", (req, res) => {
  const ipv4 = requestIpv4(req);

  res.set("Cache-Control", "no-store, no-cache, must-revalidate");

  if (!ipv4) {
    return res.status(503).json({
      ok: false,
      error: "client_ip_unavailable"
    });
  }

  return res.json({
    ok: true,
    ipv4
  });
});

app.post("/api/auth/activate", loginLimiter, async (req, res) => {
  const key = normalizeKey(req.body?.key);
  // Apenas o login web recebe o IPv4 informado pelo cliente.
  // NÃO alterar requestIpv4(): a IPA/Assembly usam o fluxo antigo.
  const ipv4 = normalizeIpv4(req.body?.ipv4);

  if (!/^REMOTE-IOS-[A-Z0-9]{6}$/.test(key)) {
    return res.status(400).json({ error: "invalid_key_format" });
  }

  if (!validIpv4(ipv4)) {
    return res.status(400).json({ error: "invalid_ipv4" });
  }

  try {
    const license = await validateWithRafaela(key, ipv4);
    // O gerador determina o endereço efetivamente vinculado.
    // Em caso de inconsistência, NÃO criar sessão Remote.
    if (license.bound_ipv4 !== ipv4) {
      return res.status(409).json({ error: "ipv4_mismatch" });
    }
    const client = ensurePairClient(key, ipv4);
    // Canal observado do NAVEGADOR usado somente para ligar a IPA que consulta
    // por trás do mesmo proxy. NÃO altera a chave/IP vinculados no gerador.
    client.transport_ipv4 = requestIpv4(req);
    client.transport_pair_at = Date.now();

    claimBinding(client);
    attachRecentDeviceToClient(client);

    licenseCache.set(`${key}|${ipv4}`, {
      ok: true,
      license,
      checked_at: Date.now()
    });

    saveState();

    return res.json({
      ok: true,
      token: issueSession(client),
      key,
      ipv4,
      client_id: client.id,
      license,
      config: client.desired_config
    });
  } catch (error) {
    const maskedKey = key.length >= 4 ? `***${key.slice(-4)}` : "***";
    console.error(
      "[REMOTE AUTH]",
      error.message,
      "| key=" + maskedKey,
      "| ipv4=" + ipv4,
      "| validator=" + RAFAELA_API_URL
    );

    return res.status(Number(error.status) || 502).json({
      error: error.payload?.error || error.message || "validation_failed"
    });
  }
});

app.post("/api/auth/logout", clientAuth, (req, res) => {
  // LOGOUT != REVOGAÇÃO DE LICENÇA/UNBIND.
  // Mantém KEY+IPv4+device_hash e configurações ativas no cliente nativo.
  // JWTs legados não tinham jti: não os revogamos por segurança da sessão
  // nativa, pois em logins simultâneos podiam ser literalmente idênticos.
  // Todos os logins novos possuem jti e são revogados individualmente.
  if (req.client.jti) {
    revokeCurrentSession(readBearer(req), req.client.exp);
  }
  return res.json({ ok: true, site_logged_out: true });
});

app.get("/api/auth/me", clientAuth, async (req, res) => {
  try {
    const client = req.clientRecord;
    const license = await validateLicenseCached(client.key, client.ipv4);

    client.transport_ipv4 = requestIpv4(req);
    client.transport_pair_at = Date.now();
    claimBinding(client);
    attachRecentDeviceToClient(client);
    saveState();

    return res.json({
      ok: true,
      key: client.key,
      ipv4: client.ipv4,
      client_id: client.id,
      license,
      config: client.desired_config
    });
  } catch (error) {
    return res.status(Number(error.status) || 401).json({
      error: error.payload?.error || error.message || "license_invalid"
    });
  }
});

/* =========================================================
   CONFIG
========================================================= */

app.get("/api/config", async (req, res) => {
  const bearer = readBearer(req);

  if (bearer) {
    try {
      const session = decodeSession(bearer);
      const client = state.clients[session.cid];

      if (!client || client.key !== normalizeKey(session.sub) ||
          client.ipv4 !== normalizeIpv4(session.ipv4) ||
          client.id !== clientIdFor(session.sub, session.ipv4)) {
        return res.status(401).json({ error: "unauthorized" });
      }

      await validateLicenseCached(client.key, client.ipv4);

      return res.json({
        ok: true,
        config: client.desired_config,
        assembly_payload: assemblyPayload(client.applied_config, true),
        updated_at: client.config_updated_at,
        applied_updated_at: client.applied_updated_at,
        pending_apply_at: client.pending_apply_at,
        assembly_last_seen_at: client.assembly_last_seen_at
      });
    } catch {
      return res.status(401).json({ error: "unauthorized" });
    }
  }

  try {
    const remote = await assemblyClient(req);
    const client = remote.client;

    if (commitPendingConfig(client)) {
      saveState();
    }

    const payload = assemblyPayload(
      client.applied_config,
      String(req.query?.sf || "") === "2"
    );

    res.set({
      "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
      "CDN-Cache-Control": "no-store",
      "Cloudflare-CDN-Cache-Control": "no-store",
      "Pragma": "no-cache",
      "Expires": "0",
      "Content-Type": "text/plain; charset=us-ascii"
    });

    return res.status(200).end(payload, "ascii");
  } catch (error) {
    const status = normalizeValidationStatus(error);

    res.set({
      "Content-Type": "text/plain; charset=us-ascii",
      "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0"
    });

    return res
      .status(status)
      .end(AUTH_DENIED_BODY, "ascii");
  }
});

async function saveConfig(req, res) {
  try {
    const client = req.clientRecord;

    await validateLicenseCached(client.key, client.ipv4);

    const incoming =
      req.body?.config && typeof req.body.config === "object"
        ? req.body.config
        : (req.body && typeof req.body === "object" ? req.body : {});

    const nextConfig = normalizeConfig({
      ...client.desired_config,
      ...incoming
    });

    client.desired_config = nextConfig;
    client.config_updated_at = Date.now();

    // "Desligar tudo" precisa ter prioridade e ser imediato.
    if (everythingOff(nextConfig)) {
      client.applied_config = { ...nextConfig };
      client.applied_updated_at = Date.now();
      client.pending_apply_at = 0;
    } else {
      // Evita o Assembly receber 4-5 estados intermediários quando o usuário
      // liga várias opções rapidamente.
      client.pending_apply_at = Date.now() + CONFIG_SETTLE_MS;
    }

    state.clients[client.id] = client;
    state.bindings[client.ipv4] = {
      client_id: client.id,
      bound_at: state.bindings[client.ipv4]?.bound_at || Date.now()
    };

    saveState();

    return res.json({
      ok: true,
      config: client.desired_config,
      assembly_payload: assemblyPayload(client.applied_config, true),
      updated_at: client.config_updated_at,
      pending_apply_at: client.pending_apply_at
    });
  } catch (error) {
    return res.status(Number(error.status) || 401).json({
      error: error.payload?.error || error.message || "config_update_failed"
    });
  }
}

app.post("/api/config", clientAuth, saveConfig);
app.put("/api/config", clientAuth, saveConfig);

/* =========================================================
   HEARTBEAT / STATUS
========================================================= */

app.post("/api/heartbeat", clientAuth, async (req, res) => {
  try {
    const client = req.clientRecord;
    const license = await validateLicenseCached(client.key, client.ipv4);

    return res.json({
      ok: true,
      server_time: Date.now(),
      config_updated_at: client.config_updated_at,
      applied_updated_at: client.applied_updated_at,
      pending_apply_at: client.pending_apply_at,
      assembly_last_seen_at: client.assembly_last_seen_at,
      license
    });
  } catch (error) {
    return res.status(Number(error.status) || 401).json({
      error: error.payload?.error || error.message || "license_invalid"
    });
  }
});

app.get("/api/remote/status", clientAuth, async (req, res) => {
  try {
    const client = req.clientRecord;
    await validateLicenseCached(client.key, client.ipv4);

    const now = Date.now();

    return res.json({
      ok: true,
      linked: currentBinding(client.ipv4)?.client.id === client.id,
      assembly_online:
        client.assembly_last_seen_at > 0 &&
        now - client.assembly_last_seen_at < ASSEMBLY_ONLINE_MS,
      assembly_last_seen_at: client.assembly_last_seen_at,
      config_updated_at: client.config_updated_at,
      applied_updated_at: client.applied_updated_at,
      pending_apply_at: client.pending_apply_at,
      overlay_updated_at: client.overlay_updated_at
    });
  } catch (error) {
    return res.status(Number(error.status) || 401).json({
      error: error.payload?.error || error.message || "license_invalid"
    });
  }
});

/* =========================================================
   OVERLAY
   Frames são efêmeros: não escrevemos remote-state.json por frame.
========================================================= */

const overlayParser = express.text({
  type: ["text/plain", "text/*", "application/octet-stream"],
  limit: "512kb"
});

async function receiveOverlay(req, res) {
  try {
    const remote = await assemblyClient(req);
    const client = remote.client;
    const frame = typeof req.body === "string" ? req.body : "";

    if (!frame || frame.length > 524288) {
      return res.status(400).type("text/plain").send("INVALID_FRAME");
    }

    const now = Date.now();

    // Cap de ingestão para o backend não ficar afogado em requests/GC.
    if (
      client.last_overlay_ingest_at > 0 &&
      now - client.last_overlay_ingest_at < OVERLAY_MIN_INTERVAL_MS
    ) {
      return res.status(200).type("text/plain").send("OK");
    }

    client.overlay = frame;
    client.overlay_updated_at = now;
    client.last_overlay_ingest_at = now;
    client.assembly_last_seen_at = now;
    state.clients[client.id] = client;

    // NUNCA saveState() aqui.
    return res.status(200).type("text/plain").send("OK");
  } catch (error) {
    const status = normalizeValidationStatus(error);

    return res
      .status(status)
      .type("text/plain")
      .send(AUTH_DENIED_BODY);
  }
}

app.put("/api/overlay", overlayParser, receiveOverlay);
app.post("/api/overlay", overlayParser, receiveOverlay);

app.get("/api/overlay", clientAuth, async (req, res) => {
  try {
    const client = req.clientRecord;
    await validateLicenseCached(client.key, client.ipv4);

    const since = Number(req.query?.since || 0);
    const updatedAt = Number(client.overlay_updated_at || 0);

    // Se o navegador já tem este frame, não reenviar a string inteira.
    if (since > 0 && updatedAt > 0 && since >= updatedAt) {
      return res.json({
        ok: true,
        unchanged: true,
        updated_at: updatedAt,
        assembly_last_seen_at: client.assembly_last_seen_at
      });
    }

    return res.json({
      ok: true,
      unchanged: false,
      frame: client.overlay || "",
      updated_at: updatedAt,
      assembly_last_seen_at: client.assembly_last_seen_at
    });
  } catch (error) {
    return res.status(Number(error.status) || 401).json({
      error: error.payload?.error || error.message || "license_invalid"
    });
  }
});

/* =========================================================
   HEALTH / STATIC
========================================================= */

app.get("/api/health", (req, res) => {
  res.json({
    ok: true,
    service: "remoteios",
    auth_mode: "key_ipv4_device_bound_v4",
      fov_protocol: "fail_closed_wire_0_show_1_hide",
    state_version: STATE_VERSION,
    config_settle_ms: CONFIG_SETTLE_MS,
    overlay_persisted: false,
    timestamp: Date.now()
  });
});

app.use(express.static(path.join(__dirname, "public")));

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.use((error, req, res, next) => {
  console.error("[REMOTEIOS SERVER]", error);
  if (res.headersSent) return next(error);
  res.status(500).json({ error: "internal_error" });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(
    `REMOTEIOS on ${PORT} | state=v${STATE_VERSION} | auth=KEY+IPv4+DEVICE bound | settle=${CONFIG_SETTLE_MS}ms`
  );
  console.log(`[REMOTE VALIDATOR] ${RAFAELA_API_URL}`);
});
