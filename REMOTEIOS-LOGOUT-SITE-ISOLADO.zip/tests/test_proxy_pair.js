'use strict';
const vm=require('node:vm'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const target=process.argv[2]||path.join(__dirname,'..','server.js');
const src=fs.readFileSync(target,'utf8');
const stateFile=path.join(__dirname,'temp-proxy-'+process.pid+'.json');
const routes={}; const noop=(_req,_res,next)=>next();
const app={disable(){return this},set(){return this},use(){return this},get(p,...h){routes['GET '+p]=h;return this},post(p,...h){routes['POST '+p]=h;return this},put(p,...h){routes['PUT '+p]=h;return this},listen(port,host,cb){cb?.();return this}};
const express=()=>app;express.json=()=>noop;express.text=()=>noop;express.static=()=>noop;
const secret='standalone-test-secret';
const jwt={sign(p){const v=JSON.stringify(p);return Buffer.from(v).toString('base64url')+'.'+crypto.createHmac('sha256',secret).update(v).digest('hex')},verify(t){const [a,b]=t.split('.');const v=Buffer.from(a,'base64url').toString();if(crypto.createHmac('sha256',secret).update(v).digest('hex')!==b)throw Error('bad jwt');return JSON.parse(v)}};
const imports={'dotenv':{config(){}},express,'jsonwebtoken':jwt,helmet:()=>noop,'express-rate-limit':()=>noop};
const licenseRequests=[];const sandbox={console,process:{env:{REMOTE_SESSION_SECRET:secret,REMOTE_STATE_FILE:stateFile,PORT:'3333'}},__dirname,require:(id)=>imports[id]??require(id),fetch:async(_url,opt)=>{const data=JSON.parse(opt.body);licenseRequests.push(data);return{ok:true,status:200,json:async()=>({ok:true,bound_ipv4:data.ipv4,plan:'7',expires_at:Date.now()+10000000})}},AbortSignal,Date,Buffer,setTimeout,clearTimeout};
vm.createContext(sandbox);vm.runInContext(src,sandbox,{filename:'server.js'});
const p='172.71.238.79';const a='45.178.251.243',b='192.144.103.237';
async function call(method,url,params={}){const handlers=routes[method+' '+url];assert(handlers,'No route '+url);const req={method,ip:p,headers:{'cf-connecting-ip':params.proxy||p,...(params.token?{authorization:'Bearer '+params.token}:{}),...(params.headers||{})},body:params.body||{},query:params.query||{},socket:{remoteAddress:'10.0.0.3'}};const res={statusCode:200,payload:undefined,sent:false,headers:{},status(n){this.statusCode=n;return this},json(v){this.payload=v;this.sent=true;return this},set(k,v){if(typeof k==='object')Object.assign(this.headers,k);else this.headers[k]=v;return this},type(v){this.headers['Content-Type']=v;return this},end(v){this.payload=v;this.sent=true;return this},send(v){this.payload=v;this.sent=true;return this}};for(const h of handlers){if(res.sent)break;let next=false;await h(req,res,()=>{next=true});if(res.sent||!next)break;}return res}
async function run(){
// A: browser and IPA both OBSERVED by Shard as proxy IPv4 p; real IP bound to generator is a.
let logA=await call('POST','/api/auth/activate',{body:{key:'REMOTE-IOS-TST001',ipv4:a}});assert.equal(logA.statusCode,200);
const headersA={'x-zeex-site':'zeex-remote-ios-v1','x-zeex-device':'DEVICE-ORIGINAL-AAA'};
let cfgA=await call('POST','/api/config',{token:logA.payload.token,body:{config:{espBox:true,espName:true}}});assert.equal(cfgA.statusCode,200);
await new Promise(done=>setTimeout(done,500));
let asmA=await call('GET','/api/config',{headers:headersA,query:{sf:'2'}});
assert.equal(asmA.statusCode,200,'Assembly A should work EVEN WHEN proxy IPv4 '+p+' differs from real IPv4 '+a+'. Returned '+JSON.stringify(asmA));
assert.equal(asmA.payload.length,21);assert.equal(asmA.payload[1],'1');assert.equal(asmA.payload[9],'1');
// B: another key, different real IPv4, same proxy edge; must not inherit A features.
let logB=await call('POST','/api/auth/activate',{body:{key:'REMOTE-IOS-TST002',ipv4:b}});assert.equal(logB.statusCode,200);
let cfgB=await call('POST','/api/config',{token:logB.payload.token,body:{config:{espHealth:true}}});assert.equal(cfgB.statusCode,200);
await new Promise(done=>setTimeout(done,500));
let asmB=await call('GET','/api/config',{headers:{'x-zeex-site':'zeex-remote-ios-v1','x-zeex-device':'DEVICE-ORIGINAL-BBB'}});
assert.equal(asmB.statusCode,200,'B should independently pair behind same proxy');assert.equal(asmB.payload.length,20);
assert.equal(asmB.payload[1],'0'); assert.equal(asmB.payload[2],'1');assert.equal(asmB.payload[9],'0');
let asmAagain=await call('GET','/api/config',{headers:headersA});assert.equal(asmAagain.statusCode,200);assert.equal(asmAagain.payload[1],'1');assert.equal(asmAagain.payload[2],'0');
const unknown=await call('GET','/api/config',{headers:{'x-zeex-site':'zeex-remote-ios-v1','x-zeex-device':'DEVICE-ORIGINAL-CCC'}});assert.equal(unknown.statusCode,403,'unknown third device must fail closed');
const wrongTransport=await call('GET','/api/config',{proxy:'172.71.238.88',headers:headersA});assert.equal(wrongTransport.statusCode,403,'new proxy / unsynchronized transport must fail closed');
const statusA=await call('GET','/api/remote/status',{token:logA.payload.token});assert.equal(statusA.statusCode,200);assert.equal(statusA.payload.assembly_online,true);
assert(licenseRequests.every(q=>[a,b].includes(q.ipv4)),'Never validate generator with proxy IP');
console.log('PASS: REAL IP license + SHARD proxy IP assembly, two KEYs on same proxy stay isolated, 20/21 unchanged, denied unknown device, denied different proxy');
}
run().then(()=>{try{fs.unlinkSync(stateFile)}catch{}}).catch(e=>{console.error(e);try{fs.unlinkSync(stateFile)}catch{};process.exitCode=1});
