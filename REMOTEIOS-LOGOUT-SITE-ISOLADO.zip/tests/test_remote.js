'use strict';
const vm=require('node:vm'), fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const src=fs.readFileSync(path.join(__dirname,'..','server.js'),'utf8');
const tmpState=path.join(__dirname,'remote-test-state.json');
try {fs.unlinkSync(tmpState)}catch{}
const routes={};function noop(req,res,next){next()}
const app={disable(){return this},set(){return this},use(){return this},get(p,...f){routes['GET '+p]=f;return this},post(p,...f){routes['POST '+p]=f;return this},put(p,...f){routes['PUT '+p]=f;return this},listen(port,host,cb){cb?.();return this}};
function express(){return app};express.json=()=>noop;express.text=()=>noop;express.static=()=>noop;
const secret='testing-secret';
const jwt={sign(p){const payload=JSON.stringify(p);return Buffer.from(payload).toString('base64url')+'.'+crypto.createHmac('sha256',secret).update(payload).digest('hex')},verify(t){const [a,b]=t.split('.');const payload=Buffer.from(a,'base64url').toString('utf8');if(crypto.createHmac('sha256',secret).update(payload).digest('hex')!==b)throw Error('bad token');return JSON.parse(payload)}};
const imports={'dotenv':{config(){}},express,'jsonwebtoken':jwt,helmet:()=>noop,'express-rate-limit':()=>noop};
let calls=[];
const sandbox={console,process:{env:{REMOTE_SESSION_SECRET:secret,REMOTE_STATE_FILE:tmpState,PORT:'3333'}},__dirname,require:(id)=>imports[id]??require(id),fetch:async(url,opt)=>{assert.match(url,/rafaelagenerator/);const data=JSON.parse(opt.body);calls.push(data);if(data.key==='REMOTE-IOS-ERROR1')return {ok:false,status:403,json:async()=>({error:'ipv4_mismatch'})};if(data.key==='REMOTE-IOS-ERROR2')return{ok:true,status:200,json:async()=>({ok:true,bound_ipv4:'172.71.238.79',plan:'7'})};return{ok:true,status:200,json:async()=>({ok:true,bound_ipv4:data.ipv4,plan:'7',expires_at:Date.now()+36000000})}},AbortSignal,Date,Buffer,setTimeout,clearTimeout};
vm.createContext(sandbox);vm.runInContext(src,sandbox,{filename:'server.js'});
async function invoke(method,url,params={}){
 const f=routes[method+' '+url];assert(f,'missing route '+method+' '+url);
 const req={method,ip:params.observedIP??'172.71.238.79',headers:{...(params.token?{authorization:'Bearer '+params.token}:{}),...(params.headers||{})},body:params.body||{},query:params.query||{},socket:{remoteAddress:'10.0.0.3'}};
 const res={statusCode:200,payload:null,sent:false,headers:{},status(n){this.statusCode=n;return this},json(x){this.payload=x;this.sent=true;return this},set(k,v){if(typeof k==='object')Object.assign(this.headers,k);else this.headers[k]=v;return this},type(v){this.headers['Content-Type']=v;return this},end(v){this.payload=v;this.sent=true;return this},send(v){this.payload=v;this.sent=true;return this}};
 for(const handler of f){if(res.sent)break;let advanced=false;await handler(req,res,()=>{advanced=true});if(!advanced||res.sent)break;}return res;
}
(async()=>{
 const a='45.178.251.243',b='192.144.103.237';
 const noIp=await invoke('POST','/api/auth/activate',{body:{key:'REMOTE-IOS-TST001'}});
 assert.equal(noIp.statusCode,400);assert.equal(calls.length,0,'NEVER activate with omitted IP');
 const bad=await invoke('POST','/api/auth/activate',{body:{key:'REMOTE-IOS-TST001',ipv4:'not-ip'}});
 assert.equal(bad.statusCode,400);assert.equal(calls.length,0);
 const genBad=await invoke('POST','/api/auth/activate',{body:{key:'REMOTE-IOS-ERROR1',ipv4:a}});
 assert.equal(genBad.statusCode,403);assert.equal(genBad.payload.error,'ipv4_mismatch');
 const genDisagreement=await invoke('POST','/api/auth/activate',{body:{key:'REMOTE-IOS-ERROR2',ipv4:a}});
 assert.equal(genDisagreement.statusCode,409);
 let la=await invoke('POST','/api/auth/activate',{body:{key:'REMOTE-IOS-TST001',ipv4:a}});
 assert.equal(la.statusCode,200,JSON.stringify(la.payload));assert.equal(la.payload.ipv4,a);
 assert.equal(calls.at(-1).ipv4,a,'Must send manual IP to generator, not proxy IP');
 let lb=await invoke('POST','/api/auth/activate',{body:{key:'REMOTE-IOS-TST002',ipv4:b}});
 assert.equal(lb.statusCode,200);assert.equal(lb.payload.ipv4,b);
 // Both website requests share same proxy IPv4 but not remote key/IP.
 const meA=await invoke('GET','/api/auth/me',{token:la.payload.token}); const meB=await invoke('GET','/api/auth/me',{token:lb.payload.token});
 assert.equal(meA.statusCode,200);assert.equal(meB.statusCode,200);assert.equal(meA.payload.ipv4,a);assert.equal(meB.payload.ipv4,b);
 const sa=await invoke('POST','/api/config',{token:la.payload.token,body:{config:{espBox:true}}});assert.equal(sa.statusCode,200);
 const ca=await invoke('GET','/api/config',{token:la.payload.token});const cb=await invoke('GET','/api/config',{token:lb.payload.token});
 assert.equal(ca.payload.config.espBox,true);assert.equal(cb.payload.config.espBox,false);
 // Assembly uses EXACT original /api/config path and IP resolver.
 const asmHeaders={'x-zeex-site':'zeex-remote-ios-v1','x-zeex-device':'DEVICE-12345678','cf-connecting-ip':a};
 const asm=await invoke('GET','/api/config',{headers:asmHeaders,query:{sf:'2'}});
 assert.equal(asm.statusCode,200,JSON.stringify(asm));assert.match(asm.payload,/^7/);assert.equal(asm.payload.length,21);
 const asm20=await invoke('GET','/api/config',{headers:asmHeaders});assert.equal(asm20.statusCode,200);assert.equal(asm20.payload.length,20);
 const deny=await invoke('GET','/api/config',{headers:{'cf-connecting-ip':'203.0.113.9','x-zeex-site':'zeex-remote-ios-v1','x-zeex-device':'DEVICE-12345678'}});assert.equal(deny.statusCode,403);assert.equal(deny.payload,'ZEEX_AUTH_DENIED!');
 const status=await invoke('GET','/api/remote/status',{token:la.payload.token});assert.equal(status.statusCode,200);assert.equal(status.payload.assembly_online,true);
 // Native assembly protocol stays the same; all 18 feature characters retain positions.
 assert.equal(asm.payload[0],'7');
 // Separate site/iPhone sessions must NEVER unbind the same KEY+IPv4 client.
 const nativeLogin=await invoke('POST','/api/auth/activate',{body:{key:'REMOTE-IOS-TST001',ipv4:a}});
 assert.equal(nativeLogin.statusCode,200);
 assert.notEqual(nativeLogin.payload.token,la.payload.token,'browser and iPhone JWTs must be unique');
 const resp=await invoke('POST','/api/auth/logout',{token:la.payload.token});
 assert.equal(resp.statusCode,200);assert.equal(resp.payload.site_logged_out,true);
 const webAfter=await invoke('GET','/api/auth/me',{token:la.payload.token});
 assert.equal(webAfter.statusCode,401,'site token must be rejected after logout');
 const nativeAfter=await invoke('GET','/api/auth/me',{token:nativeLogin.payload.token});
 assert.equal(nativeAfter.statusCode,200,'native token must remain authorized');
 const asmAfter=await invoke('GET','/api/config',{headers:asmHeaders,query:{sf:'2'}});
 assert.equal(asmAfter.statusCode,200,'Assembly must stay linked when site logs out');
 assert.equal(asmAfter.payload.length,21);
 const onDisk=JSON.parse(fs.readFileSync(tmpState,'utf8'));
 assert.equal(onDisk.bindings[a].client_id,la.payload.client_id,'binding must survive site logout');
 assert(Object.keys(onDisk.revoked_sessions).length===1,'only one session revoked');
 console.log('PASS: unique sessions, logout revokes only browser, native and Assembly remain linked');
 console.log('PASS: manual key+ip, generator IP, separated keys/config, original assembly GET /api/config (20/21), status, denied wire-format');
 try{fs.unlinkSync(tmpState)}catch{}
})().catch(e=>{console.error(e);process.exitCode=1;try{fs.unlinkSync(tmpState)}catch{}});
